# -*- coding: utf-8 -*-
"""
v12 — فیبو، ورود و مسیرِ قیمت رویِ 5m · ۱ ماه · لانگ و شورت · سرمایه‌یِ مشترک.
  1a: ورودِ مستقیم ۰.۶۱۸ (شکاف ← بازار) + فقط قیمت بالایِ MA200ِ 1h (شورت: زیر)
  1b: 1a + فیلترهایِ قفل‌شده: SL≥۳٪ · بدونِ ۴–۸ و ۱۶–۲۰ UTC · هم‌جهتیِ 5m · بدونِ واگراییِ مخالفِ 5m
  2 : بدونِ فیلتر · ورود با کراسِ MA5/MA20ِ 5m وقتی کلوز بینِ ۰.۵ و ۰.۷۸۶ـه
"""
import os, sys, time, argparse
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fr as FR, fr7 as F7, run8 as R8

MODES = {"1a": "ورودِ ۰.۶۱۸ · فقط MA200ِ 1h", "1b": "ورودِ ۰.۶۱۸ · MA200ِ 1h + فیلترهایِ قفل‌شده", "2": "کراسِ MA5/MA20 در محدوده‌یِ ۰.۵–۰.۷۸۶ · بدونِ فیلتر"}
BAD = [4, 5, 6, 7, 16, 17, 18, 19]


def pick(E, mode, sl):
    g = lambda c: E.get(c, pd.Series(False, index=E.index)).fillna(False).astype(bool)
    known = E.get("1h ورود بالایِ MA200", pd.Series(np.nan, index=E.index)).notna()
    d = E[(E["وضعیت"] == "ورود") & (E["sl"] == sl)]
    if mode == "2":
        d = d[d["ورود_حالت"] == "ma_zone"]
    else:
        d = d[d["ورود_حالت"] == "direct"]
        lng = (d["جهت"] == "لانگ") & g("1h ورود بالایِ MA200").loc[d.index]
        sht = (d["جهت"] == "شورت") & known.loc[d.index] & ~g("1h ورود بالایِ MA200").loc[d.index]
        if mode == "1b":
            lng &= g("tf هم‌جهتیِ صعودی").loc[d.index] & ~g("tf واگراییِ منفی").loc[d.index]
            sht &= g("tf هم‌جهتیِ نزولی").loc[d.index] & ~g("tf واگراییِ مثبت").loc[d.index]
            ok = (d["SL٪"] >= 3) & ~d["ساعت"].isin(BAD)
            lng &= ok; sht &= ok
        d = d[lng | sht]
    d = d[d["$ single"].notna()].copy()
    d["خروج_ms"] = d["زمانِ ورود"] + (d["مدت single"] * 3.6e6).astype("int64")
    return d.sort_values("زمانِ ورود").reset_index(drop=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbols", default=R8.SYMBOLS); ap.add_argument("--days", type=float, default=30)
    ap.add_argument("--pivots", default="10,20,30,40,50")
    ap.add_argument("--capital", type=float, default=500); ap.add_argument("--margin", type=float, default=20); ap.add_argument("--lev", type=float, default=10)
    ap.add_argument("--cache", default="/content/fr_cache"); ap.add_argument("--out", default="/content/fr12_results")
    a = ap.parse_args()
    R8.CFG.update(capital=a.capital, margin=a.margin, lev=a.lev)
    os.makedirs(os.path.join(a.out, "events"), exist_ok=True)
    end = int(time.time() * 1000) // 3_600_000 * 3_600_000
    start = end - int(a.days * 86_400_000)
    pivs = [int(x) for x in a.pivots.split(",")]
    import ccxt
    ex = ccxt.okx({"enableRateLimit": True})
    allE = {n: [] for n in pivs}
    for sym in [s.strip().upper() for s in a.symbols.split(",") if s.strip()]:
        todo = [n for n in pivs if not os.path.exists(os.path.join(a.out, "events", f"{sym}_p{n}.csv.gz"))]
        if todo:
            try:
                d5 = FR.fetch(ex, sym, "5m", start - 10 * 86_400_000, end, a.cache)
                d1 = FR.fetch(ex, sym, "1h", start - 15 * 86_400_000, end, a.cache)
            except Exception as e:                                          # noqa: BLE001
                print(f"  {sym}: داده نیومد ({e})", flush=True); continue
            if len(d5) < 3000 or len(d1) < 250:
                print(f"  {sym}: داده‌یِ کافی نیست", flush=True); continue
            F5, F1 = FR.Frame(d5, "5m"), FR.Frame(d1, "1h")
            c5, c1 = F7.m15_context(F5), F7.m1h_context(F1)
            for n in todo:
                ev = pd.DataFrame(F7.events7(F5, F5, c5, n, R8.CFG, sym, "origin", ["direct", "ma_zone"], ["single"], ["sl1", "sl05"], gap="market", ctx1h=c1, ctx_tf=F7.m1h_context(F5)))
                ev = ev[ev["تأییدِ موج"] >= start] if len(ev) else ev
                ev.to_csv(os.path.join(a.out, "events", f"{sym}_p{n}.csv.gz"), index=False, compression="gzip")
            print(f"💾 {sym}", flush=True)
        for n in pivs:
            p = os.path.join(a.out, "events", f"{sym}_p{n}.csv.gz")
            if os.path.exists(p) and os.path.getsize(p) > 50:
                x = pd.read_csv(p)
                if len(x):
                    allE[n].append(x)
    rows, files = [], []
    for n, parts in allE.items():
        if not parts:
            continue
        E = pd.concat(parts, ignore_index=True)
        for mode in MODES:
            for sl in ("sl1", "sl05"):
                d = pick(E, mode, sl)
                if not len(d):
                    rows.append({"حالت": mode, "پیووت": n, "SL": sl, "معاملات": 0}); continue
                taken, C, mx = R8.portfolio(d, a.capital, a.margin)
                t = d[taken]; u = t["$ single"]
                eqv = C["سرمایه"].to_numpy() if len(C) else np.array([a.capital])
                dd = float((eqv - np.maximum.accumulate(np.r_[a.capital, eqv])[1:]).min()) if len(C) else 0.0
                sd = {k: (len(v), round(v.sum(), 1)) for k, v in t.groupby("جهت")["$ single"]}
                rows.append({"حالت": mode, "پیووت": n, "SL": sl, "ستاپ": len(d), "معاملات": len(t), "برد": int((u > 0).sum()), "باخت": int((u <= 0).sum()),
                             "برد٪": round(100 * (u > 0).mean(), 1), "میانگین $": round(u.mean(), 2), "خالص $": round(u.sum(), 1), "سرمایه $": round(a.capital + u.sum(), 1),
                             "افت $": round(dd, 1), "لانگ": sd.get("لانگ", (0, 0)), "شورت": sd.get("شورت", (0, 0)), "هم‌زمان": mx,
                             "خروج": t["خروج single"].value_counts().to_dict()})
                t.to_csv(os.path.join(a.out, f"v12_trades_{mode}_p{n}_{sl}.csv"), index=False, encoding="utf-8-sig")
    T = pd.DataFrame(rows)
    T.to_csv(os.path.join(a.out, "v12_summary.csv"), index=False, encoding="utf-8-sig")
    ts = lambda ms: pd.Timestamp(int(ms), unit="ms").strftime("%Y-%m-%d")
    txt = [f"# v12 — 5m · {ts(start)} تا {ts(end)} · ۲۹ نماد · ${a.capital:g} مشترک · ${a.margin:g} × {a.lev:g}", "",
           "فیبو، ورود و مسیرِ قیمت رویِ 5m · موجِ شروعِ کلِ حرکت · TP سطحِ ۰ +۱٪ · SL سطحِ ۱ (sl1) یا ۰.۵٪ بازتر (sl05) · لانگ و شورت", ""]
    for mode, nm in MODES.items():
        txt += [f"## حالتِ {mode}: {nm}", T[T["حالت"] == mode].drop(columns="حالت").to_string(index=False), ""]
    open(os.path.join(a.out, "v12_report.md"), "w", encoding="utf-8").write("\n".join(txt))
    print("\n".join(txt))


if __name__ == "__main__":
    main()
