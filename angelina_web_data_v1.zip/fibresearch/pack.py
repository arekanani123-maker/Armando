# -*- coding: utf-8 -*-
"""بسته‌یِ داده برایِ Angelina Web (.fpk): gzip( [طولِ هدر uint32][هدرِ JSON][بلوک‌ها] ) · هر سری: زمان (ثانیه، uint32) + O,H,L,C (float32)."""
import gzip, json, struct
import numpy as np, pandas as pd


def write_pack(path, series, meta=None):
    """series: لیستِ (نماد، تایم، دیتافریم با ستون‌هایِ t(ms), open, high, low, close)."""
    blocks, heads, off = [], [], 0
    for sym, tf, d in series:
        n = len(d)
        b = (np.asarray(d["t"].to_numpy() // 1000, dtype="<u4").tobytes() +
             b"".join(np.asarray(d[c].to_numpy(), dtype="<f4").tobytes() for c in ("open", "high", "low", "close")))
        heads.append({"sym": sym, "tf": tf, "n": int(n), "offset": off, "from": int(d["t"].iloc[0]) if n else 0, "to": int(d["t"].iloc[-1]) if n else 0})
        blocks.append(b); off += len(b)
    head = json.dumps({"version": 1, "meta": meta or {}, "series": heads}, ensure_ascii=False).encode("utf-8")
    with gzip.open(path, "wb", compresslevel=6) as f:
        f.write(struct.pack("<I", len(head))); f.write(head)
        for b in blocks:
            f.write(b)


def read_pack(path):
    raw = gzip.open(path, "rb").read()
    hl = struct.unpack("<I", raw[:4])[0]; head = json.loads(raw[4:4 + hl]); base = 4 + hl
    out = {}
    for s in head["series"]:
        n, o = s["n"], base + s["offset"]
        t = np.frombuffer(raw, "<u4", n, o).astype(np.int64) * 1000
        cols = [np.frombuffer(raw, "<f4", n, o + 4 * n * (k + 1)).astype(np.float64) for k in range(4)]
        out.setdefault(s["sym"], {})[s["tf"]] = pd.DataFrame({"t": t, "open": cols[0], "high": cols[1], "low": cols[2], "close": cols[3], "volume": 1.0})
    return head, out
