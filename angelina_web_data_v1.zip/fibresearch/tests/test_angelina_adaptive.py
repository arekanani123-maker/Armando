# -*- coding: utf-8 -*-
import os, sys, tempfile
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import angelina_adaptive as AA, run_angelina as A
ok = []
def chk(n, c): ok.append(bool(c)); print(("✅" if c else "❌"), n)
DAY = 86_400_000
rng = np.random.default_rng(1)
n = 900
t0 = int(pd.Timestamp("2020-01-01").value // 10**6)
T = pd.DataFrame({"نماد": rng.choice(["X", "Y", "Z"], n), "جهت": rng.choice(["لانگ", "شورت"], n),
                  "زمانِ ورود": np.sort(t0 + rng.integers(0, 1500, n) * DAY), "SL٪": rng.uniform(1, 9, n), "ساعت": rng.integers(0, 24, n),
                  "سنِ چرخه‌یِ روزانه": rng.uniform(0, 400, n), "تأییدِ موج": 0})
for tf in ("15m", "1h", "4h", "1d"):
    for mo in ("موج", "ورود"):
        for k in ("قیمت", "شیب"):
            T[f"{tf}|{mo}|{k}"] = rng.choice([1.0, -1.0], n)
good = (T["4h|ورود|قیمت"] == 1)                                            # امضایِ خوب: 4h هم‌جهت
T["R single"] = np.where(rng.random(n) < np.where(good, .65, .25), 1.5, -1.0)
T["$ single"] = T["R single"] * 10
T["خروج_ms"] = T["زمانِ ورود"] + 3 * DAY; T["تأییدِ موج"] = T["زمانِ ورود"] - DAY
sel = AA.walk_forward(T, "rules", "all")
chk(f"جدولِ قانون امضایِ خوب رو یاد گرفت: از معاملاتِ انتخاب‌شده {100 * (sel['4h|ورود|قیمت'] == 1).mean():.0f}% با 4h هم‌جهت", (sel["4h|ورود|قیمت"] == 1).mean() > .85)
selm = AA.walk_forward(T, "ml", "all")
chk(f"یادگیریِ ماشین هم یاد گرفت: {100 * (selm['4h|ورود|قیمت'] == 1).mean():.0f}% هم‌جهت · برد٪ انتخاب‌شده‌ها {100 * (selm['R single'] > 0).mean():.0f} در مقابلِ همه {100 * (T['R single'] > 0).mean():.0f}",
    (selm["4h|ورود|قیمت"] == 1).mean() > .7 and (selm["R single"] > 0).mean() > (T["R single"] > 0).mean())
T2 = T.copy(); mid = int(pd.Timestamp("2022-06-01").value // 10**6)
late = T2["زمانِ ورود"] >= mid
T2.loc[late, "R single"] = -T2.loc[late, "R single"]; T2.loc[late, "خروج_ms"] = T2.loc[late, "زمانِ ورود"] + 3 * DAY
a = AA.walk_forward(T, "rules", "all"); b = AA.walk_forward(T2, "rules", "all")
early = lambda s: set(s.loc[s["زمانِ ورود"] < mid, "زمانِ ورود"].tolist())
chk("بدونِ نگاه به آینده: عوض کردنِ نتیجه‌یِ معاملاتِ بعد از ژوئنِ ۲۰۲۲ تصمیم‌هایِ قبلش رو عوض نمی‌کنه", early(a) == early(b))
T3 = T.copy(); i = T3.index[T3["زمانِ ورود"] >= int(pd.Timestamp("2021-06-10").value // 10**6)][0]
T3.loc[i, "خروج_ms"] = int(pd.Timestamp("2021-08-15").value // 10**6)
tr = T3[T3["خروج_ms"] < int(pd.Timestamp("2021-07-01").value // 10**6)]
chk("معامله‌ای که هنوز باز بوده (خروج بعد از شروعِ ماه) در یادگیریِ اون ماه نیست", i not in tr.index)
out = tempfile.mkdtemp(); AA.report(T, A.lock(), out)
rep = open(os.path.join(out, "angelina_adaptive_report.md"), encoding="utf-8").read()
chk("گزارش: ۵ نسخه، جدولِ قانونِ فعلی و مدلِ فعلی ذخیره شد", rep.count("یادگیریِ ماشین") >= 2 and os.path.exists(os.path.join(out, "angelina_adaptive_rules.json")) and os.path.exists(os.path.join(out, "angelina_adaptive_ml.pkl")))
print(f"\nنتیجه: {sum(ok)} از {len(ok)} تست موفق"); sys.exit(0 if all(ok) else 1)
