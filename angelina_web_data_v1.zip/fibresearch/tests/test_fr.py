# -*- coding: utf-8 -*-
import os, sys, types
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import fr as FR, run as RUN
ok = []
def chk(n, c): ok.append(bool(c)); print(("✅" if c else "❌"), n)
M5 = 300_000
def frame(H, L, tf, t0=0, C=None):
    H, L = np.asarray(H, float), np.asarray(L, float); C = (H + L) / 2 if C is None else np.asarray(C, float)
    d = pd.DataFrame({"t": t0 + np.arange(len(H), dtype=np.int64) * FR.TF_MS[tf], "open": C, "high": np.maximum(H, C), "low": np.minimum(L, C), "close": C, "volume": 1.0})
    return FR.Frame(d, tf)
chk("Fib: موجِ صعودیِ ۱۰۰→۲۰۰: ۰.۶۱۸ = ۱۳۸.۲، ۰ = ۲۰۰، ۱ = ۱۰۰", abs(FR.fib(100, 200, .618) - 138.2) < 1e-9 and FR.fib(100, 200, 0) == 200 and FR.fib(100, 200, 1) == 100)
chk("Fib: موجِ نزولیِ ۲۰۰→۱۰۰: ۰.۶۱۸ = ۱۶۱.۸", abs(FR.fib(200, 100, .618) - 161.8) < 1e-9)
H = [120,115,110,105,130,150,170,190,200,190,170,150,139,160,185,201,195,190,185,180]
L = [110,105,102,100,110,140,160,180,190,180,160,140,137,150,170,190,185,180,175,170]
F = frame(H, L, "15m")
W = [w for w in FR.waves(F, 3) if w[1] == 1]
chk(f"موجِ صعودی: کف ۱۰۰ (کندل ۳)، سقف ۲۰۰ (کندل ۸)، تأیید در کندل ۱۱: {W[0]}", W[0][:4] == (11, 1, 3, 8) and W[0][4:] == (100.0, 200.0))
ctx = {tf: frame([1], [1], tf) for tf in ("5m", "15m", "1h", "4h")}
ev = pd.DataFrame(FR.events(F, None, ctx, 3, {"fee_pct": 0.0, "wait_bars": 500, "max_hold_bars": 5000}, "X"))
r618 = ev[(ev["جهت"] == "لانگ") & (ev["سطح"] == 0.618)].iloc[0]
chk(f"رویداد ۰.۶۱۸: ورود در کندلِ ۱۲، TP ({r618['نتیجه']})، سود = ۰.۶۱۸/۰.۳۸۲ R", r618["نتیجه"] == "TP" and abs(r618["سود R (خالص)"] - .618 / .382) < 1e-9
    and r618["زمانِ ورود"] == 12 * 900_000)
r786 = ev[(ev["جهت"] == "لانگ") & (ev["سطح"] == 0.786)].iloc[0]
chk(f"۰.۷۸۶ (۱۲۱.۴): قیمت تا ۱۳۷ اومد ← لمس نشد، بعد سقف شکست ← لغو ({r786['وضعیت']})", r786["وضعیت"] == "لغو (شکستِ سطحِ ۰)")
chk("برگشتِ موفقِ 1R برایِ ۰.۶۱۸ (ورود ۱۳۸.۲، R=۳۸.۲، 1R=۱۷۶.۴ قبل از SL)", r618["برگشتِ موفق 1.0R"] == 1.0)
# کندلی که هم TP هم SL رو لمس می‌کنه ← 5m
Hc = H[:13] + [139, 205]; Lc = L[:13] + [150, 95]
F2 = frame(Hc, Lc, "15m")
fine_up = frame(np.r_[np.full(14 * 3, 150), [160, 206, 150]], np.r_[np.full(14 * 3, 140), [150, 190, 94]], "5m")      # کندلِ ۱۴ در 5m: اول TP بعد SL
e2 = pd.DataFrame(FR.events(F2, fine_up, ctx, 3, {"fee_pct": 0, "wait_bars": 500, "max_hold_bars": 5000}, "X"))
x = e2[(e2["جهت"] == "لانگ") & (e2["سطح"] == 0.618)].iloc[0]
chk(f"TP و SL در یه کندلِ 15m ← 5m نشون میده TP اول بوده: {x['نتیجه']}", x["نتیجه"] == "TP")
e3 = pd.DataFrame(FR.events(F2, None, ctx, 3, {"fee_pct": 0, "wait_bars": 500, "max_hold_bars": 5000}, "X"))
chk(f"بدونِ دیتایِ 5m ← مبهم (ترتیبی فرض نمیشه): {e3[(e3['جهت'] == 'لانگ') & (e3['سطح'] == 0.618)].iloc[0]['نتیجه']}",
    e3[(e3["جهت"] == "لانگ") & (e3["سطح"] == 0.618)].iloc[0]["نتیجه"] == "مبهم")
# بعد از SL: برگشت به TPِ اولیه (لانگ: TP بالایِ قیمت)
fine = frame(np.r_[100, 95, 150, 205], np.r_[90, 85, 120, 180], "5m")
a = FR.after(fine, 0, -1, 100, 10, tp0=200, trade_side=1)
chk(f"بعد از SLِ لانگ: ادامه‌یِ ریزش تا ۸۵ (۱۵٪) و برگشت به TPِ ۲۰۰ در کندلِ ۳ ({a['رسیدن به TPِ اولیه در ۷۲ ساعت']}, {a['زمان تا TPِ اولیه (ساعت)']:.2f}h)",
    abs(a["۱ ساعت: ادامه٪"] - 15) < 1e-9 and a["رسیدن به TPِ اولیه در ۷۲ ساعت"] and abs(a["زمان تا TPِ اولیه (ساعت)"] - 0.25) < 1e-9)
# MA200 فقط از کندلِ بسته‌شده
F4 = frame(np.linspace(100, 300, 400), np.linspace(99, 299, 400), "4h")
st, _ = F4.state(np.array([F4.ct[250] - 1, F4.ct[250]]))
chk("MA200: کندلِ ۲۵۰ فقط از لحظه‌یِ بسته‌شدنش حساب میشه", st[0] == 1 and st[1] == 1 and F4.closed_idx(F4.ct[250] - 1) == 249)
# بدونِ نگاه به آینده
r = np.random.default_rng(1); c = 100 * np.exp(np.cumsum(r.normal(0, .004, 3000)))
Fa = frame(c * 1.002, c * .998, "15m", C=c); Fb = frame(c[:2000] * 1.002, c[:2000] * .998, "15m", C=c[:2000])
cfg = {"fee_pct": .05, "wait_bars": 200, "max_hold_bars": 300}
A = pd.DataFrame(FR.events(Fa, None, ctx, 5, cfg, "X")); B = pd.DataFrame(FR.events(Fb, None, ctx, 5, cfg, "X"))
key = ["جهت", "سطح", "تأییدِ موج"]
A2 = A[A["تأییدِ موج"] < Fb.ct[1999 - 500]].sort_values(key).reset_index(drop=True); B2 = B[B["تأییدِ موج"] < Fb.ct[1999 - 500]].sort_values(key).reset_index(drop=True)
same = len(A2) == len(B2) and (A2[["P1", "P0", "وضعیت", "نتیجه"]].fillna("-").values == B2[["P1", "P0", "وضعیت", "نتیجه"]].fillna("-").values).all()
chk(f"بدونِ نگاه به آینده: موج‌ها، سطوح و نتایجِ تمام‌شده با و بدونِ ۱۰۰۰ کندلِ بعدی یکسان ({len(A2)} رویداد)", same and len(A2) > 20)
# گزارش رویِ دیتایِ ساختگی
A["بخش"] = FR.split_of(A["تأییدِ موج"], 0, Fa.ct[-1]); A["ترکیبِ MA200 (4h/1h/15m)"] = "ص/ص/ص"; A["هم‌جهت با MA200ِ 4h"] = "هم‌جهت"
A["نماد"] = "X"; A["پیووت"] = 5
tmp = "/tmp/fr_test_out"; os.makedirs(tmp, exist_ok=True)
RUN.CFG["min_n"] = 5
RUN.report(A, types.SimpleNamespace(out=tmp), 0, int(Fa.ct[-1]), [], [])
rep = open(os.path.join(tmp, "fib_research_report.md"), encoding="utf-8").read()
chk("گزارش: ۶ بخش + ۱۲ پاسخ ساخته شد", all(f"## گزارشِ {d}" in rep for d in "۱۲۳۴۵۶") and "## پاسخ به ۱۲ سؤال" in rep)
print(f"\nنتیجه: {sum(ok)} از {len(ok)} تست موفق"); sys.exit(0 if all(ok) else 1)
