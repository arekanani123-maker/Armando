# -*- coding: utf-8 -*-
import os, sys, json, shutil, tempfile, subprocess
import numpy as np, pandas as pd
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
import fr as FR, angelina2 as A2
ok = []
def chk(n, c): ok.append(bool(c)); print(("✅" if c else "❌"), n)
c = A2.lock2()
chk(f"قفلِ Angelina2: MA200 {c['side_ma200_tf']} · واگرایی {c['div_tf']} · قوی: اختلاف ≥{c['strong_rsi_diff']} و <{c['strong_rsi_long']}/>{c['strong_rsi_short']}", c["div_tf"] == "4h" and c["strong_rsi_diff"] == 5.0)
tmp = tempfile.mkdtemp(); shutil.copytree(ROOT, os.path.join(tmp, "x"), ignore=shutil.ignore_patterns("__pycache__"))
cf = os.path.join(tmp, "x", "angelina2.json"); j = json.load(open(cf)); j["strong_rsi_diff"] = 2.0; json.dump(j, open(cf, "w"))
r = subprocess.run([sys.executable, os.path.join(tmp, "x", "angelina2.py")], capture_output=True, text=True)
chk("تغییرِ قفلِ Angelina2 ← اجرا نمیشه", r.returncode != 0 and "تغییر کرده" in (r.stdout + r.stderr))
# واگراییِ قویِ مثبت: کفِ دوم پایین‌تر، RSIِ دوم ≥ ۵ واحد بالاتر، RSIِ کفِ اول < ۳۰
x = np.r_[np.linspace(200, 100, 40), [104, 108, 106, 103], np.linspace(103, 99, 4), np.linspace(99, 140, 30)]
H, L = x * 1.001, x * .999
L[39] = 99.5; L[47] = 98.0
F = FR.Frame(pd.DataFrame({"t": np.arange(len(x), dtype=np.int64) * FR.TF_MS["4h"], "open": x, "high": H, "low": L, "close": x, "volume": 1.0}), "4h")
fl = A2.div_flags(F, c)
import fr2 as F2
r_ = F2.rsi(x)
ph, pl = FR.pivots(H, L, 3)
print("   پیووت‌هایِ کف:", pl, "· RSI در اون‌ها:", [round(r_[p], 1) for p in pl])
strong_expected = any(L[b] < L[a] and r_[b] - r_[a] >= 5 and r_[a] < 30 and 5 <= b - a <= 60 for a, b in zip(pl, pl[1:]))
chk(f"واگراییِ قویِ مثبت مطابقِ تعریف پیدا شد ({strong_expected}) ← پرچم {bool(fl['bull_strong'].any())}", fl["bull_strong"].any() == strong_expected)
E = pd.DataFrame({"وضعیت": ["ورود"] * 4 + ["شکاف"], "سمتِ درست 4h": [1.0, 0.0, 0.0, np.nan, np.nan], "واگراییِ 4h": [False, True, False, True, False]})
s = A2.select(E, "4h")
chk(f"انتخاب: سمتِ درست ← ورود · سمتِ غلط با واگرایی ← ورود · سمتِ غلط بدونِ واگرایی ← حذف · نامعلوم ← حذف ({list(s.index)})", list(s.index) == [0, 1, 4])
print(f"\nنتیجه: {sum(ok)} از {len(ok)} تست موفق"); sys.exit(0 if all(ok) else 1)
