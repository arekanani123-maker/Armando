# -*- coding: utf-8 -*-
import os, sys, tempfile
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import fr as FR, fr7 as F7, run8 as R8, studio as S, angelina_exit as AX, angelina2 as A2
ok = []
def chk(n, c): ok.append(bool(c)); print(("✅" if c else "❌"), n)
r = np.random.default_rng(12); n5 = 48 * 900
c = 100 * np.exp(np.cumsum(r.normal(0, .0025, n5)))
F5 = FR.Frame(pd.DataFrame({"t": np.arange(n5, dtype=np.int64) * 300_000, "open": c, "high": c * 1.0015, "low": c * .9985, "close": c, "volume": 1.0}), "5m")
d = pd.DataFrame({"t": F5.t, "open": c, "high": c * 1.0015, "low": c * .9985, "close": c}); d["k"] = d["t"] // FR.TF_MS["4h"]
g = d.groupby("k").agg(t=("t", "first"), open=("open", "first"), high=("high", "max"), low=("low", "min"), close=("close", "last")).reset_index(drop=True); g["volume"] = 1.0
F4 = FR.Frame(g, "4h")
cfg = dict(S.DEFAULT, symbols=["X"], pivot=5)
data = {"X": {"4h": F4, "5m": F5}}
E = S.events(cfg, data, 0)
R8.CFG.update(capital=500, margin=20, lev=10, fee_pct=0.05)
ref = pd.DataFrame(F7.events7(F4, F5, {}, 5, R8.CFG, "X", "bos", ["direct"], ["single"], ["sl1"], gap="market"))
a = E[E["وضعیت"] == "ورود"][["تأییدِ موج", "زمانِ ورود", "ورود", "$ single"]].reset_index(drop=True)
b = ref[ref["وضعیت"] == "ورود"][["تأییدِ موج", "زمانِ ورود", "ورود", "$ single"]].reset_index(drop=True)
chk(f"پیش‌فرض‌ها = Angelina: همون ورودها و سودِ تک‌تک معاملات ({len(a)} معامله)", len(a) > 5 and len(a) == len(b) and np.allclose(a.values, b.values))
c2 = A2.lock2(); fl = A2.div_flags(F4, c2)
cfgN = dict(cfg, sl_pad_pct=0.09, be_after=2, div_tf="4h",
            targets=[{"kind": "level", "value": 0.0, "frac": 50}, {"kind": "ext", "value": 1.618, "frac": 20}, {"kind": "div", "value": 0, "frac": 30}])
EN = S.events(cfgN, data, 0); EN = EN[EN["وضعیت"] == "ورود"].reset_index(drop=True)
same = True
for _, rr in EN.iterrows():
    side = 1 if rr["جهت"] == "لانگ" else -1
    parts, net = AX.sim_multi(F5, F4, fl["bear_strong" if side == 1 else "bull_strong"], int(rr["زمانِ ورود"]), side, rr["ورود"], rr["P1"], rr["P0"], 0.05)
    same &= abs(net * 200 - rr["$ single"]) < 1e-6 and "+".join(p[2] for p in parts).replace("TP3 واگرایی", "TP3 واگرایی") == rr["خروج single"]
chk(f"خروجِ ۵۰/۲۰/۳۰ (SL +۰.۰۹٪، SL به ورود بعد از TP2، TP3 واگرایی) = angelina_exit برایِ همه‌یِ {len(EN)} معامله", same and len(EN) > 5)
chk("سطحِ لگاریتمی: موجِ ۱۰۰→۲۰۰، سطحِ ۰.۶۱۸ = ۲۰۰ × ۰.۵^۰.۶۱۸", abs(S.level(100, 200, 0.618, True) - 200 * 0.5 ** 0.618) < 1e-9)
cfgL = dict(cfg, sides="long"); EL = S.events(cfgL, data, 0)
chk("جهت = فقط لانگ ← هیچ شورتی", (EL["جهت"] == "لانگ").all())
cfgF = dict(cfg, min_sl_pct=50.0); EF = S.events(cfgF, data, 0)
chk("فیلترِ حداقلِ SL ۵۰٪ ← هیچ ورودی، همه «فیلتر: حداقلِ SL» یا وضعیتِ قبل از ورود", (EF["وضعیت"] != "ورود").all() and (EF["وضعیت"] == "فیلتر: حداقلِ SL").any())
out = tempfile.mkdtemp()
txt = S.report(cfg, E, 0, int(F5.ct[-1]), out)
chk("گزارش + settings.json + trades.csv", "## نتیجه" in txt and os.path.exists(os.path.join(out, "settings.json")) and os.path.exists(os.path.join(out, "trades.csv")))
tk, mx = S.portfolio(pd.DataFrame({"نماد": ["A", "B", "C"], "زمانِ ورود": [0, 1, 2], "خروج_ms": [10, 10, 10], "$ single": [1.0, 1.0, 1.0]}), 500, 20, max_pos=2)
chk("حداکثر پوزیشنِ هم‌زمان = ۲ ← سومی رد", tk.tolist() == [True, True, False])
chk("اکستنشنِ ۱.۶۱۸ برایِ موجِ ۱۰۰→۲۰۰ = ۲۶۱.۸ · اکستنشنِ ۱.۲۷ = ۲۲۷", abs(S.target_price({"kind": "ext", "value": 1.618}, 100, 200, 1, False) - 261.8) < 1e-9
    and abs(S.target_price({"kind": "ext", "value": 1.27}, 100, 200, 1, False) - 227) < 1e-9)
Eb = S.events(dict(cfg, targets=[{"kind": "level", "value": 1.5, "frac": 100}]), data, 0)
chk("تارگتِ اشتباه در سمتِ ضرر (سطحِ ۱.۵) ← هیچ معامله‌ای با اون تارگت باز نمیشه", (Eb["وضعیت"] != "ورود").all() and (Eb["وضعیت"] == "تارگت در سمتِ ضرر").any())
print(f"\nنتیجه: {sum(ok)} از {len(ok)} تست موفق"); sys.exit(0 if all(ok) else 1)
