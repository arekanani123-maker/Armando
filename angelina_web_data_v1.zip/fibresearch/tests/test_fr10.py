# -*- coding: utf-8 -*-
import os, sys
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import fr as FR, fr7 as F7, run10 as R10
ok = []
def chk(n, c): ok.append(bool(c)); print(("✅" if c else "❌"), n)
def frm(H, L, C):
    return FR.Frame(pd.DataFrame({"t": np.arange(len(H), dtype=np.int64) * 300_000, "open": C, "high": H, "low": L, "close": C, "volume": 1.0}), "5m")
F = frm([160, 151, 148, 147, 150, 152], [152, 148, 140, 139, 144, 149], [155, 149, 141, 140, 147, 151])
ctx = {"xu": np.array([1, 0, 0, 0, 1, 1], bool), "xd": np.zeros(6, bool)}
z = (150.0, 121.4)
e = F7.find_entry(F, ctx, "ma_zone", 1, 138.2, 100, 200, 0, 6, zone=z)
chk(f"کراس در کندلِ ۰ قبل از رسیدن به محدوده نادیده · کراس در کندلِ ۴ با کلوزِ ۱۴۷ (بینِ ۱۲۱.۴ و ۱۵۰) ← ورود: {e}", e[:2] == (4, 147.0))
ctx2 = {"xu": np.array([0, 0, 0, 0, 0, 1], bool), "xd": np.zeros(6, bool)}
chk(f"کراس با کلوزِ ۱۵۱ (بالایِ ۰.۵) ← ورود نیست: {F7.find_entry(F, ctx2, 'ma_zone', 1, 138.2, 100, 200, 0, 6, zone=z)[2]}", F7.find_entry(F, ctx2, "ma_zone", 1, 138.2, 100, 200, 0, 6, zone=z)[2] == "تأیید نیومد")
base = {"وضعیت": "ورود", "sl": "sl1", "$ single": 1.0, "زمانِ ورود": 0, "مدت single": 1.0}
E = pd.DataFrame([{**base, "ورود_حالت": "direct", "جهت": "لانگ", "SL٪": 2.0, "ساعت": 10, "1h ورود بالایِ MA200": True, "tf هم‌جهتیِ صعودی": True, "tf واگراییِ منفی": False},
                  {**base, "ورود_حالت": "direct", "جهت": "لانگ", "SL٪": 4.0, "ساعت": 10, "1h ورود بالایِ MA200": True, "tf هم‌جهتیِ صعودی": True, "tf واگراییِ منفی": False},
                  {**base, "ورود_حالت": "direct", "جهت": "شورت", "SL٪": 4.0, "ساعت": 5, "1h ورود بالایِ MA200": False, "tf هم‌جهتیِ نزولی": True, "tf واگراییِ مثبت": False},
                  {**base, "ورود_حالت": "direct", "جهت": "لانگ", "SL٪": 4.0, "ساعت": 10, "1h ورود بالایِ MA200": False},
                  {**base, "ورود_حالت": "ma_zone", "جهت": "شورت", "SL٪": 1.0, "ساعت": 5, "1h ورود بالایِ MA200": True}])
n1a, n1b, n2 = len(R10.pick(E, "1a", "sl1")), len(R10.pick(E, "1b", "sl1")), len(R10.pick(E, "2", "sl1"))
chk(f"1a: لانگ‌هایِ بالایِ MA200 (۲) + شورتِ زیرِ MA200 (۱) = ۳ · 1b: فقط لانگِ با SL ۴٪ (شورت ساعتِ ۵ رد) = ۱ · 2: فقط ma_zone = ۱ ({n1a}, {n1b}, {n2})", (n1a, n1b, n2) == (3, 1, 1))
print(f"\nنتیجه: {sum(ok)} از {len(ok)} تست موفق"); sys.exit(0 if all(ok) else 1)
