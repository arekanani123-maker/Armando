# -*- coding: utf-8 -*-
import os, sys, types
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import fr as FR, fr7 as F7, run8 as R8, run11 as R11
ok = []
def chk(n, c): ok.append(bool(c)); print(("✅" if c else "❌"), n)
def frm(H, L, C, tf="5m"):
    return FR.Frame(pd.DataFrame({"t": np.arange(len(H), dtype=np.int64) * FR.TF_MS[tf], "open": C, "high": H, "low": L, "close": C, "volume": 1.0}), tf)
H = [110,120,130,125,118,122,126,124,120,128,135,140,138,130,125,120,118]
L = [100,115,125,118,112,118,121,119,114,122,130,136,132,125,120,115,112]
C = [(h + l) / 2 for h, l in zip(H, L)]
F = frm(H, L, C)
b = [w for w in FR.waves(F, 2, "bos") if w[1] == 1]
o = [w for w in FR.waves(F, 2, "between") if w[1] == 1]
chk(f"B: سقفِ ۱۲۶ (کندل ۶) سقفِ قبلی ۱۳۰ رو نشکسته ← موج نیست · سقفِ ۱۴۰ (کندل ۱۱) با کلوزِ بالایِ ۱۳۰ ← موج: {[(w[3], w[4], w[5]) for w in b]}",
    [w[3] for w in b] == [11] and 6 in [w[3] for w in o])
bf = F7.bos_flags(F, [2])
chk(f"شکستِ پیووتِ 5m: اولین کلوزِ بالایِ ۱۳۰ (سقفِ پیووتِ کندلِ ۲، تأیید در ۴) در کندلِ ۱۰: {int(np.argmax(bf['bosu_2']))}", int(np.argmax(bf["bosu_2"])) == 10)
F2 = frm(H[:12], L[:12], C[:12]); b2 = F7.bos_flags(F2, [2])
chk("بدونِ نگاه به آینده: پرچمِ شکست با و بدونِ کندل‌هایِ بعدی یکسان", (b2["bosu_2"] == bf["bosu_2"][:12]).all())
G = frm([141, 201, 205], [139, 150, 190], [140, 195, 200])
p0 = F7.simulate_exit(G, 0, 1, 140.0, 100.0, [200.0], [1.0], 10)
chk(f"خروج در سطحِ ۰ (۲۰۰) در کندلِ ۱: {[(f, px, l) for f, px, l, _ in p0]}", [(f, px, l) for f, px, l, _ in p0] == [(1.0, 200.0, "TP1")])
r = np.random.default_rng(9); c = 100 * np.exp(np.cumsum(r.normal(0, .002, 6000)))
F5 = FR.Frame(pd.DataFrame({"t": np.arange(6000, dtype=np.int64) * 300_000, "open": c, "high": c * 1.001, "low": c * .999, "close": c, "volume": 1.0}), "5m")
c5 = F7.m15_context(F5); c5.update(F7.bos_flags(F5, [5, 10]))
rows = []
for m, wm in R11.METHODS.items():
    rows += [dict(x, روش=m, محدوده="5m p5") for x in F7.events7(F5, F5, c5, 5, R8.CFG, "X", wm, ["direct"], ["single0", "single"], ["sl1"], gap="market")]
    rows += [dict(x, روش=m, محدوده="5m p10b") for x in F7.events7(F5, F5, c5, 10, R8.CFG, "X", wm, ["bos5_5"], ["single0", "single"], ["sl1"], gap="market")]
E = pd.DataFrame(rows); E["نماد"] = "X"
out = "/tmp/fr13_test"; os.makedirs(out, exist_ok=True)
R11.report(E, types.SimpleNamespace(out=out, capital=500, margin=20, lev=10), 0, int(F5.ct[-1]))
T = pd.read_csv(os.path.join(out, "v13_all.csv"))
chk(f"گزارش: هر سه روش جدا، PF و Max DD حساب شد ({sorted(T['روش'].unique())}، {len(T)} ردیف)", sorted(T["روش"].unique()) == ["A", "B", "C"] and {"PF", "Max DD $"} <= set(T.columns))
print(f"\nنتیجه: {sum(ok)} از {len(ok)} تست موفق"); sys.exit(0 if all(ok) else 1)
