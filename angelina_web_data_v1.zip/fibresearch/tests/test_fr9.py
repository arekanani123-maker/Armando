# -*- coding: utf-8 -*-
import os, sys, json, shutil, tempfile, subprocess
import numpy as np, pandas as pd
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
import fr as FR, fr7 as F7, run8 as R8, run9 as R9
ok = []
def chk(n, c): ok.append(bool(c)); print(("✅" if c else "❌"), n)
L = R9.load_lock()
chk(f"قفل خونده شد: {L['name']} · فیلتر {L['filter']} · ورود {L['entry_level']} · شکاف {L['gap']}", L["filter"] == "ma_rsi" and L["gap"] == "market")
tmp = tempfile.mkdtemp(); shutil.copytree(ROOT, os.path.join(tmp, "x"), ignore=shutil.ignore_patterns("__pycache__"))
cf = os.path.join(tmp, "x", "strategy_locked.json"); c = json.load(open(cf)); c["min_sl_pct"] = 1.0; json.dump(c, open(cf, "w"))
r = subprocess.run([sys.executable, os.path.join(tmp, "x", "run9.py"), "--days", "1"], capture_output=True, text=True)
chk("تغییرِ فایلِ قفل (حداقلِ SL ۳ ← ۱) ← اجرا نمیشه", r.returncode != 0 and "تغییر کرده" in (r.stdout + r.stderr))
rng = np.random.default_rng(8); cc = 100 * np.exp(np.cumsum(rng.normal(0, .004, 9000)))
F15 = FR.Frame(pd.DataFrame({"t": np.arange(9000, dtype=np.int64) * 900_000, "open": cc, "high": cc * 1.002, "low": cc * .998, "close": cc, "volume": 1.0}), "15m")
d1 = pd.DataFrame({"t": F15.t, "open": cc, "high": cc * 1.002, "low": cc * .998, "close": cc}); d1["k"] = d1["t"] // 3_600_000
g = d1.groupby("k").agg(t=("t", "first"), open=("open", "first"), high=("high", "max"), low=("low", "min"), close=("close", "last")).reset_index(drop=True); g["volume"] = 1.0
F1 = FR.Frame(g, "1h")
R8.CFG.update(min_sl=0.5, bad_hours=[], wave="origin")
L2 = dict(L, min_sl_pct=0.5, bad_hours_utc=[])
ev = {}
for tf, Fw in (("15m", F15), ("1h", F1)):
    ev[(tf, 5)] = [pd.DataFrame(F7.events7(Fw, F15, F7.m15_context(F15), 5, R8.CFG, s, "origin", ["direct"], ["single"], ["sl1", "sl05"], gap="market", ctx1h=F7.m1h_context(Fw))) for s in ("X", "Y")]
out = tempfile.mkdtemp(); R9.report(ev, L2, out, 0, int(F15.ct[-1]))
S = pd.read_csv(os.path.join(out, "v11_summary.csv"))
chk(f"گزارشِ مقایسه: {len(S)} ردیف (۲ تایم × ۱ پیووت × ۲ SL)، با سود، افت، ماهانه، لانگ و شورت", len(S) == 4 and {"خالص $", "بیشترین افت $", "میانگینِ ماهانه $"} <= set(S.columns))
chk("مهلتِ ورود به اندازه‌یِ کندل‌هایِ تایمِ فیبو (15m ← ۱ برابر، 1h ← ۴ برابر)", max(1, FR.TF_MS["15m"] // FR.TF_MS["15m"]) == 1 and FR.TF_MS["1h"] // FR.TF_MS["15m"] == 4)
print(f"\nنتیجه: {sum(ok)} از {len(ok)} تست موفق"); sys.exit(0 if all(ok) else 1)
