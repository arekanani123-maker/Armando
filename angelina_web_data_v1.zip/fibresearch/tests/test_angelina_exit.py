# -*- coding: utf-8 -*-
import os, sys
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import fr as FR, angelina_exit as AX
ok = []
def chk(n, c): ok.append(bool(c)); print(("✅" if c else "❌"), n)
M5, H4 = 300_000, 14_400_000
def f5(H, L, C):
    return FR.Frame(pd.DataFrame({"t": np.arange(len(H), dtype=np.int64) * M5, "open": C, "high": H, "low": L, "close": C, "volume": 1.0}), "5m")
F4 = FR.Frame(pd.DataFrame({"t": np.arange(10, dtype=np.int64) * H4, "open": 250.0, "high": 260.0, "low": 240.0, "close": [250.0 + i for i in range(10)], "volume": 1.0}), "4h")
div = np.zeros(10, bool); div[2] = True                                       # واگرایی در بسته‌شدنِ کندلِ 4hِ شماره‌یِ ۲ (۱۲ ساعت)
lab = lambda p: [(f, round(px, 3), l) for f, px, l, _ in p]
# مسیر: ورود ۱۳۸.۲ · TP1 ۲۰۰ · TP2 ۲۶۱.۸ · بعد بالا می‌مونه تا واگرایی
n = 200
H = np.full(n, 270.0); L = np.full(n, 262.0); C = np.full(n, 265.0)
H[:3] = [139, 201, 202]; L[:3] = [138, 150, 190]; C[:3] = [138.2, 195, 200]
p, net = AX.sim_multi(f5(H, L, C), F4, div, 0, 1, 138.2, 100.0, 200.0, 0.0)
chk(f"TP1 (۵۰٪) → TP2 (۲۰٪) → ۳۰٪ با کلوزِ 4h در واگرایی (۲۵۲): {lab(p)}", lab(p) == [(.5, 200.0, "TP1"), (.2, 261.8, "TP2"), (.3, 252.0, "TP3 واگرایی")])
H2 = H.copy(); L2 = L.copy(); L2[10] = 130.0                                  # بعد از TP2 قیمت به ورود برمی‌گرده قبل از واگرایی
p2, _ = AX.sim_multi(f5(H2, L2, C), F4, div, 0, 1, 138.2, 100.0, 200.0, 0.0)
chk(f"بعد از TP2 برگشت به ورود قبل از واگرایی ← ۳۰٪ در ۱۳۸.۲: {lab(p2)[-1]}", lab(p2)[-1] == (.3, 138.2, "SL در ورود"))
H3 = np.full(n, 160.0); L3 = np.full(n, 150.0); C3 = np.full(n, 155.0)
H3[:3] = [139, 201, 170]; L3[:3] = [138, 150, 99]; C3[:3] = [138.2, 195, 120]
p3, _ = AX.sim_multi(f5(H3, L3, C3), F4, div, 0, 1, 138.2, 100.0, 200.0, 0.0)
chk(f"TP1 بعد SL قبل از TP2 ← ۵۰٪ در SL (۹۹.۹۱ = ۱۰۰ × (۱ − ۰.۰۹٪)): {lab(p3)}", lab(p3) == [(.5, 200.0, "TP1"), (.5, 99.91, "SL")])
H4_ = np.full(n, 140.0); L4 = np.full(n, 99.0); C4 = np.full(n, 120.0); H4_[0], L4[0], C4[0] = 139, 138, 138.2
p4, net4 = AX.sim_multi(f5(H4_, L4, C4), F4, div, 0, 1, 138.2, 100.0, 200.0, 0.0)
chk(f"SL قبل از TP1 ← همه در ۹۹.۹۱، سود {net4 * 100:.2f}٪ از حجم", lab(p4) == [(1.0, 99.91, "SL")] and abs(net4 - (99.91 - 138.2) / 138.2) < 1e-9)
chk(f"سودِ خالصِ مسیرِ اول = ۰.۵×(۲۰۰−۱۳۸.۲) + ۰.۲×(۲۶۱.۸−۱۳۸.۲) + ۰.۳×(۲۵۲−۱۳۸.۲) نسبت به ۱۳۸.۲ = {net:.4f}",
    abs(net - (.5 * 61.8 + .2 * 123.6 + .3 * 113.8) / 138.2) < 1e-9)
print(f"\nنتیجه: {sum(ok)} از {len(ok)} تست موفق"); sys.exit(0 if all(ok) else 1)
