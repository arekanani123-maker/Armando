# -*- coding: utf-8 -*-
import os, sys, tempfile
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import fr as FR, angelina_mtf as M
ok = []
def chk(n, c): ok.append(bool(c)); print(("✅" if c else "❌"), n)
H = 3_600_000
c = np.r_[np.linspace(100, 200, 400), np.linspace(200, 100, 400)]
fr_ = {tf: {"X": FR.Frame(pd.DataFrame({"t": np.arange(len(c), dtype=np.int64) * FR.TF_MS[tf], "open": c, "high": c, "low": c, "close": c, "volume": 1.0}), tf)} for tf in M.TFS}
t = pd.DataFrame({"نماد": ["X", "X"], "جهت": ["لانگ", "شورت"], "$ single": [5.0, -3.0],
                  "تأییدِ موج": [390 * FR.TF_MS["15m"]] * 2, "زمانِ ورود": [395 * FR.TF_MS["15m"]] * 2, "خروج_ms": [700 * FR.TF_MS["15m"]] * 2})
T = M.tag(t, fr_)
chk(f"15m: لانگ در اوجِ روندِ صعودی ← قیمت هم‌جهت در ورود، خلاف در خروج (بعد از ریزش): {T.loc[0, '15m|ورود|قیمت']}, {T.loc[0, '15m|خروج|قیمت']}",
    T.loc[0, "15m|ورود|قیمت"] == 1 and T.loc[0, "15m|خروج|قیمت"] == -1)
chk("شورت قرینه‌یِ لانگ در همون لحظه", T.loc[1, "15m|ورود|قیمت"] == -1 and T.loc[1, "15m|خروج|قیمت"] == 1)
out = tempfile.mkdtemp(); M.report(T, out)
rep = open(os.path.join(out, "angelina_mtf_report.md"), encoding="utf-8").read()
chk("گزارش ساخته شد (۳ لحظه × ۴ تایم، تغییر از ورود تا خروج)", "تغییر از ورود تا خروج" in rep and "موج" in rep)
print(f"\nنتیجه: {sum(ok)} از {len(ok)} تست موفق"); sys.exit(0 if all(ok) else 1)
