# -*- coding: utf-8 -*-
import os, sys
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import angelina_daily as AD
ok = []
def chk(n, c): ok.append(bool(c)); print(("✅" if c else "❌"), n)
DAY = 86_400_000
c = np.r_[np.linspace(100, 200, 300), np.linspace(200, 120, 200)]
D1 = pd.DataFrame({"t": np.arange(len(c), dtype=np.int64) * DAY, "open": c, "high": c * 1.01, "low": c * .99, "close": c, "volume": 1.0})
ctx = {"X": AD.daily_context(D1)}
F = ctx["X"]["F"]
t = pd.DataFrame({"نماد": ["X"] * 4, "جهت": ["لانگ", "شورت", "لانگ", "لانگ"], "$ single": [1.0, -1.0, 2.0, -2.0],
                  "زمانِ ورود": [280 * DAY + 3600_000, 280 * DAY + 3600_000, 480 * DAY + 3600_000, 300 * DAY + 3600_000],
                  "خروج_ms": [285 * DAY, 285 * DAY, 490 * DAY, 400 * DAY]})
T = AD.tag(t, ctx)
chk(f"روزِ ۲۸۰ (روندِ صعودی): لانگ ← قیمت و چرخه هم‌جهت · شورت ← هر دو خلاف: {T.iloc[0][['قیمت/MA200ِ روزانه', 'چرخه‌یِ روزانه']].tolist()} / {T.iloc[1][['قیمت/MA200ِ روزانه', 'چرخه‌یِ روزانه']].tolist()}",
    T.iloc[0]["قیمت/MA200ِ روزانه"] == "هم‌جهت" and T.iloc[0]["چرخه‌یِ روزانه"] == "هم‌جهت" and T.iloc[1]["قیمت/MA200ِ روزانه"] == "خلاف" and T.iloc[1]["چرخه‌یِ روزانه"] == "خلاف")
chk(f"روزِ ۴۸۰ (بعد از ریزش): لانگ ← قیمت زیرِ MA200 = خلاف: {T.iloc[2]['قیمت/MA200ِ روزانه']}", T.iloc[2]["قیمت/MA200ِ روزانه"] == "خلاف")
s = ctx["X"]["sign"]; flip_day = int(np.where((s[1:] != s[:-1]) & (s[1:] != 0) & (s[:-1] != 0))[0][0]) + 1
t2 = t.iloc[[3, 3]].copy(); t2["خروج_ms"] = [(flip_day - 2) * DAY, (flip_day + 5) * DAY]
T2 = AD.tag(t2, ctx)
chk(f"چرخه در روزِ {flip_day} برگشت: لانگی که قبلش بسته شد ← «نه» · لانگی که بعدش بسته شد ← «بله» ({T2['تغییرِ چرخه در معامله'].tolist()})", T2["تغییرِ چرخه در معامله"].tolist() == ["نه", "بله"])
chk("فقط کندلِ روزانه‌یِ بسته‌شده: ورود در ساعتِ ۱ روزِ ۲۸۰ ← کندلِ ۲۷۹", F.closed_idx(np.array([280 * DAY + 3600_000]))[0] == 279)
if os.path.isdir("/tmp/ang_results/events"):
    tr = AD.rebuild("/tmp/ang_results")
    chk(f"بازسازیِ معاملاتِ Angelina: {len(tr)} معامله · ${tr['$ single'].sum():+.1f}", len(tr) > 0)
print(f"\nنتیجه: {sum(ok)} از {len(ok)} تست موفق"); sys.exit(0 if all(ok) else 1)
