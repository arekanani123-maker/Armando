# -*- coding: utf-8 -*-
import os, sys, json, glob, shutil, tempfile, subprocess
import numpy as np, pandas as pd
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
import run_angelina as A
ok = []
def chk(n, c): ok.append(bool(c)); print(("✅" if c else "❌"), n)
L = A.lock()
chk(f"قفل: {L['name']} · {L['fib_tf']} پیووت {L['pivot']} · روش {L['wave_method']} · ورود {L['entry_level']} · بدونِ فیلتر", L["wave_method"] == "bos" and L["pivot"] == 20 and L["filters"] == "none")
tmp = tempfile.mkdtemp(); shutil.copytree(ROOT, os.path.join(tmp, "x"), ignore=shutil.ignore_patterns("__pycache__"))
cf = os.path.join(tmp, "x", "angelina.json"); c = json.load(open(cf)); c["pivot"] = 30; json.dump(c, open(cf, "w"))
r = subprocess.run([sys.executable, os.path.join(tmp, "x", "run_angelina.py")], capture_output=True, text=True)
chk("تغییرِ فایلِ قفل (پیووت ۲۰ ← ۳۰) ← اجرا نمیشه", r.returncode != 0 and "تغییر کرده" in (r.stdout + r.stderr))
s = A.streaks(np.array([1, -1, -1, -1, 2, 3, -1, 4, 5, 6, 7]))
chk(f"رشته‌ها: ۳ باختِ پشتِ‌سرِهم ($‎-3) · ۴ بردِ پشتِ‌سرِهم ($+22) · توزیعِ باخت {s['باخت'][1]}", s["باخت"][0][:2] == (3, -3.0) and s["برد"][0][:2] == (4, 22.0) and s["باخت"][1] == {1: 1, 3: 1})
ev = "/tmp/fr13r/events"
if os.path.isdir(ev):
    E = pd.concat([pd.read_csv(f) for f in glob.glob(ev + "/*.csv.gz") if os.path.getsize(f) > 50], ignore_index=True)
    E = E[(E["روش"] == "B") & (E["محدوده"] == "4h p20") & (E["ورود_حالت"] == "direct")]
    out = tempfile.mkdtemp(); A.report(E, L, out, int(pd.Timestamp("2026-04-20").value // 10**6), int(pd.Timestamp("2026-10-19").value // 10**6))
    rep = open(os.path.join(out, "angelina_report.md"), encoding="utf-8").read()
    chk("بازتولیدِ v13 (روشِ B · 4h p20): ۱۷۷ معامله · +$1,278 · افت ‎-$293 · ۱۱ باختِ متوالی", "معاملات: 177" in rep and "$+1,278" in rep and "$-293" in rep and "ضررِ متوالی: 11" in rep)
print(f"\nنتیجه: {sum(ok)} از {len(ok)} تست موفق"); sys.exit(0 if all(ok) else 1)
