# -*- coding: utf-8 -*-
import os, sys, tempfile
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import fr as FR, fr7 as F7, run7 as R7
ok = []
def chk(n, c): ok.append(bool(c)); print(("✅" if c else "❌"), n)
def f15(H, L, C):
    H, L, C = (np.asarray(x, float) for x in (H, L, C))
    return FR.Frame(pd.DataFrame({"t": np.arange(len(H), dtype=np.int64) * 900_000, "open": C, "high": H, "low": L, "close": C, "volume": 1.0}), "15m")
lv, sl, p0 = 138.2, 100.0, 200.0
F = f15([150, 145, 140, 141, 160], [146, 139, 135, 137, 150], [147, 140, 136, 140, 158])
ctx = {"xu": np.array([0, 0, 0, 0, 1], bool), "xd": np.zeros(5, bool), "rsi_up": np.array([0, 0, 0, 1, 0], bool), "rsi_dn": np.zeros(5, bool)}
e, px, st = F7.find_entry(F, ctx, "direct", 1, lv, sl, p0, 0, 5)
chk(f"مستقیم: اولین لمس (کندلِ ۱، کفِ ۱۳۹؟ نه ← کندلِ ۲ کفِ ۱۳۵) در ۱۳۸.۲: ({e}, {px})", e == 2 and px == lv)
e, px, st = F7.find_entry(F, ctx, "close", 1, lv, sl, p0, 0, 5)
chk(f"کلوزِ برگشتی: کندلِ ۲ کلوز ۱۳۶ زیرِ سطح، کندلِ ۳ کلوز ۱۴۰ ← ورود ۱۴۰: ({e}, {px})", e == 3 and px == 140)
chk("RSI: پرچم در کندلِ ۳ ← ورود ۱۴۰ · MA: کراس در کندلِ ۴ ← ورود ۱۵۸",
    F7.find_entry(F, ctx, "rsi", 1, lv, sl, p0, 0, 5)[:2] == (3, 140.0) and F7.find_entry(F, ctx, "ma", 1, lv, sl, p0, 0, 5)[:2] == (4, 158.0))
Fg = FR.Frame(pd.DataFrame({"t": np.arange(3, dtype=np.int64) * 900_000, "open": [130.0, 129, 131], "high": [133.0, 132, 140], "low": [128.0, 126, 129], "close": [129.0, 131, 139], "volume": 1.0}), "15m")
chk("شکاف (کلِ کندل زیرِ ۱۳۸.۲) با skip ← بدونِ ورود", F7.find_entry(Fg, ctx, "direct", 1, lv, sl, p0, 0, 3, "skip")[2] == "شکاف")
chk(f"شکاف با market ← ورود با اوپنِ ۱۳۰: {F7.find_entry(Fg, ctx, 'direct', 1, lv, sl, p0, 0, 3, 'market')[:3]}", F7.find_entry(Fg, ctx, "direct", 1, lv, sl, p0, 0, 3, "market")[:3] == (0, 130.0, "ورود (شکاف)"))
chk("market786: اوپنِ ۱۳۰ بالایِ ۰.۷۸۶ (۱۲۱.۴) ← ورود · با سطحِ ۰.۷۸۶ = ۱۳۵ ← بدونِ ورود",
    F7.find_entry(Fg, ctx, "direct", 1, lv, sl, p0, 0, 3, "market786", 121.4)[1] == 130.0 and F7.find_entry(Fg, ctx, "direct", 1, lv, sl, p0, 0, 3, "market786", 135.0)[2] == "شکاف")
Fs = f15([150, 145, 120, 141], [146, 139, 99, 137], [147, 140, 110, 140])
chk(f"لغو: SL (۱۰۰) قبل از تأیید لمس شد: {F7.find_entry(Fs, ctx, 'close', 1, lv, sl, p0, 0, 4)[2]}", F7.find_entry(Fs, ctx, "close", 1, lv, sl, p0, 0, 4)[2] == "SL قبل از تأیید")
# خروجِ چندتارگتی: ورود ۱۴۰، TP1 ۲۰۰، TP2 ۲۲۷، TP3 ۲۶۱.۸
G = f15([141, 201, 205, 150, 139], [139, 150, 190, 141, 120], [140, 195, 200, 145, 125])
parts = F7.simulate_exit(G, 0, 1, 140.0, 100.0, [200, 227, 261.8], [.5, .25, .25], 100)
chk(f"TP1 در کندلِ ۱ (۵۰٪)، بعد برگشت به ۱۴۰ در کندلِ ۴ ← بقیه در ورود: {[(f, p, l) for f, p, l, _ in parts]}",
    [(f, p, l) for f, p, l, _ in parts] == [(.5, 200, "TP1"), (.5, 140.0, "SL در ورود")])
G2 = f15([141, 201, 230, 270], [139, 150, 205, 228], [140, 195, 228, 265])
p2 = F7.simulate_exit(G2, 0, 1, 140.0, 100.0, [200, 227, 261.8], [.5, .25, .25], 100)
chk(f"هر سه تارگت: {[(f, l) for f, _, l, _ in p2]}", [(f, l) for f, _, l, _ in p2] == [(.5, "TP1"), (.25, "TP2"), (.25, "TP3")])
G3 = f15([141, 150, 120], [139, 135, 99], [140, 140, 100])
chk("SL قبل از TP1 ← کلِ پوزیشن در SL", [(f, l) for f, _, l, _ in F7.simulate_exit(G3, 0, 1, 140.0, 100.0, [200, 227, 261.8], [.5, .25, .25], 100)] == [(1.0, "SL")])
G4 = f15([141, 201, 205], [139, 99, 190], [140, 150, 200])
chk("SL و TP1 در یه کندل ← SL (محافظه‌کارانه)", F7.simulate_exit(G4, 0, 1, 140.0, 100.0, [200, 227, 261.8], [.5, .25, .25], 100)[0][2] == "SL")
chk(f"اکستنشن‌ها: ۱.۲۷ = {FR.fib(100, 200, 1 - 1.27):.0f} · ۱.۶۱۸ = {FR.fib(100, 200, 1 - 1.618):.1f} · ۲.۰ = {FR.fib(100, 200, 1 - 2.0):.0f}",
    abs(FR.fib(100, 200, -0.27) - 227) < 1e-9 and abs(FR.fib(100, 200, -0.618) - 261.8) < 1e-9 and abs(FR.fib(100, 200, -1.0) - 300) < 1e-9)
r = np.random.default_rng(4); c = 100 * np.exp(np.cumsum(r.normal(0, .003, 8000)))
F15 = FR.Frame(pd.DataFrame({"t": np.arange(8000, dtype=np.int64) * 900_000, "open": c, "high": c * 1.002, "low": c * .998, "close": c, "volume": 1.0}), "15m")
d1 = pd.DataFrame({"t": F15.t, "open": c, "high": c * 1.002, "low": c * .998, "close": c}); d1["k"] = d1["t"] // 3_600_000
g = d1.groupby("k").agg(t=("t", "first"), open=("open", "first"), high=("high", "max"), low=("low", "min"), close=("close", "last")).reset_index(drop=True); g["volume"] = 1.0
F1 = FR.Frame(g, "1h")
cfg = {"fee_pct": .05, "wait_bars": 200, "max_hold_bars": 500, "margin": 20.0, "lev": 10.0}
E = pd.DataFrame(F7.events7(F1, F15, F7.m15_context(F15), 5, cfg, "X", "origin"))
tmp = tempfile.mkdtemp(); R7.report(E, tmp, 0, int(F15.ct[-1]))
rep = open(os.path.join(tmp, "v7_report.md"), encoding="utf-8").read()
chk(f"گزارشِ v7 ساخته شد ({int((E['وضعیت'] == 'ورود').sum())} ورود از {len(E)} ستاپ)", "چند درصد ستاپ‌ها" in rep and "مسیرِ خروج" in rep)
print(f"\nنتیجه: {sum(ok)} از {len(ok)} تست موفق"); sys.exit(0 if all(ok) else 1)
