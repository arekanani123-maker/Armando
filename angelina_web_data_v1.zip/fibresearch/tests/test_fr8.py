# -*- coding: utf-8 -*-
import os, sys, tempfile
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import fr as FR, fr7 as F7, run8 as R8
ok = []
def chk(n, c): ok.append(bool(c)); print(("✅" if c else "❌"), n)
d = pd.DataFrame({"نماد": ["A", "A", "B", "C", "D"], "زمانِ ورود": [0, 10, 20, 30, 50], "خروج_ms": [100, 40, 60, 70, 60], "$ single": [10.0, 5.0, -3.0, 4.0, 2.0]})
taken, C, mx = R8.portfolio(d, 50, 20)
chk(f"سرمایه $50، مارجین $20: A (۰) گرفته میشه · A دوم رد (همون نماد باز) · B گرفته · C رد (مارجینِ آزاد $10) · D در ۵۰ رد: {taken.tolist()}", taken.tolist() == [True, False, True, False, False])
d2 = d.assign(**{"زمانِ ورود": [0, 10, 20, 60, 61]})
taken2, C2, _ = R8.portfolio(d2, 50, 20)
chk(f"خروجِ B در ۶۰ قبل از ورودِ هم‌زمانِ C در ۶۰ ← C گرفته میشه، D (۶۱) رد چون دو پوزیشن بازه: {taken2.tolist()}", taken2.tolist() == [True, False, True, True, False])
chk(f"منحنیِ سرمایه: ۵۰ ← ۴۷ (B) ← ۵۱ (C) ← ۶۱ (A): {C2['سرمایه'].tolist()}", C2["سرمایه"].tolist() == [47.0, 51.0, 61.0])
r = np.random.default_rng(6); c = 100 * np.exp(np.cumsum(r.normal(0, .004, 9000)))
F15 = FR.Frame(pd.DataFrame({"t": np.arange(9000, dtype=np.int64) * 900_000, "open": c, "high": c * 1.002, "low": c * .998, "close": c, "volume": 1.0}), "15m")
d1 = pd.DataFrame({"t": F15.t, "high": c * 1.002, "low": c * .998, "close": c, "open": c}); d1["k"] = d1["t"] // 3_600_000
g = d1.groupby("k").agg(t=("t", "first"), open=("open", "first"), high=("high", "max"), low=("low", "min"), close=("close", "last")).reset_index(drop=True); g["volume"] = 1.0
F1 = FR.Frame(g, "1h")
R8.CFG.update(min_sl=0.5)
E = pd.concat([pd.DataFrame(F7.events7(F1, F15, F7.m15_context(F15), 5, R8.CFG, s, "origin", ["direct"], ["single"], ["sl05", "sl1"])) for s in ("X", "Y")], ignore_index=True)
tmp = tempfile.mkdtemp(); rep = R8.report(E, tmp, 0, int(F15.ct[-1]), "skip")
chk("گزارشِ v8 ساخته شد (سرمایه، ماهانه، نماد، بخش‌ها) و فایل‌هایِ معاملات و منحنیِ سرمایه", "سودِ ماهانه" in rep and os.path.exists(os.path.join(tmp, "v8_trades_skip_none_sl05.csv")) and os.path.exists(os.path.join(tmp, "v8_equity_skip_none_sl05.csv")))
Em = pd.concat([pd.DataFrame(F7.events7(F1, F15, F7.m15_context(F15), 5, R8.CFG, s, "origin", ["direct"], ["single"], ["sl05", "sl1"], gap="market")) for s in ("X", "Y")], ignore_index=True)
ns, nm = int((E["وضعیت"] == "ورود").sum()), int((Em["وضعیت"] == "ورود").sum())
chk(f"با ورودِ شکاف، ورودها بیشتر میشن ({ns} ← {nm}) و ورودهایِ عادی همون می‌مونن", nm >= ns and int((Em["وضعیت"] == "ورود").sum() - Em.get("شکاف", pd.Series(False)).fillna(False).astype(bool).sum()) == ns)
Ef = pd.DataFrame({"وضعیت": ["ورود"] * 6, "sl": ["sl1"] * 6, "جهت": ["لانگ", "لانگ", "لانگ", "شورت", "شورت", "شورت"], "SL٪": [5.0] * 6, "ساعت": [10] * 6,
                   "$ single": [1.0] * 6, "زمانِ ورود": [0] * 6, "مدت single": [1.0] * 6,
                   "1h ورود بالایِ MA200": [True, True, False, False, False, True], "1h هم‌جهتیِ صعودی": [True, True, True, False, False, False],
                   "1h هم‌جهتیِ نزولی": [False, False, False, True, True, True], "1h واگراییِ منفی": [False, True, False, False, False, False],
                   "1h واگراییِ مثبت": [False, False, False, False, True, False]})
R8.CFG.update(min_sl=3.0)
sel = R8.select(Ef, "sl1", "ma_rsi")
chk(f"فیلترِ جدید: لانگ ۱ قبول · لانگ ۲ (واگراییِ منفی) رد · لانگ ۳ (زیرِ MA200) رد · شورت ۴ قبول · شورت ۵ (واگراییِ مثبت) رد · شورت ۶ (بالایِ MA200) رد → {len(sel)} معامله",
    len(sel) == 2 and list(sel["جهت"]) == ["لانگ", "شورت"])
chk("فیلترِ قبلی: فقط لانگ‌ها (۳)", len(R8.select(Ef, "sl1", "none")) == 3)
print(f"\nنتیجه: {sum(ok)} از {len(ok)} تست موفق"); sys.exit(0 if all(ok) else 1)
