# -*- coding: utf-8 -*-
import os, sys, tempfile
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import fr as FR, fr2 as F2, run2 as R2
ok = []
def chk(n, c): ok.append(bool(c)); print(("✅" if c else "❌"), n)
def frame(H, L, tf, C=None):
    H, L = np.asarray(H, float), np.asarray(L, float); C = (H + L) / 2 if C is None else np.asarray(C, float)
    return FR.Frame(pd.DataFrame({"t": np.arange(len(H), dtype=np.int64) * FR.TF_MS[tf], "open": C, "high": np.maximum(H, C), "low": np.minimum(L, C), "close": C, "volume": 1.0}), tf)
H = [120,115,110,105,130,150,170,190,200,190,170,150,139,160,185,201,195,190,185,180,175,170,165,160]
L = [110,105,102,100,110,140,160,180,190,180,160,140,137,150,170,190,185,180,175,170,165,160,155,150]
F = frame(H, L, "15m")
N = len(H)
up = {tf: (np.ones(N), np.ones(N)) for tf in ("15m", "1h", "4h")}
flags = {k: np.ones(N, bool) for k in ("bull_reg", "bull_hid", "bear_reg", "bear_hid", "align_up", "align_dn")}
cfg = {"fee_pct": 0.0, "wait_bars": 500, "max_hold_bars": 5000}
ev = pd.DataFrame(F2.events2(F, None, None, up, flags, 3, cfg, "X"))
r = ev[(ev["جهت"] == "لانگ") & (ev["سطح"] == 0.618)].iloc[0]
chk(f"پایه (سطحِ ۰، سطحِ ۱): TP با {0.618/0.382:.3f}R", r["tp0|sl1|none|none"] == "TP" and abs(r["R tp0|sl1|none|none"] - .618 / .382) < 1e-9)
chk("TP +۰.۵٪ (۲۰۱) در کندلِ ۱۵ رسید: TP · TP +۱٪ (۲۰۲) نرسید: باز", r["tp05|sl1|none|none"] == "TP" and r["tp1|sl1|none|none"] == "باز")
chk("اکستنشن ‎-۰.۲۷ (۲۲۷) نرسید: باز", r["ext|sl1|none|none"] == "باز")
R05 = 138.2 - 100 * .995
chk(f"SL ۰.۵٪ بازتر (۹۹.۵): R بزرگ‌تر ← سودِ TP برحسبِ R کمتر ({r['R tp0|sl05|none|none']:.3f})", abs(r["R tp0|sl05|none|none"] - (200 - 138.2) / R05) < 1e-9)
cy = {tf: (np.ones(N), np.ones(N)) for tf in ("15m", "1h", "4h")}
cl = np.ones(N); cl[13] = -1; cy["1h"] = (cl, np.ones(N))
ev2 = pd.DataFrame(F2.events2(F, None, None, cy, flags, 3, cfg, "X"))
r2 = ev2[(ev2["جهت"] == "لانگ") & (ev2["سطح"] == 0.618)].iloc[0]
chk(f"چرخه‌یِ 1h در بسته‌شدنِ کندلِ ۱۳ برگشت ← خروج با کلوزِ ۱۳ ({r2['tp0|sl1|1h|none']}، {r2['R tp0|sl1|1h|none']:.3f}R)", r2["tp0|sl1|1h|none"] == "چرخه" and abs(r2["R tp0|sl1|1h|none"] - ((160 + 150) / 2 - 138.2) / 38.2) < 1e-9)
chk(f"بعد از خروجِ چرخه، قیمت اول به TP رسید: {r2['بعد از چرخه 1h']}", r2["بعد از چرخه 1h"] == "TP")
nope = {tf: (np.ones(N), -np.ones(N)) for tf in ("15m", "1h", "4h")}
ev3 = pd.DataFrame(F2.events2(F, None, None, nope, flags, 3, cfg, "X"))
chk("چرخه خلافِ لانگ در لحظه‌یِ ورود ← وارد نمیشه (x)، بدونِ چرخه وارد میشه", ev3[(ev3["جهت"] == "لانگ") & (ev3["سطح"] == .618)].iloc[0]["tp0|sl1|4h|none"] == "x"
    and ev3[(ev3["جهت"] == "لانگ") & (ev3["سطح"] == .618)].iloc[0]["tp0|sl1|none|none"] == "TP")
r_ = np.random.default_rng(3); c = 100 * np.exp(np.cumsum(r_.normal(0, .004, 3000)))
Fa, Fb = frame(c * 1.002, c * .998, "15m", c), frame(c[:2000] * 1.002, c[:2000] * .998, "15m", c[:2000])
fa, fb = F2.filter_flags(Fa), F2.filter_flags(Fb)
chk("فیلترها بدونِ نگاه به آینده", all((fa[k][:1990] == fb[k][:1990]).all() for k in fa))
cyc = {tf: (np.sign(np.sin(np.arange(3000) / 50)), np.sign(np.sin(np.arange(3000) / 50))) for tf in ("15m", "1h", "4h")}
E = pd.DataFrame(F2.events2(Fa, None, None, cyc, fa, 5, {"fee_pct": .05, "wait_bars": 300, "max_hold_bars": 500}, "X"))
tmp = tempfile.mkdtemp(); R2.CFG["min_n"] = 5
R2.report(E, tmp, 0, int(Fa.ct[-1]), pd.DataFrame([{"نماد": "X"}]))
rep = open(os.path.join(tmp, "fib_v2_report.md"), encoding="utf-8").read()
chk(f"گزارشِ v2 ساخته شد ({len(E)} رویداد × ۳۲ ترکیب × ۴ فیلتر)", "TP × SL" in rep and "چرخه × فیلتر" in rep and "هر سه بخش" in rep and os.path.exists(os.path.join(tmp, "v2_all_combos_by_split.csv")))
He = [120,115,110,105,130,150,170,190,200,190,170,150,139,160,185,150,140,130,120,110,100,95,90,90]
Le = [110,105,102,100,110,140,160,180,190,180,160,140,137,150,170,140,135,130,118,105,96,92,88,88]
Fe = frame(He, Le, "15m"); Ne = len(He)
upe = {tf: (np.ones(Ne), np.ones(Ne)) for tf in ("15m", "1h", "4h")}
fle = {k: np.ones(Ne, bool) for k in ("bull_reg", "bull_hid", "bear_reg", "bear_hid", "align_up", "align_dn")}
ee = pd.DataFrame(F2.events2(Fe, None, None, upe, fle, 3, cfg, "X"))
x = ee[(ee["جهت"] == "لانگ") & (ee["سطح"] == 0.618)].iloc[0]
chk(f"مدیریت: بدون ← بعد از +۱R (۱۷۶.۴) قیمت تا ۹۲ اومد ← SL ({x['tp0|sl1|none|none']}، {x['R tp0|sl1|none|none']:.2f}R)", x["tp0|sl1|none|none"] == "SL" and abs(x["R tp0|sl1|none|none"] + 1) < 1e-9)
chk(f"مدیریت: SL به ورود ← خروج در ۱۳۸.۲ با ۰R ({x['tp0|sl1|none|be1']}، {x['R tp0|sl1|none|be1']:.2f})", x["tp0|sl1|none|be1"] == "SL در ورود" and abs(x["R tp0|sl1|none|be1"]) < 1e-9)
chk(f"مدیریت: ۵۰٪ در +۱R ← +۰.۵R ({x['tp0|sl1|none|part1']}، {x['R tp0|sl1|none|part1']:.2f})", x["tp0|sl1|none|part1"] == "نیمه + ورود" and abs(x["R tp0|sl1|none|part1"] - 0.5) < 1e-9)
y = ev[(ev["جهت"] == "لانگ") & (ev["سطح"] == 0.618)].iloc[0]
chk(f"مدیریت: وقتی TP خورده، ۵۰٪ در +۱R + بقیه TP = ۰.۵ + ۰.۵ × ۱.۶۱۸ ({y['R tp0|sl1|none|part1']:.3f})", abs(y["R tp0|sl1|none|part1"] - (0.5 + 0.5 * .618 / .382)) < 1e-9)
chk(f"ساعتِ ورود ثبت شد ({y['ساعت']})", y["ساعت"] == int(12 * 900_000 // 3_600_000 % 24))
usd = y["R tp0|sl1|none|none"] * y["R٪ sl1"] / 100 * 200
chk(f"دلار: TPِ ۱۳۸.۲→۲۰۰ با پوزیشنِ $200 = {usd:.2f}$ (= ۲۰۰ × ۶۱.۸/۱۳۸.۲)", abs(usd - 200 * 61.8 / 138.2) < 1e-6)
Hw = [101,120,140,160,150,145,141,150,170,190,200,195,190,185,180,175,170]
Lw = [100,110,130,150,140,139,140,145,160,180,190,185,180,175,170,165,160]
Fw = frame(Hw, Lw, "15m")
rw = {m: [x for x in FR.waves(Fw, 2, m) if x[1] == 1 and x[3] == 10][0][4] for m in ("between", "lastpivot", "origin")}
chk(f"روش‌هایِ موج: فعلی/آخرین کفِ پیووت ← ۱۳۹، شروعِ کلِ حرکت ← ۱۰۰ ({rw})", rw == {"between": 139.0, "lastpivot": 139.0, "origin": 100.0})
pc = {"tf": "15m", "waves": [{"tf": "1h", "n": 10, "side": 1, "ct": np.array([1000, 5000], np.int64), "p1": np.array([90.0, 50.0]), "p0": np.array([200.0, 300.0])}],
      "sr_t": np.array([100, 4000, 9000], np.int64), "sr_p": np.array([138.25, 170.0, 138.2]), "sr_win": 10_000}
f1 = F2.prz_flags(pc, 3000, 1, 138.2, (100.0, 200.0), 20)      # موجِ 1h (۹۰→۲۰۰): ۰.۵۶۴… نه · ۰.۵ = ۱۴۵ نه · ۰.۶۱۸ = ۱۳۲ نه · ۰.۷۸۶ = ۱۱۳.۵ نه
f2 = F2.prz_flags(dict(pc, waves=[dict(pc["waves"][0], p1=np.array([100.0, 50.0]))]), 3000, 1, 138.2, (100.0, 120.0), 20)
f3 = F2.prz_flags(pc, 6000, 1, 138.2, (100.0, 200.0), 20)
chk(f"PRZِ فیبو: موجِ دیگه (۹۰→۲۰۰) سطحی نزدیکِ ۱۳۸.۲ نداره ← نه؛ موجِ (۱۰۰→۲۰۰) ۰.۶۱۸ = ۱۳۸.۲ ← بله ({f1[0]}, {f2[0]})", f1[0] is False and f2[0] is True)
chk(f"PRZِ فیبو: موجی که بعد از لحظه‌یِ ورود تأیید شده استفاده نمیشه (در t=۶۰۰۰ موجِ ۵۰→۳۰۰ ← ۰.۶۱۸ = ۱۴۴.۵ ← نه): {f3[0]}", f3[0] is False)
chk(f"حمایت/مقاومت: سقف/کفِ ۱۳۸.۲۵ در t=۱۰۰ داخلِ پنجره و تا ۰.۳٪ ← بله؛ ۱۳۸.۲ در t=۹۰۰۰ هنوز تأیید نشده ({f1[1]}, {F2.prz_flags(pc, 8000, 1, 138.2, (0, 0), 20)[1]})",
    f1[1] is True and F2.prz_flags(dict(pc, sr_win=1000), 3000, 1, 138.2, (0, 0), 20)[1] is False)
own = F2.prz_flags({"tf": "15m", "waves": [{"tf": "15m", "n": 20, "side": 1, "ct": np.array([0], np.int64), "p1": np.array([100.0]), "p0": np.array([200.0])}],
                    "sr_t": np.array([], np.int64), "sr_p": np.array([]), "sr_win": 1}, 10, 1, 138.2, (100.0, 200.0), 20)
chk("PRZ: موجِ خودِ معامله با خودش همپوشانی حساب نمیشه", own[0] is False)
Fr_ = {"15m": Fa, "1h": frame(c[::4] * 1.003, c[::4] * .997, "1h", c[::4])}
pcx = F2.prz_context(Fr_, "15m", [5, 10], "between")
E6 = pd.DataFrame(F2.events2(Fa, None, None, cyc, fa, 5, {"fee_pct": .05, "wait_bars": 300, "max_hold_bars": 500}, "X", przc=pcx))
E6["موج"] = "between"
R2.CFG["min_n"] = 5
tmp6 = tempfile.mkdtemp(); R2.report_prz(E6, tmp6, 0, int(Fa.ct[-1]))
r6 = open(os.path.join(tmp6, "v6_prz_report.md"), encoding="utf-8").read()
chk(f"گزارشِ v6 ساخته شد (PRZِ فیبو در {int(E6['prz_fib'].sum())} و حمایت/مقاومت در {int(E6['prz_sr'].sum())} رویداد از {len(E6)})", "PRZ × حداقلِ SL٪" in r6 and os.path.exists(os.path.join(tmp6, "v6_prz_0618_all.csv")))
print(f"\nنتیجه: {sum(ok)} از {len(ok)} تست موفق"); sys.exit(0 if all(ok) else 1)
