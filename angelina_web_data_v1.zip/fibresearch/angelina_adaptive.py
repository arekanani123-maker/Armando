# -*- coding: utf-8 -*-
"""
Angelina-Adaptive — Angelina (قفل‌شده) + یادگیریِ ماهانه از گذشته. Angelina خودش تغییر نمی‌کنه؛ فقط تصمیمِ «این ستاپ رو بگیر یا نه» یاد گرفته میشه.
امضایِ هر ستاپ (فقط اطلاعاتِ معلوم در لحظه‌یِ ورود): جهت · قیمت/MA200 و شیبِ MA200 در 15m، 1h، 4h، 1D (لحظه‌یِ کشیدنِ فیبو و ورود) · سنِ چرخه‌یِ روزانه · اندازه‌یِ SL · ساعت
یادگیری (ماه به ماه، فقط از معاملاتی که قبل از شروعِ اون ماه **بسته شدن**):
  rules = جدولِ شفاف: خانه‌یِ امضا (جهت × قیمت/MA200ِ 4h در ورود × قیمت/MA200ِ 4h در فیبو × قیمت/MA200ِ 1D × چرخه‌یِ 1D × شیبِ 1h در ورود)؛
          مجاز اگه حداقل MIN_N معامله‌یِ گذشته و میانگینِ R مثبت داشته باشه
  ml    = رگرسیونِ لجستیک رویِ همه‌یِ ویژگی‌ها؛ مجاز اگه احتمالِ برد > حدِ سربه‌سرِ گذشته
پنجره: all = همه‌یِ گذشته · 24m = ۲۴ ماهِ اخیر · ۱۲ ماهِ اول فقط یادگیری
اجرا: python angelina_adaptive.py   (قابلِ ادامه؛ مرحله‌یِ ساختِ ستاپ‌ها برایِ هر نماد ذخیره میشه)
"""
import os, sys, json, glob, time, pickle, argparse
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fr as FR, fr7 as F7, run8 as R8, run_angelina as A, angelina_mtf as M, angelina_daily as AD

MIN_N = 15
WARMUP_MONTHS = 12
RULE_KEY = ["جهت", "4h|ورود|قیمت", "4h|موج|قیمت", "1d|ورود|قیمت", "1d|ورود|شیب", "1h|ورود|شیب"]


# ---------------------------------------------------------------- ۱. ستاپ‌ها + امضا
def build_symbol(sym, ex, start, end, cache, L):
    d5 = FR.fetch(ex, sym, "5m", start - 5 * 86_400_000, end, cache)
    D = {tf: FR.fetch(ex, sym, tf, start - 260 * FR.TF_MS[tf] - 30 * 86_400_000, end, cache) for tf in ("15m", "1h", "4h", "1d")}
    if len(d5) < 5000 or len(D["4h"]) < 300:
        return None
    F5, F4 = FR.Frame(d5, "5m"), FR.Frame(D["4h"], "4h")
    ev = pd.DataFrame(F7.events7(F4, F5, {}, L["pivot"], R8.CFG, sym, L["wave_method"], ["direct"], ["single"], ["sl1"], gap=L["gap"]))
    if not len(ev):
        return pd.DataFrame()
    ev = ev[(ev["تأییدِ موج"] >= start) & (ev["وضعیت"] == "ورود") & ev["$ single"].notna()].copy()
    if not len(ev):
        return ev
    ev["خروج_ms"] = ev["زمانِ ورود"] + (ev["مدت single"] * 3.6e6).astype("int64")
    frames = {tf: {sym: FR.Frame(D[tf], tf)} for tf in M.TFS}
    T = M.tag(ev, frames)
    dc = AD.daily_context(D["1d"])
    j = dc["F"].closed_idx(T["زمانِ ورود"].astype("int64").to_numpy())
    age = np.where((j >= 0) & (dc["last_flip"][np.clip(j, 0, None)] >= 0), j - dc["last_flip"][np.clip(j, 0, None)], np.nan)
    T["سنِ چرخه‌یِ روزانه"] = age
    return T.drop(columns=[c for c in T.columns if "|خروج|" in c])


def features(T):
    X = pd.DataFrame(index=T.index)
    X["لانگ"] = (T["جهت"] == "لانگ").astype(float)
    for c in [c for c in T.columns if c.count("|") == 2]:
        X[c + "+"] = (T[c] > 0).astype(float); X[c + "-"] = (T[c] < 0).astype(float)
    age = T["سنِ چرخه‌یِ روزانه"]
    for lo, hi in ((0, 30), (30, 90), (90, 180), (180, 1e9)):
        X[f"سنِ چرخه {lo}"] = ((age >= lo) & (age < hi)).astype(float)
    sl = T["SL٪"]
    for lo, hi in ((0, 2), (2, 4), (4, 8), (8, 1e9)):
        X[f"SL {lo}"] = ((sl >= lo) & (sl < hi)).astype(float)
    h = T["ساعت"]
    for b in range(0, 24, 4):
        X[f"ساعت {b}"] = ((h >= b) & (h < b + 4)).astype(float)
    return X


def rule_key(T):
    return T[RULE_KEY].astype(str).agg("|".join, axis=1)


# ---------------------------------------------------------------- ۲. یادگیری
def learn_rules(train):
    if not len(train):
        return {}
    g = train.assign(k=rule_key(train)).groupby("k")["R single"].agg(["size", "mean"])
    return {k: {"n": int(r["size"]), "میانگینِ R": round(float(r["mean"]), 4), "مجاز": bool(r["size"] >= MIN_N and r["mean"] > 0)} for k, r in g.iterrows()}


def learn_ml(train):
    from sklearn.linear_model import LogisticRegression
    if len(train) < 60 or train["R single"].gt(0).nunique() < 2:
        return None
    X, y = features(train), (train["R single"] > 0).astype(int)
    m = LogisticRegression(C=0.3, max_iter=2000).fit(X.to_numpy(), y.to_numpy())
    w, l = train.loc[y == 1, "R single"].mean(), -train.loc[y == 0, "R single"].mean()
    return {"model": m, "cols": list(X.columns), "p_be": l / (w + l)}


def decide(kind, model, test):
    if kind == "base":
        return np.ones(len(test), bool)
    if kind == "rules":
        k = rule_key(test)
        return np.array([model.get(x, {}).get("مجاز", False) for x in k])
    if model is None:
        return np.zeros(len(test), bool)
    X = features(test).reindex(columns=model["cols"], fill_value=0.0)
    return model["model"].predict_proba(X.to_numpy())[:, 1] > model["p_be"]


def walk_forward(T, kind, window):
    T = T.sort_values("زمانِ ورود").reset_index(drop=True)
    m0 = pd.to_datetime(T["زمانِ ورود"].min(), unit="ms").to_period("M") + WARMUP_MONTHS
    months = pd.period_range(m0, pd.to_datetime(T["زمانِ ورود"].max(), unit="ms").to_period("M"), freq="M")
    em = pd.to_datetime(T["زمانِ ورود"], unit="ms").dt.to_period("M")
    take = np.zeros(len(T), bool)
    for mo in months:
        t0 = int(mo.start_time.value // 10**6)
        tr = T[T["خروج_ms"] < t0]                                             # فقط معاملاتِ بسته‌شده قبل از این ماه
        if window == "24m":
            tr = tr[tr["خروج_ms"] >= t0 - int(730.5 * 86_400_000)]
        idx = np.where(em == mo)[0]
        if not len(idx):
            continue
        model = None if kind == "base" else (learn_rules(tr) if kind == "rules" else learn_ml(tr))
        take[idx] = decide(kind, model, T.iloc[idx])
    return T[take & (em >= months[0]).to_numpy()]


# ---------------------------------------------------------------- ۳. سرمایه و گزارش
def simulate(sel, L):
    d = sel.sort_values("زمانِ ورود").reset_index(drop=True)
    if not len(d):
        return d, {"معاملات": 0}
    tk, C, mx = R8.portfolio(d, L["capital"], L["margin"])
    t = d[tk].sort_values("خروج_ms").reset_index(drop=True)
    u = t["$ single"].to_numpy(); cap = L["capital"]
    eq = cap + np.cumsum(u); pk = np.maximum.accumulate(np.r_[cap, eq])[1:]
    st = A.streaks(u)
    w, l = u[u > 0].sum(), -u[u <= 0].sum()
    return t, {"معاملات": len(u), "برد٪": round(100 * (u > 0).mean(), 1), "سود $": round(u.sum(), 0), "سرمایه $": round(eq[-1], 0),
               "PF": round(w / l, 2) if l > 0 else np.inf, "Max DD $": round((eq - pk).min(), 0), "کمترین سرمایه $": round(eq.min(), 0),
               "بیشترین ضررِ متوالی": st["باخت"][0][0], "بیشترین سودِ متوالی": st["برد"][0][0], "لانگ/شورت": f"{int((t['جهت'] == 'لانگ').sum())}/{int((t['جهت'] == 'شورت').sum())}"}


def main():
    L = A.lock()
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbols", default=R8.SYMBOLS); ap.add_argument("--years", type=float, default=6)
    ap.add_argument("--cache", default="/content/fr_cache"); ap.add_argument("--out", default="/content/angelina_adaptive_results")
    ap.add_argument("--refresh", type=int, default=0, help="۱ = ستاپ‌ها با داده‌یِ جدید دوباره ساخته و قانون‌ها دوباره یاد گرفته بشن (به‌روزرسانیِ ماهانه)")
    a = ap.parse_args()
    if a.refresh:
        for f in glob.glob(os.path.join(a.out, "setups", "*.csv.gz")):
            os.remove(f)
    R8.CFG.update(capital=L["capital"], margin=L["margin"], lev=L["lev"], fee_pct=L["fee_pct"])
    os.makedirs(os.path.join(a.out, "setups"), exist_ok=True)
    end = int(time.time() * 1000) // 3_600_000 * 3_600_000
    start = end - int(a.years * 365.25 * 86_400_000)
    import ccxt
    ex = ccxt.okx({"enableRateLimit": True})
    parts = []
    for sym in [s.strip().upper() for s in a.symbols.split(",") if s.strip()]:
        p = os.path.join(a.out, "setups", f"{sym}.csv.gz")
        if not os.path.exists(p):
            print(f"  {sym} ...", flush=True)
            try:
                T = build_symbol(sym, ex, start, end, a.cache, L)
            except Exception as e:                                          # noqa: BLE001
                print(f"  {sym}: خطا ({e})", flush=True); continue
            (T if T is not None else pd.DataFrame()).to_csv(p, index=False, compression="gzip")
            print(f"💾 {sym}: {0 if T is None else len(T)} ستاپ", flush=True)
        if os.path.getsize(p) > 50:
            x = pd.read_csv(p)
            if len(x):
                parts.append(x)
    report(pd.concat(parts, ignore_index=True), L, a.out)


def report(T, L, out):
    rows, curves = [], {}
    for kind, window, nm in (("base", "all", "Angelina (بدونِ یادگیری)"), ("rules", "all", "جدولِ قانون · همه‌یِ گذشته"), ("rules", "24m", "جدولِ قانون · ۲۴ ماه"),
                             ("ml", "all", "یادگیریِ ماشین · همه‌یِ گذشته"), ("ml", "24m", "یادگیریِ ماشین · ۲۴ ماه")):
        sel = walk_forward(T, kind, window)
        t, s = simulate(sel, L)
        rows.append({"نسخه": nm, **s})
        if len(t):
            t["سال"] = pd.to_datetime(t["خروج_ms"], unit="ms").dt.year
            curves[nm] = t.groupby("سال")["$ single"].sum().round(0)
            t.to_csv(os.path.join(out, f"trades_{kind}_{window}.csv"), index=False, encoding="utf-8-sig")
    R = pd.DataFrame(rows)
    Y = pd.DataFrame(curves).T
    closed = T[T["خروج_ms"] < T["خروج_ms"].max()]
    rules_now = learn_rules(closed)
    json.dump(rules_now, open(os.path.join(out, "angelina_adaptive_rules.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    ml_now = learn_ml(closed)
    if ml_now:
        pickle.dump(ml_now, open(os.path.join(out, "angelina_adaptive_ml.pkl"), "wb"))
    RT = pd.DataFrame([{"امضا (جهت|4h ورود|4h فیبو|1D قیمت|1D چرخه|1h شیب)": k, **v} for k, v in rules_now.items()]).sort_values("میانگینِ R", ascending=False)
    m0 = pd.to_datetime(T["زمانِ ورود"].min(), unit="ms").to_period("M") + WARMUP_MONTHS
    txt = ["# Angelina-Adaptive — یادگیریِ ماهانه از گذشته (walk-forward)", "",
           f"{T['نماد'].nunique()} نماد · {len(T)} ستاپِ Angelina · ارزیابی از {m0} (۱۲ ماهِ اول فقط یادگیری) · $500 · $20 × ۱۰",
           "هر ماه فقط از معاملاتی که قبل از شروعِ اون ماه بسته شدن یاد گرفته میشه؛ ویژگی‌ها فقط از لحظه‌یِ فیبو و ورود.", "",
           "## مقایسه (همون ماه‌ها)", R.to_string(index=False), "", "## سود به تفکیکِ سال ($)", Y.to_string(), "",
           f"## جدولِ قانونِ فعلی (یادگرفته‌شده از همه‌یِ گذشته، حداقل {MIN_N} معامله) — ۱ = سمتِ درستِ MA200/شیب، ‎-1 = سمتِ غلط",
           RT.to_string(index=False), "",
           "فایل‌ها: angelina_adaptive_rules.json (قانون‌هایِ فعلی) · angelina_adaptive_ml.pkl (مدلِ فعلی) · trades_*.csv"]
    open(os.path.join(out, "angelina_adaptive_report.md"), "w", encoding="utf-8").write("\n".join(txt))
    print("\n".join(txt[:40]))


if __name__ == "__main__":
    main()
