# -*- coding: utf-8 -*-
"""اجرا: python run.py --symbols BTC,ETH --years 6 --tfs 5m,15m,1h --pivots 5,10,20,30,40,50 (قابلِ ادامه بعد از قطع‌شدن)."""
import os, sys, glob, json, math, argparse, time
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fr as FR

CFG = {"fee_pct": 0.05, "wait_bars": 500, "max_hold_bars": 5000, "min_n": 30}


# ---------------------------------------------------------------- آمار
def wilson(k, n, z=1.96):
    if n == 0:
        return np.nan, np.nan
    p = k / n; d = 1 + z * z / n; c = (p + z * z / (2 * n)) / d; h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return c - h, c + h


def cluster_mean(x, day):
    """میانگین و خطایِ استانداردِ مقاوم با خوشه‌یِ روزانه (معاملاتِ یه روز مستقل حساب نمیشن)."""
    x = np.asarray(x, float); ok = np.isfinite(x); x, day = x[ok], np.asarray(day)[ok]
    n = len(x)
    if n < 2:
        return (x.mean() if n else np.nan), np.nan, 0
    m = x.mean(); g = pd.Series(x - m).groupby(day).sum().to_numpy()
    G = len(g)
    se = math.sqrt((g ** 2).sum() * G / max(1, G - 1)) / n
    return m, se, G


def max_dd(r):
    c = np.cumsum(np.nan_to_num(r)); return float((c - np.maximum.accumulate(np.r_[0, c])[1:]).min()) if len(c) else np.nan


def stats(g):
    t = g[g["وضعیت"] == "معامله"].sort_values("زمانِ ورود")
    res = t["نتیجه"]
    tp, sl, amb = int((res == "TP").sum()), int((res == "SL").sum()), int((res == "مبهم").sum())
    dec = tp + sl
    day = (t["زمانِ ورود"] // 86_400_000).to_numpy()
    m, se, G = cluster_mean(t["سود R (خالص)"], day)
    pnl = t["سود R (خالص)"]
    o = {"موج×سطح": len(g), "لمس (رویدادِ مستقل)": len(t), "روزهایِ مستقل": G, "TP": tp, "SL": sl, "مبهم": amb, "باز": int((res == "باز").sum()),
         "نرخِ برد": tp / dec if dec else np.nan, "امید (R)": m, "امید پایین۹۵ (R)": m - 1.96 * se if np.isfinite(se) else np.nan,
         "میانگینِ سود (R)": pnl[res == "TP"].mean(), "میانگینِ زیان (R)": pnl[res == "SL"].mean(),
         "MFE (R)": t["MFE R"].mean(), "MAE (R)": t["MAE R"].mean(), "مدت (ساعت)": t["مدت (ساعت)"].mean(), "بیشترین افت (R)": max_dd(pnl.to_numpy())}
    for k in FR.THRESH_R:
        c = t[f"برگشتِ موفق {k}R"].dropna()
        lo, _ = wilson(int(c.sum()), len(c))
        o[f"برگشت {k}R٪"] = 100 * c.mean() if len(c) else np.nan
        o[f"برگشت {k}R پایین۹۵٪"] = 100 * lo if len(c) else np.nan
    for w in ("۲۴ ساعت", "۷۲ ساعت"):
        o[f"بعد از TP: ادامه {w} (R)"] = t.get(f"بعد از TP · {w}: ادامه R", pd.Series(dtype=float)).mean()
        o[f"بعد از SL: ادامه {w} (R)"] = t.get(f"بعد از SL · {w}: ادامه R", pd.Series(dtype=float)).mean()
    rt = t.get("بعد از SL · رسیدن به TPِ اولیه در ۷۲ ساعت", pd.Series(dtype=object)).dropna()
    o["بعد از SL: برگشت به TP در ۷۲س٪"] = 100 * rt.astype(float).mean() if len(rt) else np.nan
    return pd.Series(o)


def table(E, keys, min_n=0):
    T = E.groupby(keys, dropna=False).apply(stats).reset_index()
    return T[T["لمس (رویدادِ مستقل)"] >= min_n] if min_n else T


def combo_key(E):
    lab = lambda v: "ص" if v == 1 else ("ن" if v == -1 else ("خنثی" if v == 0 else "?"))
    return E["MA200 4h"].map(lab) + "/" + E["MA200 1h"].map(lab) + "/" + E["MA200 15m"].map(lab)


def fmt(df, n=60):
    return df.head(n).round(3).to_string(index=False) if len(df) else "-"


# ---------------------------------------------------------------- اجرا
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbols", default="BTC,ETH"); ap.add_argument("--years", type=float, default=6)
    ap.add_argument("--tfs", default="5m,15m,1h"); ap.add_argument("--pivots", default="5,10,20,30,40,50")
    ap.add_argument("--cache", default="/content/fr_cache"); ap.add_argument("--out", default="/content/fr_results")
    ap.add_argument("--end", default=None)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True); os.makedirs(os.path.join(a.out, "events"), exist_ok=True)
    end = int(pd.Timestamp(a.end, tz="UTC").value // 10**6) if a.end else int(time.time() * 1000) // 3_600_000 * 3_600_000
    start = end - int(a.years * 365.25 * 86_400_000)
    warm = 210 * FR.TF_MS["4h"]
    syms = [s.strip().upper() for s in a.symbols.split(",") if s.strip()]
    tfs = [x for x in a.tfs.split(",") if x]; pivs = [int(x) for x in a.pivots.split(",")]
    import ccxt
    ex = ccxt.okx({"enableRateLimit": True})
    Q, notes = [], []
    for sym in syms:
        D = {}
        for tf in sorted(set(tfs + ["5m", "15m", "1h", "4h"]), key=lambda x: FR.TF_MS[x]):
            print(f"  داده‌یِ {sym} {tf} ...", flush=True)
            D[tf] = FR.fetch(ex, sym, tf, start - warm, end, a.cache)
            Q.append({"نماد": sym, "تایم": tf, **FR.quality(D[tf], tf)})
            if len(D[tf]) and D[tf]["t"].iloc[0] > start:
                notes.append(f"- {sym} {tf}: داده فقط از {pd.Timestamp(int(D[tf]['t'].iloc[0]), unit='ms'):%Y-%m-%d} موجوده (کمتر از {a.years:g} سال)")
        Fr = {tf: FR.Frame(D[tf], tf) for tf in D}
        ctx = {tf: Fr[tf] for tf in ("5m", "15m", "1h", "4h")}
        for tf in tfs:
            F = Fr[tf]
            for n in pivs:
                p = os.path.join(a.out, "events", f"{sym}_{tf}_p{n}.csv.gz")
                if os.path.exists(p):
                    print(f"⏭  {sym} {tf} پیووت {n}: قبلاً", flush=True); continue
                t0 = time.time()
                rows = FR.events(F, Fr["5m"] if tf != "5m" else Fr["5m"], ctx, n, CFG, sym)
                ev = pd.DataFrame(rows)
                if len(ev):
                    ev = ev[ev["تأییدِ موج"] >= start]
                ev.to_csv(p, index=False, compression="gzip")
                print(f"💾 {sym} {tf} پیووت {n}: {len(ev)} موج×سطح ({time.time() - t0:.0f}s)", flush=True)
    pd.DataFrame(Q).to_csv(os.path.join(a.out, "data_quality.csv"), index=False)
    E = pd.concat([pd.read_csv(f) for f in glob.glob(os.path.join(a.out, "events", "*.csv.gz"))], ignore_index=True)
    E["بخش"] = FR.split_of(E["تأییدِ موج"], start, end)
    E["ترکیبِ MA200 (4h/1h/15m)"] = combo_key(E) if "MA200 4h" in E else "?"
    E["هم‌جهت با MA200ِ 4h"] = np.where(E.get("MA200 4h").isna(), "?", np.where(E["MA200 4h"] * np.where(E["جهت"] == "لانگ", 1, -1) > 0, "هم‌جهت", "خلاف"))
    report(E, a, start, end, Q, notes)


def report(E, a, start, end, Q, notes):
    mn = CFG["min_n"]
    tr, va, te = (E[E["بخش"] == s] for s in ("آموزش", "اعتبارسنجی", "آزمونِ نهایی"))
    ts = lambda ms: pd.Timestamp(int(ms), unit="ms").strftime("%Y-%m-%d")
    K = ["نماد", "تایم", "جهت", "سطح"]
    r1 = table(tr, K)
    best1 = r1[r1["لمس (رویدادِ مستقل)"] >= mn].sort_values("برگشت 1.0R پایین۹۵٪", ascending=False).groupby(["نماد", "تایم", "جهت"]).head(1)
    r2 = table(tr, ["نماد", "تایم", "جهت", "سطح", "ترکیبِ MA200 (4h/1h/15m)"], mn)
    r3 = table(E[E["وضعیت"] == "معامله"], ["تایم", "جهت", "سطح"])
    after_cols = [c for c in E.columns if c.startswith("بعد از TP ·") and (": ادامه" in c or ": برگشت" in c)]
    r3b = E[E["نتیجه"] == "TP"].groupby(["تایم", "جهت", "سطح"])[after_cols].mean().reset_index() if after_cols else pd.DataFrame()
    sl_cols = [c for c in E.columns if c.startswith("بعد از SL ·") and (": ادامه" in c or ": برگشت" in c)]
    S = E[E["نتیجه"] == "SL"].copy()
    if "بعد از SL · رسیدن به TPِ اولیه در ۷۲ ساعت" in S:
        S["برگشت به TP"] = S["بعد از SL · رسیدن به TPِ اولیه در ۷۲ ساعت"].astype(float)
    r4 = S.groupby(["تایم", "جهت", "سطح"])[sl_cols + (["برگشت به TP", "بعد از SL · زمان تا TPِ اولیه (ساعت)"] if "برگشت به TP" in S else [])].mean().reset_index() if len(S) else pd.DataFrame()
    r4c = S.groupby(["جهت", "ترکیبِ MA200 (4h/1h/15m)"])[["برگشت به TP"] + [c for c in sl_cols if "۷۲ ساعت: ادامه R" in c]].mean().reset_index() if "برگشت به TP" in S else pd.DataFrame()
    r5 = table(tr, ["تایم", "سطح", "جهت"])
    r5b = table(tr, ["تایم", "جهت", "هم‌جهت با MA200ِ 4h"])
    G = ["نماد", "تایم", "پیووت", "جهت", "سطح"]
    rk = table(tr, G, mn).sort_values("امید پایین۹۵ (R)", ascending=False)
    top = rk.head(15)[G]
    chk = []
    for _, r in top.iterrows():
        row = {k: r[k] for k in G}
        for nm, part in (("آموزش", tr), ("اعتبارسنجی", va), ("آزمونِ نهایی", te)):
            sub = part[np.logical_and.reduce([(part[k] == row[k]).to_numpy() for k in G])] if len(part) else part
            s_ = stats(sub) if len(sub) else None
            row[f"امید {nm}"] = s_["امید (R)"] if s_ is not None else np.nan
            row[f"n {nm}"] = s_["لمس (رویدادِ مستقل)"] if s_ is not None else 0
        chk.append(row)
    CH = pd.DataFrame(chk)
    for df_, nm in ((r1, "r1_levels.csv"), (r2, "r2_ma200_combos.csv"), (r3, "r3_trade_stats_all.csv"), (r3b, "r3_after_tp.csv"), (r4, "r4_after_sl.csv"),
                    (r5, "r5_long_short.csv"), (rk, "r6_ranking_train.csv"), (CH, "r6_top_checked.csv")):
        df_.to_csv(os.path.join(a.out, nm), index=False)
    # پاسخ‌هایِ ۱۲ سؤال — فقط از جدول‌ها
    ans = []
    def best(df, by, filt=None):
        d = df if filt is None else df[filt(df)]
        d = d[d["لمس (رویدادِ مستقل)"] >= mn].sort_values(by, ascending=False)
        return d.iloc[0] if len(d) else None
    for i, (q, d, by, f) in enumerate([
            ("بهترین سطح برایِ لانگ", r5, "امید پایین۹۵ (R)", lambda x: x["جهت"] == "لانگ"),
            ("بهترین سطح برایِ شورت", r5, "امید پایین۹۵ (R)", lambda x: x["جهت"] == "شورت"),
            ("بهترین سطح در 15m", r5, "امید پایین۹۵ (R)", lambda x: x["تایم"] == "15m"),
            ("بهترین سطح در 1h", r5, "امید پایین۹۵ (R)", lambda x: x["تایم"] == "1h"),
            ("بهترین سطح در 5m", r5, "امید پایین۹۵ (R)", lambda x: x["تایم"] == "5m")], 1):
        b = best(d, by, f)
        ans.append(f"{i}. {q}: " + (f"{b['تایم']} · {b['جهت']} · سطحِ {b['سطح']} — امید {b['امید (R)']:+.3f}R (پایین۹۵ {b['امید پایین۹۵ (R)']:+.3f})، n={int(b['لمس (رویدادِ مستقل)'])}" if b is not None else "نمونه‌یِ کافی نیست"))
    ans.append("6. اثرِ MA200: " + "; ".join(f"{r['تایم']} {r['جهت']} {r['هم‌جهت با MA200ِ 4h']}: امید {r['امید (R)']:+.3f}R (n={int(r['لمس (رویدادِ مستقل)'])})" for _, r in r5b.iterrows()))
    b = best(r2, "امید پایین۹۵ (R)")
    ans.append("7. بهترین ترکیبِ سه تایم: " + (f"{b['ترکیبِ MA200 (4h/1h/15m)']} · {b['نماد']} {b['تایم']} {b['جهت']} سطحِ {b['سطح']} — امید {b['امید (R)']:+.3f}R، n={int(b['لمس (رویدادِ مستقل)'])}" if b is not None else "نمونه‌یِ کافی نیست"))
    for i, (lab, col) in enumerate((("8. بعد از TP، ادامه‌یِ میانگین در ۷۲ ساعت", "بعد از TP · ۷۲ ساعت: ادامه٪"), ("9. بعد از SL، ادامه‌یِ خلاف در ۷۲ ساعت", "بعد از SL · ۷۲ ساعت: ادامه٪"))):
        ans.append(f"{lab}: " + ("; ".join(f"{k}: {v:.2f}٪" for k, v in E.groupby('جهت')[col].mean().items()) if col in E else "-"))
    ans.append("10. معاملاتِ استاپ‌خورده‌ای که تا ۷۲ ساعت به TPِ اولیه رسیدن: " + (f"{100 * S['برگشت به TP'].mean():.1f}٪ (n={int(S['برگشت به TP'].notna().sum())})" if "برگشت به TP" in S else "-"))
    if "بعد از TP · ۷۲ ساعت: ادامه R" in E:
        c11 = E[E["نتیجه"] == "TP"].groupby("ترکیبِ MA200 (4h/1h/15m)")["بعد از TP · ۷۲ ساعت: ادامه R"].agg(["mean", "size"])
        c11 = c11[c11["size"] >= mn].sort_values("mean", ascending=False)
        ans.append("11. بیشترین ادامه بعد از TP: " + (f"{c11.index[0]} ({c11['mean'].iloc[0]:.2f}R، n={int(c11['size'].iloc[0])})" if len(c11) else "-"))
    if len(r4c):
        c12 = r4c.sort_values([c for c in r4c.columns if "ادامه R" in c][0], ascending=False) if any("ادامه R" in c for c in r4c.columns) else r4c
        ans.append("12. بیشترین ادامه‌یِ خلاف بعد از SL: " + (f"{c12.iloc[0]['جهت']} · {c12.iloc[0]['ترکیبِ MA200 (4h/1h/15m)']}" if len(c12) else "-"))
    L = ["# تحقیقِ شش‌ساله‌یِ فیبوناچی، MA200 و رفتارِ قیمت بعد از تارگت و استاپ", "",
         f"بازه: {ts(start)} تا {ts(end)} · بخش‌ها (زمانی): آموزش ۶۰٪ · اعتبارسنجی ۲۰٪ · آزمونِ نهایی ۲۰٪ · کارمزد {CFG['fee_pct']}٪ هر طرف",
         "قراردادها و الگوریتم: بالایِ fr.py مستند شده. TP = سطحِ ۰، SL = سطحِ ۱. «برگشتِ موفق kR» = رسیدن به k برابرِ ریسک قبل از SL.",
         "رتبه‌بندی‌ها رویِ «آموزش» و با حدِ پایینِ بازه‌یِ ۹۵٪ (خوشه‌یِ روزانه) — نمونه‌یِ کم برنده نمیشه. حداقلِ نمونه: " + str(mn), "",
         "## کیفیتِ داده", pd.DataFrame(Q).to_string(index=False), *notes, "",
         "## پاسخ به ۱۲ سؤال", *ans, "",
         "## گزارشِ ۱ — بهترین سطح برایِ هر نماد/تایم/جهت (آموزش، معیار: حدِ پایینِ برگشتِ 1R)", fmt(best1[K + ["لمس (رویدادِ مستقل)", "برگشت 1.0R٪", "برگشت 1.0R پایین۹۵٪", "نرخِ برد", "امید (R)"]]), "",
         "## گزارشِ ۲ — ترکیب‌هایِ MA200 (۱۵ ترکیبِ برتر بر اساسِ حدِ پایینِ امید)", fmt(r2.sort_values("امید پایین۹۵ (R)", ascending=False)[["نماد", "تایم", "جهت", "سطح", "ترکیبِ MA200 (4h/1h/15m)", "لمس (رویدادِ مستقل)", "نرخِ برد", "امید (R)", "امید پایین۹۵ (R)"]], 15), "",
         "## گزارشِ ۳ — بعد از TP (میانگینِ همه‌یِ بخش‌ها)", fmt(r3b, 30), "",
         "## گزارشِ ۴ — بعد از SL", fmt(r4, 30), "", "بر اساسِ ترکیبِ MA200:", fmt(r4c, 30), "",
         "## گزارشِ ۵ — لانگ و شورت · هم‌جهت/خلافِ MA200ِ 4h", fmt(r5b, 30), "",
         "## گزارشِ ۶ — رتبه‌بندی (۱۵ برتر در آموزش) و نتیجه‌شون در اعتبارسنجی و آزمونِ نهایی", fmt(CH, 15), "",
         "⚠️ رویدادهایِ هم‌پوشان (چند سطح از یه موج، چند پیووت) مستقل نیستن؛ خطاها با خوشه‌یِ روزانه حساب شدن ولی «بیشترین افت» تقریبیه (همه‌یِ رویدادها پشتِ‌سرِهم).",
         "جدول‌هایِ کامل: r1…r6 (CSV) · همه‌یِ رویدادها و پیووت/موج‌ها: events/*.csv.gz"]
    open(os.path.join(a.out, "fib_research_report.md"), "w", encoding="utf-8").write("\n".join(L))
    print("\n".join(L[:80]))


if __name__ == "__main__":
    main()
