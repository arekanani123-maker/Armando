# -*- coding: utf-8 -*-
"""v2: python run2.py --symbols BTC,ETH --years 6 --tfs 15m,1h --pivots 10,20,30,40,50 (قابلِ ادامه)."""
import os, sys, glob, time, argparse, math
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fr as FR, fr2 as F2

CFG = {"fee_pct": 0.05, "wait_bars": 500, "max_hold_bars": 5000, "min_n": 30, "margin": 20.0, "lev": 10.0, "capital": 500.0}
TPF = {"tp0": "سطحِ ۰", "tp05": "+۰.۵٪", "tp1": "+۱٪", "ext": "اکستنشن ‎-۰.۲۷"}
SLF = {"sl1": "سطحِ ۱", "sl05": "۰.۵٪ بازتر"}
CYF = {"none": "بدونِ چرخه", "15m": "چرخه 15m", "1h": "چرخه 1h", "4h": "چرخه 4h"}
XMF = {"none": "بدونِ مدیریت", "be1": "SL به ورود بعد از +۱R", "part1": "۵۰٪ در +۱R + SL به ورود"}
HOURS = {"all": "همه‌یِ ساعت‌ها", "ex12_16": "بدونِ ۱۲–۱۶ UTC"}
WAVES = {"between": "فعلی (بینِ دو سقف)", "lastpivot": "آخرین کفِ پیووت", "origin": "شروعِ کلِ حرکت"}


def long_table(E):
    ids = ["موج", "تایم", "جهت", "سطح", "پیووت", "بخش", "day", "ساعت", "f_align", "f_reg", "f_hid"]
    parts = []
    for tn in F2.TPS:
        for sn in F2.SLS:
            for cm in F2.CYCLES:
                for xm in F2.EXITS:
                    c = f"{tn}|{sn}|{cm}|{xm}"
                    if c not in E:
                        continue
                    d = E[ids].copy(); d["tp"], d["sl"], d["cyc"], d["xm"] = tn, sn, cm, xm
                    d["res"] = E[c].to_numpy(); d["R"] = E[f"R {c}"].to_numpy()
                    d["usd"] = d["R"] * E.get(f"R٪ {sn}", pd.Series(np.nan, index=E.index)).to_numpy() / 100 * CFG["margin"] * CFG["lev"]
                    d["t"] = E["زمانِ ورود"].to_numpy()
                    parts.append(d[d["res"] != "x"])
    return pd.concat(parts, ignore_index=True)


def agg(L, keys):
    out = []
    for fl, hr in [(f, h) for f in F2.FILTERS for h in HOURS]:
        sub = L if fl == "none" else L[L[f"f_{fl}"]]
        if hr == "ex12_16":
            sub = sub[~sub["ساعت"].between(12, 15)]
        sub = sub.assign(filter=fl, hours=hr)
        d = sub[sub["R"].notna()]
        kf = keys + ["filter", "hours"]
        g = d.groupby(kf)
        base = g["R"].agg(n="size", mean="mean", sum="sum").join(g["R"].apply(lambda x: (x > 0).mean()).rename("win"))
        base = base.join(g["usd"].agg(usd="sum")).join(d[d["usd"] > 0].groupby(kf)["usd"].sum().rename("usd_win")).join(d[d["usd"] <= 0].groupby(kf)["usd"].sum().rename("usd_loss"))
        dd = d.groupby(kf + ["day"])["R"].agg(s="sum", c="size").reset_index().merge(base["mean"].reset_index(), on=kf)
        dd["u"] = (dd["s"] - dd["mean"] * dd["c"]) ** 2
        cl = dd.groupby(kf).agg(U=("u", "sum"), D=("day", "size"))
        base = base.join(cl)
        base["se"] = np.sqrt(base["U"] * base["D"] / (base["D"] - 1).clip(lower=1)) / base["n"]
        base["low95"] = base["mean"] - 1.96 * base["se"]
        amb = sub.groupby(kf)["res"].agg(amb=lambda x: int((x == "مبهم").sum()), cyc_exit=lambda x: int((x == "چرخه").sum()))
        out.append(base.join(amb).reset_index())
    return pd.concat(out, ignore_index=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbols", default="BTC,ETH"); ap.add_argument("--years", type=float, default=6)
    ap.add_argument("--tfs", default="15m,1h"); ap.add_argument("--pivots", default="10,20,30,40,50")
    ap.add_argument("--cache", default="/content/fr_cache"); ap.add_argument("--out", default="/content/fr2_results"); ap.add_argument("--end", default=None)
    ap.add_argument("--waves", default="between,lastpivot,origin")
    ap.add_argument("--tps", default="tp0,tp05,tp1,ext"); ap.add_argument("--sls", default="sl1,sl05")
    ap.add_argument("--prz", type=int, default=1)
    ap.add_argument("--margin", type=float, default=20); ap.add_argument("--lev", type=float, default=10); ap.add_argument("--capital", type=float, default=500)
    ap.add_argument("--cycles", default="none,15m,1h,4h"); ap.add_argument("--exits", default="none,be1,part1")
    a = ap.parse_args()
    CFG.update(margin=a.margin, lev=a.lev, capital=a.capital)
    ev_dir = os.path.join(a.out, "events"); os.makedirs(ev_dir, exist_ok=True)
    end = int(pd.Timestamp(a.end, tz="UTC").value // 10**6) if a.end else int(time.time() * 1000) // 3_600_000 * 3_600_000
    start = end - int(a.years * 365.25 * 86_400_000)
    tfs = [x for x in a.tfs.split(",") if x]; pivs = [int(x) for x in a.pivots.split(",")]
    import ccxt
    ex = ccxt.okx({"enableRateLimit": True})
    Q = []
    for sym in [s.strip().upper() for s in a.symbols.split(",") if s.strip()]:
        D = {}
        for tf in ("5m", "15m", "1h", "4h"):
            print(f"  داده‌یِ {sym} {tf} ...", flush=True)
            D[tf] = FR.fetch(ex, sym, tf, start - 210 * FR.TF_MS["4h"], end, a.cache)
            Q.append({"نماد": sym, "تایم": tf, **FR.quality(D[tf], tf)})
        Fr = {tf: FR.Frame(D[tf], tf) for tf in D}
        for tf in tfs:
            F = Fr[tf]; cyc = F2.cycle_arrays(F, Fr); flags = F2.filter_flags(F)
            for wm in [w for w in a.waves.split(",") if w]:
              przc = F2.prz_context(Fr, tf, pivs, wm) if a.prz else None
              for n in pivs:
                p = os.path.join(ev_dir, f"{sym}_{tf}_p{n}_{wm}.csv.gz")
                if os.path.exists(p):
                    print(f"⏭  {sym} {tf} پیووت {n} {wm}", flush=True); continue
                t0 = time.time()
                ev = pd.DataFrame(F2.events2(F, Fr["5m"], Fr, cyc, flags, n, CFG, sym, wm, a.tps.split(","), a.sls.split(","), a.cycles.split(","), a.exits.split(","), przc))
                if len(ev):
                    ev = ev[ev["تأییدِ موج"] >= start]
                ev.to_csv(p, index=False, compression="gzip")
                print(f"💾 {sym} {tf} پیووت {n} {wm}: {len(ev)} رویداد ({time.time() - t0:.0f}s)", flush=True)
    E = pd.concat([pd.read_csv(f) for f in glob.glob(os.path.join(ev_dir, "*.csv.gz"))], ignore_index=True)
    report(E, a.out, start, end, pd.DataFrame(Q))
    if "prz_fib" in E:
        report_prz(E, a.out, start, end)


def report(E, out, start, end, Q):
    mn = CFG["min_n"]
    E = E.copy()
    E["بخش"] = FR.split_of(E["تأییدِ موج"], start, end)
    E["day"] = E["زمانِ ورود"] // 86_400_000
    L = long_table(E)
    if "موج" not in E:
        E["موج"] = "between"
    K = ["موج", "تایم", "جهت", "tp", "sl", "cyc", "xm"]
    A = agg(L, K + ["بخش"]); A_all = agg(L, K)
    full = agg(L, ["موج", "تایم", "جهت", "سطح", "پیووت", "tp", "sl", "cyc", "xm", "بخش"])
    full.to_csv(os.path.join(out, "v2_all_combos_by_split.csv"), index=False)
    lab = lambda d: d.assign(TP=d["tp"].map(TPF), SL=d["sl"].map(SLF), چرخه=d["cyc"].map(CYF), فیلتر=d["filter"].map(F2.FILTER_FA), روشِ_موج=d["موج"].map(WAVES),
                             خروج=d["xm"].map(XMF), ساعتِ_ورود=d["hours"].map(HOURS))
    xh = lab(A_all[(A_all["cyc"] == "none") & (A_all["filter"] == "none")])
    xh_t = lab(A[(A["بخش"] == "آزمونِ نهایی") & (A["cyc"] == "none") & (A["filter"] == "none")])
    one = lambda d: d[(d["xm"] == "none") & (d["hours"] == "all")]
    A_all, A = one(A_all), one(A)
    sec = []
    sec += ["## مدیریتِ خروج × ساعتِ ورود (بدونِ چرخه و فیلترِ ورود) · امید در هر معامله (R)",
            xh.pivot_table(index=["روشِ_موج", "تایم", "جهت", "TP", "SL"], columns=["خروج", "ساعتِ_ورود"], values="mean").round(3).to_string(), "",
            "### همون جدول — فقط آزمونِ نهایی",
            xh_t.pivot_table(index=["روشِ_موج", "تایم", "جهت", "TP", "SL"], columns=["خروج", "ساعتِ_ورود"], values="mean").round(3).to_string(), ""]
    wv = lab(A_all[(A_all["cyc"] == "none") & (A_all["filter"] == "none")])
    sec += ["### مقایسه‌یِ روشِ موج — TP × SL (بدونِ چرخه و فیلتر) · امید (R)",
            wv.pivot_table(index=["تایم", "جهت", "TP", "SL"], columns="روشِ_موج", values="mean").round(3).to_string(),
            wv.pivot_table(index=["تایم", "جهت", "TP", "SL"], columns="روشِ_موج", values="n").to_string(), ""]
    for (wm_, tf, sd), g in A_all.groupby(["موج", "تایم", "جهت"]):
        g0 = lab(g[(g["cyc"] == "none") & (g["filter"] == "none")])
        sec += [f"### {WAVES.get(wm_, wm_)} · {tf} · {sd} — TP × SL (بدونِ چرخه و فیلتر) · امید در هر معامله (R)",
                g0.pivot_table(index="TP", columns="SL", values="mean").round(3).to_string(), ""]
        g1 = lab(g[(g["tp"] == "tp0") & (g["sl"] == "sl1")])
        sec += [f"### {WAVES.get(wm_, wm_)} · {tf} · {sd} — چرخه × فیلتر (TP سطحِ ۰، SL سطحِ ۱) · امید (R) و تعداد",
                g1.pivot_table(index="چرخه", columns="فیلتر", values="mean").round(3).to_string(),
                g1.pivot_table(index="چرخه", columns="فیلتر", values="n").to_string(), ""]
    allk = ["موج", "تایم", "جهت", "سطح", "پیووت", "tp", "sl", "cyc", "xm", "filter", "hours"]
    money = full.groupby(allk)[["n", "sum", "usd", "usd_win", "usd_loss"]].sum().reset_index()
    money = money[money["n"] >= 100].sort_values("usd", ascending=False)
    dd_rows = []
    for _, r in money.head(30).iterrows():
        sub = L
        for k in ("موج", "تایم", "جهت", "tp", "sl", "cyc", "xm"):
            sub = sub[sub[k] == r[k]]
        sub = sub[np.isclose(sub["سطح"], r["سطح"]) & (sub["پیووت"] == r["پیووت"])]
        if r["filter"] != "none":
            sub = sub[sub[f"f_{r['filter']}"]]
        if r["hours"] == "ex12_16":
            sub = sub[~sub["ساعت"].between(12, 15)]
        u = sub[sub["usd"].notna()].sort_values("t")["usd"].to_numpy()
        eq = CFG["capital"] + np.cumsum(u)
        dd_rows.append({**{k: r[k] for k in allk}, "معاملات": len(u), "برد": int((u > 0).sum()), "باخت": int((u <= 0).sum()),
                        "جمعِ سود $": round(u[u > 0].sum(), 1), "جمعِ ضرر $": round(u[u <= 0].sum(), 1), "خالص $": round(u.sum(), 1),
                        "سرمایه‌یِ پایانی $": round(eq[-1], 1) if len(eq) else CFG["capital"],
                        "بیشترین افت $": round(float((eq - np.maximum.accumulate(np.r_[CFG["capital"], eq])[1:]).min()), 1) if len(eq) else 0})
    MON = pd.DataFrame(dd_rows)
    MON.to_csv(os.path.join(out, "v4_money_top30.csv"), index=False)
    tr = full[full["بخش"] == "آموزش"]; tr = tr[tr["n"] >= mn].sort_values("low95", ascending=False).head(25)
    key = ["موج", "تایم", "جهت", "سطح", "پیووت", "tp", "sl", "cyc", "xm", "filter", "hours"]
    chk = tr[key + ["n", "mean", "low95"]].rename(columns={"n": "n آموزش", "mean": "امید آموزش", "low95": "پایین۹۵ آموزش"})
    for part in ("اعتبارسنجی", "آزمونِ نهایی"):
        p_ = full[full["بخش"] == part][key + ["n", "mean"]].rename(columns={"n": f"n {part}", "mean": f"امید {part}"})
        chk = chk.merge(p_, on=key, how="left")
    piv = full.pivot_table(index=key, columns="بخش", values=["mean", "n"])
    piv.columns = [f"{a_} {b_}" for a_, b_ in piv.columns]
    allpos = piv[(piv.filter(like="n ").min(axis=1) >= mn) & (piv.filter(like="mean ").min(axis=1) > 0)].reset_index()
    cyc_cols = [c for c in E.columns if c.startswith("بعد از چرخه")]
    after = pd.concat([E[c].value_counts(normalize=True).rename(c) for c in cyc_cols], axis=1).T.round(3) if cyc_cols else pd.DataFrame()
    T = ["# تحقیقِ فیبوناچی v2 — TP، SL، تغییرِ چرخه و فیلترِ ورود (BTC، ETH · ۶ سال · 15m و 1h · پیووتِ ۱۰ تا ۵۰)", "",
         "تعریف‌ها: بالایِ fr2.py. امید = سودِ خالص در هر معامله برحسبِ R (R = فاصله‌یِ ورود تا SLِ همون نسخه)، بعد از کارمزدِ ۰.۰۵٪ هر طرف.",
         "بخش‌ها: آموزش ۶۰٪ · اعتبارسنجی ۲۰٪ · آزمونِ نهایی ۲۰٪ (زمانی). سطوح و پیووت‌ها در جدول‌هایِ خلاصه با هم جمع شدن (هم‌پوشان، مستقل نیستن).", "",
         "## داده", Q.to_string(index=False), "", "## خلاصه‌یِ هر تایم و جهت (همه‌یِ بخش‌ها)", *sec,
         "## آزمونِ نهایی: TP × SL (بدونِ چرخه و فیلتر)",
         lab(A[(A["بخش"] == "آزمونِ نهایی") & (A["cyc"] == "none") & (A["filter"] == "none")]).pivot_table(index=["روشِ_موج", "تایم", "جهت", "TP"], columns="SL", values="mean").round(3).to_string(), "",
         "## آزمونِ نهایی: چرخه × فیلتر (TP و SLِ پایه)",
         lab(A[(A["بخش"] == "آزمونِ نهایی") & (A["tp"] == "tp0") & (A["sl"] == "sl1")]).pivot_table(index=["روشِ_موج", "تایم", "جهت", "چرخه"], columns="فیلتر", values="mean").round(3).to_string(), "",
         f"## ۲۵ ترکیبِ برتر در آموزش (حدِ پایینِ ۹۵٪، حداقل {mn} معامله) و نتیجه‌شون بعداً", chk.round(3).to_string(index=False), "",
         f"## ترکیب‌هایی که در **هر سه بخش** مثبت بودن (حداقل {mn} معامله در هر بخش): {len(allpos)} از {len(piv)}",
         allpos.round(3).head(40).to_string(index=False) if len(allpos) else "هیچ", "",
         f"## ۳۰ ترکیب با بیشترین سودِ دلاری (مارجین ${CFG['margin']:g} × لوریج {CFG['lev']:g} = ${CFG['margin'] * CFG['lev']:g} هر معامله · سرمایه‌یِ اولیه ${CFG['capital']:g} · حداقل ۱۰۰ معامله)",
         "هر معامله جدا حساب شده (هم‌پوشانیِ زمانیِ پوزیشن‌ها محدود نشده)؛ «بیشترین افت» به ترتیبِ زمانِ ورود.",
         MON.to_string(index=False) if len(MON) else "-", "",
         "## بعد از خروج با تغییرِ چرخه (TP/SLِ پایه): قیمت بعدش اول به کدوم رسید", after.to_string() if len(after) else "-", "",
         "⚠️ ۱۲۸ ترکیب × سطح × پیووت = هزاران آزمون؛ چند ترکیبِ «مثبت در هر سه بخش» از شانس هم انتظار میره. همه‌یِ اعداد: v2_all_combos_by_split.csv"]
    open(os.path.join(out, "fib_v2_report.md"), "w", encoding="utf-8").write("\n".join(T))
    print("\n".join(T[:120]))


PRZ = {"none": "بدونِ PRZ", "fib": "همپوشانیِ فیبو", "sr": "حمایت/مقاومت", "both": "هر دو", "any": "هر کدوم"}
HR6 = {"all": "همه‌یِ ساعت‌ها", "ex4_8_16_20": "بدونِ ۴–۸ و ۱۶–۲۰", "ex12_16": "بدونِ ۱۲–۱۶"}


def report_prz(E, out, start, end, level=0.618):
    """v6: فقط ورودِ ۰.۶۱۸ · PRZ × حداقلِ فاصله‌یِ SL × ساعت (فیلترِ ورودِ RSI خاموش)."""
    E = E[np.isclose(E["سطح"], level)].copy()
    E["بخش"] = FR.split_of(E["تأییدِ موج"], start, end)
    rows = []
    for tn in F2.TPS:
        for sn in F2.SLS:
            for cm in F2.CYCLES:
                for xm in F2.EXITS:
                    c = f"{tn}|{sn}|{cm}|{xm}"
                    if c not in E:
                        continue
                    d = E[["موج", "تایم", "جهت", "پیووت", "بخش", "ساعت", "prz_fib", "prz_sr", "زمانِ ورود"]].copy()
                    d["tp"], d["sl"], d["cyc"], d["xm"] = tn, sn, cm, xm
                    d["R"] = E[f"R {c}"].to_numpy(); d["slp"] = E[f"R٪ {sn}"].to_numpy()
                    d["usd"] = d["R"] * d["slp"] / 100 * CFG["margin"] * CFG["lev"]
                    rows.append(d[d["R"].notna()])
    L = pd.concat(rows, ignore_index=True)
    fb, sr = L["prz_fib"].astype(bool), L["prz_sr"].astype(bool)
    pm = {"none": pd.Series(True, index=L.index), "fib": fb, "sr": sr, "both": fb & sr, "any": fb | sr}
    hm = {"all": pd.Series(True, index=L.index), "ex4_8_16_20": ~(L["ساعت"].between(4, 7) | L["ساعت"].between(16, 19)), "ex12_16": ~L["ساعت"].between(12, 15)}
    K = ["موج", "تایم", "جهت", "پیووت", "tp", "sl", "cyc", "xm", "بخش"]
    parts = []
    for pz, m1 in pm.items():
        for ms in (0, 1, 2, 3):
            m2 = L["slp"] >= ms
            for hr, m3 in hm.items():
                d = L[m1 & m2 & m3]
                g = d.groupby(K).agg(n=("R", "size"), R=("R", "sum"), usd=("usd", "sum"), win=("R", lambda x: (x > 0).mean())).reset_index()
                g["prz"], g["minSL"], g["hours"] = pz, ms, hr
                parts.append(g)
    G = pd.concat(parts, ignore_index=True)
    G.to_csv(os.path.join(out, "v6_prz_0618_by_split.csv"), index=False)
    k2 = [k for k in K if k != "بخش"] + ["prz", "minSL", "hours"]
    T = G.groupby(k2).agg(n=("n", "sum"), R=("R", "sum"), usd=("usd", "sum")).reset_index()
    T["امید"] = T["R"] / T["n"]
    for b in ("آموزش", "اعتبارسنجی", "آزمونِ نهایی"):
        x = G[G["بخش"] == b].set_index(k2)
        T = T.join((x["R"] / x["n"]).rename(f"امید {b}"), on=k2).join(x["n"].rename(f"n {b}"), on=k2)
    pool = lambda q: q.groupby(["موج", "تایم", "جهت", "prz", "minSL", "hours"]).agg(n=("n", "sum"), R=("R", "sum"), usd=("usd", "sum")).reset_index().assign(امید=lambda z: z["R"] / z["n"])
    base = T[(T["tp"] == "tp1") & (T["sl"] == "sl1") & (T["cyc"] == "none") & (T["xm"] == "none")]
    P1 = pool(base)
    lab = lambda d: d.assign(PRZ=d["prz"].map(PRZ), ساعت=d["hours"].map(HR6))
    sec = []
    for (wm, tf, sd), g in lab(P1).groupby(["موج", "تایم", "جهت"]):
        sec += [f"### {wm} · {tf} · {sd} · TP +۱٪ · SL سطحِ ۱ — امید (R) · PRZ × حداقلِ SL٪ (همه‌یِ ساعت‌ها)",
                g[g["hours"] == "all"].pivot_table(index="PRZ", columns="minSL", values="امید").round(3).to_string(),
                g[g["hours"] == "all"].pivot_table(index="PRZ", columns="minSL", values="n").to_string(),
                "PRZ × ساعت (بدونِ حداقلِ SL):", g[g["minSL"] == 0].pivot_table(index="PRZ", columns="ساعت", values="امید").round(3).to_string(), ""]
    top = T[T["n"] >= 100].sort_values("usd", ascending=False).head(30)
    m20 = T[[c for c in T if c.startswith("n ")]].min(axis=1) >= 20
    allp = T[m20 & (T[["امید آموزش", "امید اعتبارسنجی", "امید آزمونِ نهایی"]] > 0).all(axis=1)].sort_values("usd", ascending=False).head(30)
    cols = k2 + ["n", "امید", "usd", "امید آموزش", "امید اعتبارسنجی", "امید آزمونِ نهایی"]
    txt = ["# v6 — ورودِ ۰.۶۱۸ با تأییدِ PRZ، حداقلِ فاصله‌یِ SL و فیلترِ ساعت", "",
           "PRZ: همپوشانیِ فیبو = سطحِ ۰.۵/۰.۶۱۸/۰.۷۸۶ از آخرین موجِ تأییدشده‌یِ هم‌جهتِ بقیه‌یِ پیووت‌ها (همین تایم و تایمِ بالاتر) تا ۰.۳٪ ·",
           "حمایت/مقاومت = سقف/کفِ پیووتِ ۵ (همین تایم و تایمِ بالاتر، ۵۰۰ کندلِ اخیر) تا ۰.۳٪ · فقط منابعِ تأییدشده قبل از ورود.",
           f"دلار: مارجین ${CFG['margin']:g} × {CFG['lev']:g} = ${CFG['margin'] * CFG['lev']:g} هر معامله.", "", *sec,
           "## ۳۰ ترکیب با بیشترین سودِ دلاری (حداقل ۱۰۰ معامله)", top[cols].round(3).to_string(index=False), "",
           "## مثبت در هر سه بخش (حداقل ۲۰ معامله در هر بخش) — ۳۰ تا با بیشترین سود", allp[cols].round(3).to_string(index=False) if len(allp) else "هیچ"]
    open(os.path.join(out, "v6_prz_report.md"), "w", encoding="utf-8").write("\n".join(txt))
    T.to_csv(os.path.join(out, "v6_prz_0618_all.csv"), index=False)
    print("\n".join(txt[:60]))


if __name__ == "__main__":
    main()
