# -*- coding: utf-8 -*-
"""
Angelina Studio — موتورِ قابلِ‌تنظیم برایِ بک‌تستِ فیبوناچی (پیش‌فرض‌ها = Angelina).
قراردادها مثلِ fr.py: موجِ صعودی سطحِ ۱ = کف، سطحِ ۰ = سقف (شورت قرینه) · فقط کندلِ بسته‌شده و پیووتِ تأییدشده ·
مسیرِ قیمت رویِ تایمِ ورود · کندلی که هم SL هم تارگت رو لمس کنه ← SL · کارمزد برایِ هر بخش.
"""
import os, json, time
import numpy as np, pandas as pd
import fr as FR, fr2 as F2, fr7 as F7, run_angelina as A, angelina2 as A2

DEFAULT = {
    "symbols": ["BTC", "ETH", "SOL", "XRP", "ADA", "DOGE", "SUI"], "days": 2191, "end": None,
    "capital": 500.0, "margin": 20.0, "lev": 10.0, "fee_pct": 0.05, "max_positions": 0,
    "fib_tf": "4h", "pivot": 20, "wave": "B", "log_scale": False,
    "entry_level": 0.618, "entry_tf": "5m", "entry_mode": "direct", "entry_pivot": 10, "gap": "market", "sides": "both",
    "sl_level": 1.0, "sl_pad_pct": 0.0,
    "targets": [{"kind": "level_plus", "value": 1.0, "frac": 100}], "be_after": 0,
    "ma200_tf": "off", "wrong_side_div": True, "div_tf": "4h", "strong_rsi_diff": 5.0, "strong_rsi_long": 30.0, "strong_rsi_short": 70.0,
    "min_sl_pct": 0.0, "bad_hours": [], "wait_fib_bars": 500, "max_hold_fib_bars": 5000,
}
WAVE = {"A": "origin", "B": "bos", "C": "lastpivot"}


def level(p1, p0, r, log=False):
    if log:
        return float(np.exp(np.log(p0) + r * (np.log(p1) - np.log(p0))))
    return p0 + r * (p1 - p0)


def target_price(t, p1, p0, side, log):
    if t["kind"] == "level":
        return level(p1, p0, float(t["value"]), log)
    if t["kind"] == "ext":                                                   # اکستنشنِ k (۱.۲۷، ۱.۶۱۸، ۲.۰ …) = سطحِ ۱ − k
        return level(p1, p0, 1 - float(t["value"]), log)
    if t["kind"] == "level_plus":
        return p0 * (1 + side * float(t["value"]) / 100)
    return None                                                              # div


def simulate(P, e, side, entry, sl, targets, fracs, be_after, div_ok, Fdiv, max_bars):
    """P = فریمِ مسیر (تایمِ ورود). targets: قیمت یا None (واگرایی). خروجی: [(سهم، قیمت، برچسب، زمانِ ms)]."""
    end = min(len(P.H), e + 1 + max_bars)
    H, L, C, T = P.H, P.L, P.C, P.t
    if (L[e] <= sl) if side == 1 else (H[e] >= sl):
        return [(1.0, sl, "SL", int(P.ct[e]))]
    out, rem, stop, s_tp, s_st = [], 1.0, sl, e + 1, e + 1
    for k, (px, fr_) in enumerate(zip(targets, fracs)):
        lab_stop = "SL" if stop == sl else "SL در ورود"
        st_m = (L[s_st:end] <= stop) if side == 1 else (H[s_st:end] >= stop)
        j_st = FR._first(st_m); j_st = None if j_st is None else s_st + j_st
        if px is None:                                                       # واگراییِ قویِ مخالف
            t0 = int(P.ct[s_tp]) if k > 0 else int(P.ct[e])                # از لحظه‌یِ تارگتِ قبلی (یا ورود)
            cand = np.flatnonzero(div_ok & (Fdiv.ct >= t0))
            kd = int(np.searchsorted(T, Fdiv.ct[cand[0]])) if len(cand) else end
            if j_st is not None and j_st < kd:
                out.append((rem, stop, lab_stop, int(P.ct[j_st]))); return out
            if len(cand) and kd < end:
                out.append((fr_, float(Fdiv.C[cand[0]]), f"TP{k + 1} واگرایی", int(Fdiv.ct[cand[0]]))); rem -= fr_
                j_tp = kd
            else:
                out.append((rem, float(C[end - 1]), "پایانِ داده", int(P.ct[end - 1]))); return out
        else:
            tp_m = (H[s_tp:end] >= px) if side == 1 else (L[s_tp:end] <= px)
            j_tp = FR._first(tp_m); j_tp = None if j_tp is None else s_tp + j_tp
            if j_tp is None or (j_st is not None and j_st <= j_tp):
                if j_st is not None:
                    out.append((rem, stop, lab_stop, int(P.ct[j_st]))); return out
                out.append((rem, float(C[end - 1]), "پایانِ داده", int(P.ct[end - 1]))); return out
            out.append((fr_, px, f"TP{k + 1}", int(P.ct[j_tp]))); rem -= fr_
        s_tp = j_tp; s_st = j_tp + 1
        if be_after == k + 1:
            stop = entry
        if rem <= 1e-9:
            return out
    return out


def load(cfg, cache, log=print):
    import ccxt
    ex = ccxt.okx({"enableRateLimit": True})
    end = int(pd.Timestamp(cfg["end"], tz="UTC").value // 10**6) if cfg.get("end") else int(time.time() * 1000) // 3_600_000 * 3_600_000
    start = end - int(cfg["days"] * 86_400_000)
    tfs = {cfg["fib_tf"], cfg["entry_tf"]}
    if cfg["ma200_tf"] != "off":
        tfs |= {cfg["ma200_tf"], cfg["div_tf"]}
    if any(t["kind"] == "div" for t in cfg["targets"]):
        tfs.add(cfg["div_tf"])
    data = {}
    for sym in cfg["symbols"]:
        try:
            D = {}
            for tf in tfs:
                warm = max(240 * FR.TF_MS[tf], (10 * cfg["pivot"] + 60) * FR.TF_MS[cfg["fib_tf"]])
                D[tf] = FR.Frame(FR.fetch(ex, sym, tf, start - warm, end, cache), tf)
            if len(D[cfg["entry_tf"]].t) < 500:
                log(f"  {sym}: داده‌یِ کافی نیست"); continue
            data[sym] = D
            log(f"  {sym}: آماده")
        except Exception as e:                                               # noqa: BLE001
            log(f"  {sym}: داده نیومد ({e})")
    return data, start, end


def events(cfg, data, start):
    c2 = {"rsi_len": 14, "pivot_lr": 3, "pivot_gap": [5, 60], "div_valid_bars": 10, "strong_rsi_diff": cfg["strong_rsi_diff"],
          "strong_rsi_long": cfg["strong_rsi_long"], "strong_rsi_short": cfg["strong_rsi_short"]}
    pos = cfg["margin"] * cfg["lev"]; fee = cfg["fee_pct"] / 100
    fr_ = [float(t["frac"]) for t in cfg["targets"]]; fr_ = [f / sum(fr_) for f in fr_]
    rows = []
    for sym, D in data.items():
        Fw, P = D[cfg["fib_tf"]], D[cfg["entry_tf"]]
        ctx = {}
        if cfg["entry_mode"] in ("close", "ma"):
            ctx = F7.m15_context(P)
        if cfg["entry_mode"] == "bos":
            ctx = F7.bos_flags(P, [cfg["entry_pivot"]])
        mode = {"direct": "direct", "close": "close", "ma": "ma", "bos": f"bos5_{cfg['entry_pivot']}"}[cfg["entry_mode"]]
        Fdiv = D.get(cfg["div_tf"]); dflags = A2.div_flags(Fdiv, c2) if Fdiv is not None else None
        Fma = D.get(cfg["ma200_tf"]) if cfg["ma200_tf"] != "off" else None
        fac = max(1, FR.TF_MS[cfg["fib_tf"]] // FR.TF_MS[cfg["entry_tf"]])
        for (k, side, i0, j, p1, p0) in FR.waves(Fw, cfg["pivot"], WAVE.get(cfg["wave"], cfg["wave"])):
            if (cfg["sides"] == "long" and side != 1) or (cfg["sides"] == "short" and side != -1):
                continue
            t_conf = int(Fw.ct[k])
            if t_conf < start:
                continue
            a = int(np.searchsorted(P.t, t_conf))
            if a >= len(P.t):
                continue
            stop = min(len(P.t), a + cfg["wait_fib_bars"] * fac)
            lv = level(p1, p0, cfg["entry_level"], cfg["log_scale"])
            sl = level(p1, p0, cfg["sl_level"], cfg["log_scale"]) * (1 - side * cfg["sl_pad_pct"] / 100)
            base = {"نماد": sym, "جهت": "لانگ" if side == 1 else "شورت", "تأییدِ موج": t_conf, "P1": p1, "P0": p0}
            e, entry, st = F7.find_entry(P, ctx, mode, side, lv, sl, p0, a, stop, cfg["gap"], level(p1, p0, 0.786, cfg["log_scale"]))
            if e is None:
                rows.append({**base, "وضعیت": st}); continue
            if not ((sl < entry < p0) if side == 1 else (p0 < entry < sl)):
                rows.append({**base, "وضعیت": "ورود خارج از محدوده"}); continue
            R = abs(entry - sl); slp = R / entry * 100; hour = int(P.t[e] // 3_600_000 % 24)
            why = None
            if slp < cfg["min_sl_pct"]:
                why = "فیلتر: حداقلِ SL"
            elif hour in cfg["bad_hours"]:
                why = "فیلتر: ساعت"
            elif Fma is not None:
                jm = Fma.closed_idx(np.array([int(P.t[e])]))[0]
                if jm < 0 or not np.isfinite(Fma.ma[jm]):
                    why = "فیلتر: MA200 نامعلوم"
                elif np.sign(Fma.C[jm] - Fma.ma[jm]) * side <= 0:
                    jd = Fdiv.closed_idx(np.array([int(P.t[e])]))[0]
                    okd = jd >= 0 and bool((dflags["bull_strong"] | dflags["bull_hid"])[jd] if side == 1 else (dflags["bear_strong"] | dflags["bear_hid"])[jd])
                    if not (cfg["wrong_side_div"] and okd):
                        why = "فیلتر: سمتِ غلطِ MA200"
            if why:
                rows.append({**base, "وضعیت": why}); continue
            tg = [target_price(t, p1, p0, side, cfg["log_scale"]) for t in cfg["targets"]]
            if any(x is not None and (x - entry) * side <= 0 for x in tg):
                rows.append({**base, "وضعیت": "تارگت در سمتِ ضرر"}); continue
            div_ok = None
            if any(x is None for x in tg):
                div_ok = dflags["bear_strong"] if side == 1 else dflags["bull_strong"]
            parts = simulate(P, e, side, entry, sl, tg, fr_, cfg["be_after"], div_ok, Fdiv, cfg["max_hold_fib_bars"] * fac)
            gross = sum(f * side * (px - entry) / entry for f, px, _, _ in parts)
            fees = fee + sum(f * fee * px / entry for f, px, _, _ in parts)
            rows.append({**base, "وضعیت": "ورود", "زمانِ ورود": int(P.t[e]), "ساعت": hour, "ورود": entry, "SL٪": slp,
                         "$ single": (gross - fees) * pos, "R single": (gross - fees) * entry / R,
                         "مدت single": (max(p[3] for p in parts) - int(P.t[e])) / 3.6e6, "خروج single": "+".join(p[2] for p in parts)})
    return pd.DataFrame(rows)


def portfolio(d, cap, margin, max_pos=0):
    ev = [(t, 1, i) for i, t in enumerate(d["خروج_ms"])] + [(t, 2, i) for i, t in enumerate(d["زمانِ ورود"])]
    ev.sort()
    eq, used, open_sym, taken, mx = cap, 0.0, set(), np.zeros(len(d), bool), 0
    for t, kind, i in ev:
        sym = d.at[i, "نماد"]
        if kind == 1 and taken[i]:
            eq += d.at[i, "$ single"]; used -= margin; open_sym.discard(sym)
        elif kind == 2:
            if sym in open_sym or eq - used < margin or (max_pos and len(open_sym) >= max_pos):
                continue
            taken[i] = True; used += margin; open_sym.add(sym); mx = max(mx, len(open_sym))
    return taken, mx


def report(cfg, E, start, end, out):
    os.makedirs(out, exist_ok=True)
    json.dump(cfg, open(os.path.join(out, "settings.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    d = E[(E["وضعیت"] == "ورود") & E["$ single"].notna()].copy() if len(E) else pd.DataFrame()
    status = E["وضعیت"].value_counts().to_dict() if len(E) else {}
    if not len(d):
        txt = "# Angelina Studio — هیچ معامله‌ای\n\nوضعیتِ ستاپ‌ها: " + str(status)
        open(os.path.join(out, "report.md"), "w", encoding="utf-8").write(txt); print(txt); return txt
    d["خروج_ms"] = d["زمانِ ورود"] + (d["مدت single"] * 3.6e6).astype("int64")
    d = d.sort_values("زمانِ ورود").reset_index(drop=True)
    taken, mx = portfolio(d, cfg["capital"], cfg["margin"], cfg["max_positions"])
    t = d[taken].sort_values("خروج_ms").reset_index(drop=True)
    u = t["$ single"].to_numpy(); cap = cfg["capital"]
    eq = cap + np.cumsum(u); pk = np.maximum.accumulate(np.r_[cap, eq])[1:]
    i = int(np.argmin(eq - pk)); w, l = u[u > 0].sum(), -u[u <= 0].sum()
    st = A.streaks(u); (ln, ls, la, lb), lruns = st["باخت"]; (wn, ws, wa, wb), _ = st["برد"]
    dt = lambda k: pd.to_datetime(t.loc[k, "خروج_ms"], unit="ms").date() if k is not None else "-"
    t["سال"] = pd.to_datetime(t["خروج_ms"], unit="ms").dt.year
    M = t.groupby(pd.to_datetime(t["خروج_ms"], unit="ms").dt.to_period("M"))["$ single"].sum().reindex(
        pd.period_range(pd.Timestamp(start, unit="ms").to_period("M"), pd.Timestamp(end, unit="ms").to_period("M"), freq="M"), fill_value=0)
    Y = t.groupby("سال")["$ single"].agg(معاملات="size", سود="sum").round(1)
    Y["سرمایه‌یِ پایانِ سال"] = pd.Series(eq, index=t["سال"]).groupby(level=0).last().round(0)
    S = t.groupby("نماد")["$ single"].agg(معاملات="size", سود="sum").round(1)
    S["برد٪"] = t.groupby("نماد")["$ single"].apply(lambda x: round(100 * (x > 0).mean(), 1))
    paths = t["خروج single"].value_counts().head(10)
    ts = lambda ms: pd.Timestamp(int(ms), unit="ms").strftime("%Y-%m-%d")
    tg = " · ".join(f"TP{k + 1}: {x['kind']}{'' if x['kind'] == 'div' else ' ' + str(x['value'])} ({x['frac']}٪)" for k, x in enumerate(cfg["targets"]))
    txt = [f"# Angelina Studio — {ts(start)} تا {ts(end)} · {E['نماد'].nunique()} نماد · ${cap:g} · ${cfg['margin']:g} × {cfg['lev']:g}", "",
           f"فیبو {cfg['fib_tf']} · پیووت {cfg['pivot']} · روش {cfg['wave']} · {'لگاریتمی' if cfg['log_scale'] else 'خطی'} · ورود {cfg['entry_level']} رویِ {cfg['entry_tf']} ({cfg['entry_mode']}) · جهت {cfg['sides']}",
           f"SL سطحِ {cfg['sl_level']} + {cfg['sl_pad_pct']}٪ · {tg} · SL به ورود بعد از TP{cfg['be_after'] or '—'}",
           f"فیلتر: MA200 {cfg['ma200_tf']} (سمتِ غلط با واگرایی: {cfg['wrong_side_div']}) · حداقلِ SL {cfg['min_sl_pct']}٪ · ساعت‌هایِ ممنوع {cfg['bad_hours'] or '—'}", "",
           "## نتیجه",
           f"- **معاملات: {len(u)}** (برد {int((u > 0).sum())} · باخت {int((u <= 0).sum())} · برد٪ {100 * (u > 0).mean():.1f}) · لانگ {int((t['جهت'] == 'لانگ').sum())} · شورت {int((t['جهت'] == 'شورت').sum())}",
           f"- **سرمایه: ${cap:g} → ${eq[-1]:,.0f}** (خالص ${u.sum():+,.0f}) · PF {w / l if l else float('inf'):.2f} · میانگینِ هر معامله ${u.mean():+.2f} (برد ${u[u > 0].mean() if (u > 0).any() else 0:+.2f} · باخت ${u[u <= 0].mean() if (u <= 0).any() else 0:+.2f})",
           f"- **Drawdown: ${(eq - pk).min():,.0f}** (از ${pk[i]:,.0f} به ${eq[i]:,.0f}، تا {dt(i)}) · کمترین سرمایه ${eq.min():,.0f}",
           f"- **ضررِ متوالی: {ln}** (${ls:+,.0f}، {dt(la)} تا {dt(lb)}) · **سودِ متوالی: {wn}** (${ws:+,.0f})",
           f"- رشته‌هایِ باخت: {lruns}",
           f"- میانگینِ ماهانه ${M.mean():+.1f} · ماهِ مثبت/منفی {int((M > 0).sum())}/{int((M < 0).sum())} · معامله در ماه {len(u) / max(1, len(M)):.1f} · حداکثر هم‌زمان {mx}", "",
           "## مسیرِ خروج", " · ".join(f"{k}: {v}" for k, v in paths.items()), "",
           "## وضعیتِ همه‌یِ ستاپ‌ها (قبل از سرمایه)", " · ".join(f"{k}: {v}" for k, v in status.items()), "",
           "## سالانه", Y.to_string(), "", "## نمادها", S.sort_values("سود", ascending=False).to_string(), "",
           "## ماهانه ($)", " ".join(f"{str(k)[2:]}:{v:+.0f}" for k, v in M.items())]
    txt = "\n".join(txt)
    open(os.path.join(out, "report.md"), "w", encoding="utf-8").write(txt)
    json.dump({"اجرا": os.path.basename(out), "معاملات": int(len(u)), "برد٪": round(100 * float((u > 0).mean()), 1), "سرمایه‌یِ پایانی": round(float(eq[-1]), 0),
               "خالص": round(float(u.sum()), 0), "PF": round(float(w / l), 2) if l else None, "Drawdown": round(float((eq - pk).min()), 0),
               "ضررِ متوالی": int(ln), "سودِ متوالی": int(wn), "ماهانه": round(float(M.mean()), 1)},
              open(os.path.join(out, "metrics.json"), "w", encoding="utf-8"), ensure_ascii=False)
    t.assign(**{"زمانِ ورود": pd.to_datetime(t["زمانِ ورود"], unit="ms")})[["نماد", "جهت", "زمانِ ورود", "ورود", "SL٪", "خروج single", "$ single"]].to_csv(
        os.path.join(out, "trades.csv"), index=False, encoding="utf-8-sig")
    print(txt)
    return txt


def run(cfg, cache="/content/fr_cache", runs_dir="/content/studio_runs", name=None):
    c = dict(DEFAULT); c.update(cfg or {})
    data, start, end = load(c, cache)
    E = events(c, data, start)
    out = os.path.join(runs_dir, name or time.strftime("%Y%m%d_%H%M%S"))
    return report(c, E, start, end, out), out


def compare(runs_dir="/content/studio_runs"):
    rows = []
    for d in sorted(os.listdir(runs_dir)) if os.path.isdir(runs_dir) else []:
        m = os.path.join(runs_dir, d, "metrics.json")
        if os.path.exists(m):
            rows.append(json.load(open(m, encoding="utf-8")))
    return pd.DataFrame(rows)
