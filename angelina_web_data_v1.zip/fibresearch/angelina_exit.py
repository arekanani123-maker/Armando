# -*- coding: utf-8 -*-
"""
خروجِ جدید برایِ Angelina و Angelina2 (ورود و فیبو بدونِ تغییر؛ فقط خروج دوباره شبیه‌سازی میشه):
  SL = ۰.۰۹٪ اونطرفِ سطحِ ۱ · TP1 = سطحِ ۰ → ۵۰٪ (SL سرِ جاش) · TP2 = اکستنشنِ ۱.۶۱۸ → ۲۰٪ و SL به ورود (از کندلِ بعد)
  TP3 = ۳۰٪ِ آخر با کلوزِ کندلِ 4h که واگراییِ قویِ مخالف (لانگ: منفی، شورت: مثبت؛ تعریفِ angelina2.json) تأیید میشه — یا در ورود اگه قیمت زودتر برگرده
  مسیر رویِ 5m · کندلی که هم SL هم تارگت رو لمس کنه ← SL · کارمزد برایِ هر بخش
اجرا: python angelina_exit.py --results /content/angelina_results
"""
import os, sys, glob, argparse
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fr as FR, run_angelina as A, angelina2 as A2

SL_PAD = 0.0009
FR3 = (0.5, 0.2, 0.3)


def _first(m):
    return FR._first(m)


def sim_multi(F5, F4, div_ok, e_ms, side, entry, p1, p0, fee_pct):
    """خروجی: (لیستِ (سهم، قیمت، برچسب، زمانِ ms)، سودِ خالصِ نسبی به حجم)."""
    e = int(np.searchsorted(F5.t, e_ms))
    if e >= len(F5.t):
        return [], np.nan
    sl = p1 * (1 - side * SL_PAD); t1 = p0; t2 = FR.fib(p1, p0, -0.618)
    H, L, T, C = F5.H, F5.L, F5.t, F5.C
    hit = lambda a, px, fav: _first((H[a:] >= px) if (side == 1) == fav else (L[a:] <= px))
    parts = []
    if (L[e] <= sl) if side == 1 else (H[e] >= sl):
        parts = [(1.0, sl, "SL", int(F5.ct[e]))]
    else:
        i_sl, i_1 = hit(e + 1, sl, False), hit(e + 1, t1, True)
        if i_1 is None or (i_sl is not None and i_sl <= i_1):
            parts = [(1.0, sl, "SL", int(F5.ct[e + 1 + i_sl]))] if i_sl is not None else [(1.0, float(C[-1]), "پایانِ داده", int(F5.ct[-1]))]
        else:
            k1 = e + 1 + i_1
            parts.append((FR3[0], t1, "TP1", int(F5.ct[k1])))
            i_sl, i_2 = hit(k1 + 1, sl, False), hit(k1, t2, True)
            j_sl = None if i_sl is None else k1 + 1 + i_sl
            j_2 = None if i_2 is None else k1 + i_2
            if j_2 is None or (j_sl is not None and j_sl <= j_2):
                parts.append((FR3[1] + FR3[2], sl, "SL", int(F5.ct[j_sl])) if j_sl is not None else (FR3[1] + FR3[2], float(C[-1]), "پایانِ داده", int(F5.ct[-1])))
            else:
                parts.append((FR3[1], t2, "TP2", int(F5.ct[j_2])))
                t_tp2 = int(F5.ct[j_2])
                cand = np.flatnonzero(div_ok & (F4.ct >= t_tp2))                # اولین کندلِ 4h با واگراییِ تأییدشده بعد از TP2
                kd = int(np.searchsorted(T, F4.ct[cand[0]])) if len(cand) else len(T)
                i_be = hit(j_2 + 1, entry, False)
                j_be = None if i_be is None else j_2 + 1 + i_be
                if j_be is not None and j_be < kd:
                    parts.append((FR3[2], entry, "SL در ورود", int(F5.ct[j_be])))
                elif len(cand):
                    parts.append((FR3[2], float(F4.C[cand[0]]), "TP3 واگرایی", int(F4.ct[cand[0]])))
                else:
                    parts.append((FR3[2], float(C[-1]), "پایانِ داده", int(F5.ct[-1])))
    f = fee_pct / 100
    gross = sum(fr_ * side * (px - entry) / entry for fr_, px, _, _ in parts)
    fees = f + sum(fr_ * f * px / entry for fr_, px, _, _ in parts)
    return parts, gross - fees


def apply_new_exit(E, F5s, F4s, flags, L):
    E = E.copy()
    pos = L["margin"] * L["lev"]
    ent = E.index[(E["وضعیت"] == "ورود")]
    for i in ent:
        r = E.loc[i]; side = 1 if r["جهت"] == "لانگ" else -1
        F5, F4 = F5s[r["نماد"]], F4s[r["نماد"]]
        div_ok = flags[r["نماد"]]["bear_strong" if side == 1 else "bull_strong"]
        parts, net = sim_multi(F5, F4, div_ok, int(r["زمانِ ورود"]), side, float(r["ورود"]), float(r["P1"]), float(r["P0"]), L["fee_pct"])
        if not parts:
            E.at[i, "$ single"] = np.nan; continue
        E.at[i, "$ single"] = net * pos
        E.at[i, "مدت single"] = (max(p[3] for p in parts) - int(r["زمانِ ورود"])) / 3.6e6
        E.at[i, "خروج single"] = "+".join(p[2] for p in parts)
    return E


def main():
    L = A.lock(); c = A2.lock2()
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="/content/angelina_results"); ap.add_argument("--cache", default="/content/fr_cache")
    ap.add_argument("--out", default="/content/angelina_exit_results")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    fs = [f for f in glob.glob(os.path.join(a.results, "events", "*.csv.gz")) if os.path.getsize(f) > 50]
    E = pd.concat([pd.read_csv(f) for f in fs], ignore_index=True)
    import ccxt
    ex = ccxt.okx({"enableRateLimit": True})
    import time
    s0, e0 = int(E["تأییدِ موج"].min()), int(time.time() * 1000)
    F5s, F4s, flags, frames = {}, {}, {}, {"4h": {}, "1d": {}, "div": {}}
    for sym in sorted(E["نماد"].unique()):
        print(f"  {sym} ...", flush=True)
        F5s[sym] = FR.Frame(FR.fetch(ex, sym, "5m", s0 - 5 * 86_400_000, e0, a.cache), "5m")
        F4 = FR.Frame(FR.fetch(ex, sym, "4h", s0 - 240 * FR.TF_MS["4h"], e0, a.cache), "4h")
        F4s[sym] = F4; flags[sym] = A2.div_flags(F4, c)
        frames["4h"][sym] = F4; frames["div"][sym] = (F4, flags[sym])
        frames["1d"][sym] = FR.Frame(FR.fetch(ex, sym, "1d", s0 - 240 * 86_400_000, e0, a.cache), "1d")
    T = A2.tag(E, frames, c)
    New = apply_new_exit(T, F5s, F4s, flags, L)
    start, end = s0, int(max(f.ct[-1] for f in F5s.values()))
    sets = {"Angelina · خروجِ فعلی": T, "Angelina · خروجِ جدید": New,
            "Angelina2 (MA200ِ 4h) · خروجِ فعلی": A2.select(T, "4h"), "Angelina2 (MA200ِ 4h) · خروجِ جدید": A2.select(New, "4h")}
    parts = []
    for k, (nm, sub) in enumerate(sets.items()):
        d = os.path.join(a.out, f"set{k + 1}"); os.makedirs(d, exist_ok=True)
        A.report(sub, L, d, start, end)
        rep = open(os.path.join(d, "angelina_report.md"), encoding="utf-8").read()
        body = rep.split("## نتیجه", 1)[1].split("## ماهانه")[0]
        extra = ""
        if "جدید" in nm:
            x = sub[(sub["وضعیت"] == "ورود") & sub["$ single"].notna()]["خروج single"].value_counts().head(8)
            extra = "\nمسیرِ خروج (ستاپ‌ها، قبل از محدودیتِ سرمایه): " + " · ".join(f"{i}: {v}" for i, v in x.items()) + "\n"
        parts.append(f"# {nm} (پوشه‌یِ set{k + 1})\n## نتیجه{body}{extra}")
    open(os.path.join(a.out, "angelina_exit_compare.md"), "w", encoding="utf-8").write(
        "# خروجِ فعلی در مقابلِ خروجِ جدید — Angelina و Angelina2\n\nخروجِ جدید: SL ۰.۰۹٪ اونطرفِ سطحِ ۱ · ۵۰٪ در سطحِ ۰ · ۲۰٪ در ۱.۶۱۸ و SL به ورود · ۳۰٪ با واگراییِ قویِ مخالفِ 4h\n\n" + "\n\n".join(parts))
    print(open(os.path.join(a.out, "angelina_exit_compare.md"), encoding="utf-8").read())


if __name__ == "__main__":
    main()
