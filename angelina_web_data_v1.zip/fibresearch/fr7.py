# -*- coding: utf-8 -*-
"""
v7 — فیبو رویِ 1h، ورود با تأییدِ 15m، خروجِ چندتارگتی. (همون قراردادهایِ fr.py برایِ موج و سطوح)
ورود:
  direct  = سفارشِ محدود در ۰.۶۱۸ِ 1h (اولین کندلِ 15m بعد از تأییدِ موج که سطح رو لمس کنه)
  close   = بعد از لمس، اولین کندلِ 15m که کلوزش برگرده اینطرفِ ۰.۶۱۸ (لانگ: بالایِ سطح)
  ma      = بعد از لمس، کراسِ MA5 از MA20 در جهتِ معامله رویِ 15m
  rsi     = بعد از لمس، واگراییِ معمولی/مخفیِ هم‌جهت یا هم‌جهتیِ RSI رویِ 15m (پرچم‌هایِ fr2.filter_flags)
  ورودِ تأییدی با کلوزِ کندلِ تأیید، حداکثر ۱۶ کندلِ 15m بعد از لمس؛ لغو اگه قبلش SL یا سطحِ ۰ (پایانِ موج) لمس بشه
خروج (رویِ 15m):
  single = همه در TP = سطحِ ۰ +۱٪، SL ثابت
  mt_a / mt_b / mt_c = TP1 سطحِ ۰ (۵۰٪ + SL به ورود) · بعد ۲۵٪ در TP2 و ۲۵٪ در TP3:
        a: ۱.۲۷ و ۱.۶۱۸ · b: +۱٪ و ۱.۲۷ · c: ۱.۲۷ و ۲.۰   (اکستنشن k = Fib(1 − k))
  SL: سطحِ ۱ (sl1) یا ۰.۵٪ بازتر (sl05). کندلی که هم SL هم تارگت رو لمس کنه ← SL. SL به ورود از کندلِ بعد از TP1.
"""
import numpy as np
import pandas as pd
import fr as FR
import fr2 as F2

ENTRIES = ["direct", "close", "ma", "rsi"]
ENTRY_FA = {"direct": "مستقیم (1h)", "close": "15m: کلوزِ برگشتی", "ma": "15m: کراسِ MA5/MA20", "rsi": "15m: RSI"}
EXITS7 = {"single": None, "single0": "lvl0", "mt_a": (1.27, 1.618), "mt_b": ("tp1", 1.27), "mt_c": (1.27, 2.0)}
EXIT7_FA = {"single": "تک‌تارگت (سطحِ ۰ +۱٪)", "mt_a": "TP1 سطحِ ۰ · ۱.۲۷ · ۱.۶۱۸", "mt_b": "TP1 سطحِ ۰ · +۱٪ · ۱.۲۷", "mt_c": "TP1 سطحِ ۰ · ۱.۲۷ · ۲.۰"}
SLS7 = {"sl1": 0.0, "sl05": 0.005}
CONFIRM_BARS = 16


def m15_context(F15):
    c = F15.C
    m5, m20 = pd.Series(c).rolling(5).mean().to_numpy(), pd.Series(c).rolling(20).mean().to_numpy()
    xu = np.zeros(len(c), bool); xd = np.zeros(len(c), bool)
    xu[1:] = (m5[:-1] <= m20[:-1]) & (m5[1:] > m20[1:]); xd[1:] = (m5[:-1] >= m20[:-1]) & (m5[1:] < m20[1:])
    fl = F2.filter_flags(F15)
    return {"xu": xu, "xd": xd, "rsi_up": fl["bull_reg"] | fl["bull_hid"] | fl["align_up"], "rsi_dn": fl["bear_reg"] | fl["bear_hid"] | fl["align_dn"]}


def bos_flags(F, ns):
    """برایِ هر n: کلوزِ کندلِ k بالایِ آخرین سقفِ پیووتِ تأییدشده تا کندلِ k-1 (و قرینه برایِ کف)."""
    out = {}
    for n in ns:
        ph, pl = FR.pivots(F.H, F.L, n)
        N = len(F.C)
        lh = np.full(N, np.nan); ll = np.full(N, np.nan)
        for j in ph:
            if j + n + 1 < N: lh[j + n + 1] = F.H[j]
        for j in pl:
            if j + n + 1 < N: ll[j + n + 1] = F.L[j]
        lh = pd.Series(lh).ffill().to_numpy(); ll = pd.Series(ll).ffill().to_numpy()
        out[f"bosu_{n}"] = np.isfinite(lh) & (F.C > lh)
        out[f"bosd_{n}"] = np.isfinite(ll) & (F.C < ll)
    return out


def m1h_context(F1h):
    """برایِ فیلترِ v10: MA200 و پرچم‌هایِ RSIِ 1h (معتبر از بسته‌شدنِ هر کندل)."""
    fl = F2.filter_flags(F1h)
    return {"F": F1h, "ma": F1h.ma, "align_up": fl["align_up"], "align_dn": fl["align_dn"], "bull_reg": fl["bull_reg"], "bear_reg": fl["bear_reg"]}


def h1_state(c1, t_ms, price):
    """وضعیتِ آخرین کندلِ 1hِ بسته‌شده تا t_ms."""
    j = c1["F"].closed_idx(np.array([t_ms]))[0]
    if j < 0 or not np.isfinite(c1["ma"][j]):
        return {}
    return {"1h ورود بالایِ MA200": bool(price > c1["ma"][j]), "1h هم‌جهتیِ صعودی": bool(c1["align_up"][j]), "1h هم‌جهتیِ نزولی": bool(c1["align_dn"][j]),
            "1h واگراییِ منفی": bool(c1["bear_reg"][j]), "1h واگراییِ مثبت": bool(c1["bull_reg"][j])}


def _first(m):
    return FR._first(m)


def find_entry(F15, ctx, mode, side, lv, sl, p0, a, stop, gap="skip", lv786=None, zone=None):
    """از اندیسِ a تا stop رویِ 15m. خروجی: (اندیسِ کندلِ ورود، قیمتِ ورود، وضعیت).
    gap (فقط direct): skip = کندلِ کامل اونطرفِ سطح ← بدونِ ورود · market = ورود با اوپنِ همون کندل (اگه هنوز اینطرفِ SL باشه)
                      market786 = مثلِ market ولی فقط اگه اوپن هنوز اینطرفِ ۰.۷۸۶ باشه"""
    H, L, C = F15.H[a:stop], F15.L[a:stop], F15.C[a:stop]
    if mode == "ma_zone":                                                  # «رسیدن» = ورود به محدوده (لمسِ ۰.۵)
        lv = zone[0]
    touch = _first((L <= lv) if side == 1 else (H >= lv))
    brk = _first((H > p0) if side == 1 else (L < p0))
    if touch is None:
        return None, None, "لمس نشد"
    if brk is not None and brk <= touch:
        return None, None, "لغو (شکستِ سطحِ ۰)"
    if mode == "direct":
        if (H[touch] < lv) if side == 1 else (L[touch] > lv):
            o = float(F15.O[a + touch])
            beyond_sl = (o <= sl) if side == 1 else (o >= sl)
            too_deep = lv786 is not None and ((o < lv786) if side == 1 else (o > lv786))
            if gap == "skip" or beyond_sl or (gap == "market786" and too_deep):
                return None, None, "شکاف"
            return a + touch, o, "ورود (شکاف)"
        return a + touch, lv, "ورود"
    if mode.startswith("bos5_"):                                           # v13: بعد از لمس، شکستِ آخرین سقف/کفِ پیووتِ 5m (کلوز)
        key = ("bosu_" if side == 1 else "bosd_") + mode.split("_")[1]
        for j in range(touch, len(C)):
            if (L[j] <= sl) if side == 1 else (H[j] >= sl):
                return None, None, "SL قبل از تأیید"
            if (H[j] > p0) if side == 1 else (L[j] < p0):
                return None, None, "لغو (شکستِ سطحِ ۰)"
            if ctx[key][a + j]:
                return a + j, float(C[j]), "ورود"
        return None, None, "تأیید نیومد"
    if mode == "ma_zone":                                                  # v12: کراسِ MA5/MA20 وقتی کلوز بینِ ۰.۵ و ۰.۷۸۶ـه
        z1, z2 = sorted((zone[0], zone[1]))
        for j in range(touch, len(C)):
            if (L[j] <= sl) if side == 1 else (H[j] >= sl):
                return None, None, "SL قبل از تأیید"
            if (H[j] > p0) if side == 1 else (L[j] < p0):
                return None, None, "لغو (شکستِ سطحِ ۰)"
            k = a + j
            if (ctx["xu"][k] if side == 1 else ctx["xd"][k]) and z1 <= C[j] <= z2:
                return k, float(C[j]), "ورود"
        return None, None, "تأیید نیومد"
    end = min(len(C), touch + CONFIRM_BARS + 1)
    for j in range(touch, end):
        if (L[j] <= sl) if side == 1 else (H[j] >= sl):
            return None, None, "SL قبل از تأیید"
        if (H[j] > p0) if side == 1 else (L[j] < p0):
            return None, None, "لغو (شکستِ سطحِ ۰)"
        k = a + j
        ok = {"close": (C[j] > lv) if side == 1 else (C[j] < lv),
              "ma": ctx["xu"][k] if side == 1 else ctx["xd"][k],
              "rsi": ctx["rsi_up"][k] if side == 1 else ctx["rsi_dn"][k]}[mode]
        if ok:
            return k, float(C[j]), "ورود"
    return None, None, "تأیید نیومد"


def simulate_exit(F15, e, side, entry, sl, targets, fracs, max_bars, be_after_first=True):
    """targets: قیمت‌ها به ترتیب، fracs: سهمِ هر کدوم (جمع ۱). خروجی: [(سهم، قیمتِ خروج، برچسب، اندیس)]."""
    end = min(len(F15.H), e + 1 + max_bars)
    H, L = F15.H[e + 1:end], F15.L[e + 1:end]
    hit = lambda px, fav: _first((H >= px) if (side == 1) == fav else (L <= px))
    if (F15.L[e] <= sl) if side == 1 else (F15.H[e] >= sl):            # SL در کندلِ ورود
        return [(1.0, sl, "SL", e)]
    out, rem, stop, start = [], 1.0, sl, 0
    for ti, (px, fr_) in enumerate(zip(targets, fracs)):
        sub = slice(start, None)
        i_stop = _first((L[sub] <= stop) if side == 1 else (H[sub] >= stop))
        i_tp = _first((H[sub] >= px) if side == 1 else (L[sub] <= px))
        if i_stop is not None and (i_tp is None or i_stop <= i_tp):          # SL قبل یا هم‌زمان با تارگت
            out.append((rem, stop, "SL" if stop == sl else "SL در ورود", e + 1 + start + i_stop)); return out
        if i_tp is None:
            out.append((rem, float(F15.C[end - 1]), "پایانِ مهلت", end - 1)); return out
        out.append((fr_, px, f"TP{ti + 1}", e + 1 + start + i_tp)); rem -= fr_
        if ti == 0 and be_after_first and len(targets) > 1:
            stop = entry
            start = start + i_tp + 1                                          # SLِ جدید از کندلِ بعد
        else:
            start = start + i_tp                                              # تارگتِ بعدی می‌تونه در همون کندل باشه
    return out


def events7(F1h, F15, ctx15, n, cfg, sym, wave_mode="origin", entries=None, exits=None, sls=None, gap="skip", ctx1h=None, ctx_tf=None):
    entries = entries or ENTRIES; exits = exits or list(EXITS7); sls = sls or list(SLS7)
    fee, pos = cfg["fee_pct"] / 100, cfg["margin"] * cfg["lev"]
    rows = []
    for (k, side, i0, j, p1, p0) in FR.waves(F1h, n, wave_mode):
        t_conf = int(F1h.ct[k])
        a = int(np.searchsorted(F15.t, t_conf))
        if a >= len(F15.t):
            continue
        fac = max(1, FR.TF_MS[F1h.tf] // FR.TF_MS[F15.tf])
        stop = min(len(F15.t), a + cfg["wait_bars"] * fac)                    # مهلت = wait_bars کندلِ تایمِ فیبو
        lv = FR.fib(p1, p0, 0.618)
        for sn, sv in SLS7.items():
            if sn not in sls:
                continue
            sl = p1 * (1 - side * sv)
            for em in entries:
                e, entry, st = find_entry(F15, ctx15, em, side, lv, sl, p0, a, stop, gap, FR.fib(p1, p0, 0.786), (FR.fib(p1, p0, 0.5), FR.fib(p1, p0, 0.786)))
                base = {"موج": wave_mode, "نماد": sym, "پیووت": n, "جهت": "لانگ" if side == 1 else "شورت", "sl": sn, "ورود_حالت": em,
                        "تأییدِ موج": t_conf, "وضعیت": st, "P1": p1, "P0": p0}
                if e is None:
                    rows.append(base); continue
                base["شکاف"] = st == "ورود (شکاف)"; st = "ورود"; base["وضعیت"] = st
                if (side == 1 and not (sl < entry < p0)) or (side == -1 and not (p0 < entry < sl)):
                    rows.append({**base, "وضعیت": "ورود خارج از محدوده"}); continue
                R = abs(entry - sl)
                row = {**base, "زمانِ ورود": int(F15.t[e]), "ساعت": int(F15.t[e] // 3_600_000 % 24), "ورود": entry, "SL٪": R / entry * 100,
                       **(h1_state(ctx1h, int(F15.t[e]), entry) if ctx1h is not None else {}),
                       **({k.replace("1h ", "tf "): v for k, v in h1_state(ctx_tf, int(F15.t[e]), entry).items()} if ctx_tf is not None else {})}
                for xm in exits:
                    spec = EXITS7[xm]
                    if spec is None:
                        tg, fr_ = [p0 * (1 + side * 0.01)], [1.0]
                    elif spec == "lvl0":
                        tg, fr_ = [p0], [1.0]
                    else:
                        conv = lambda v: p0 * (1 + side * 0.01) if v == "tp1" else FR.fib(p1, p0, 1 - v)
                        tg, fr_ = [p0, conv(spec[0]), conv(spec[1])], [0.5, 0.25, 0.25]
                    parts = simulate_exit(F15, e, side, entry, sl, tg, fr_, cfg["max_hold_bars"] * fac)
                    gross = sum(f * side * (px - entry) / entry for f, px, _, _ in parts)
                    fees = fee + sum(f * fee * px / entry for f, px, _, _ in parts)
                    usd = (gross - fees) * pos
                    row[f"R {xm}"] = (gross - fees) * entry / R
                    row[f"$ {xm}"] = usd
                    row[f"خروج {xm}"] = "+".join(lbl for _, _, lbl, _ in parts)
                    row[f"مدت {xm}"] = (F15.ct[max(p[3] for p in parts)] - F15.t[e]) / 3.6e6
                rows.append(row)
    return rows
