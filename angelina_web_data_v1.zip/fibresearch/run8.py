# -*- coding: utf-8 -*-
"""
v8 — بهترین ترکیب رویِ ۳۰ نماد با سرمایه‌یِ مشترک.
فیبو 1h · موج origin · پیووت ۲۰ · لانگ · ورودِ مستقیم ۰.۶۱۸ (fr7) · تک‌تارگت سطحِ ۰ +۱٪ · SL ۰.۵٪ بازتر (و سطحِ ۱ برایِ مقایسه)
فیلتر: فاصله‌یِ SL ≥ ۳٪ · بدونِ ورود در ۴–۸ و ۱۶–۲۰ UTC
پرتفو: سرمایه‌یِ اولیه مشترک · هر معامله مارجین × لوریج · ورود فقط با مارجینِ آزاد · یه پوزیشن برایِ هر نماد · سود/ضرر در لحظه‌یِ خروج
اجرا: python run8.py (قابلِ ادامه؛ هر نماد جدا ذخیره میشه)
"""
import os, sys, glob, time, argparse
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fr as FR, fr7 as F7

SYMBOLS = "BTC,ETH,SOL,XRP,DOGE,ADA,AVAX,LINK,DOT,LTC,BCH,TRX,TON,NEAR,APT,ARB,OP,SUI,ATOM,FIL,ETC,UNI,AAVE,INJ,SEI,TIA,WLD,PEPE,SHIB,XLM"
CFG = {"fee_pct": 0.05, "wait_bars": 500, "max_hold_bars": 5000, "margin": 20.0, "lev": 10.0, "capital": 500.0,
       "pivot": 20, "wave": "origin", "min_sl": 3.0, "bad_hours": [4, 5, 6, 7, 16, 17, 18, 19]}


def trades_for(sym, ex, start, end, cache, out, gap="skip"):
    p = os.path.join(out, "events", f"{sym}_{gap}_v10.csv.gz")
    if os.path.exists(p):
        return pd.read_csv(p)
    try:
        D = {tf: FR.fetch(ex, sym, tf, start - 210 * FR.TF_MS["4h"], end, cache) for tf in ("15m", "1h")}
    except Exception as e:                                                    # noqa: BLE001
        print(f"  {sym}: داده نیومد ({e})", flush=True); return None
    if len(D["1h"]) < 500 or len(D["15m"]) < 2000:
        print(f"  {sym}: داده‌یِ کافی نیست", flush=True); pd.DataFrame().to_csv(p, index=False, compression="gzip"); return pd.DataFrame()
    F1, F15 = FR.Frame(D["1h"], "1h"), FR.Frame(D["15m"], "15m")
    ev = pd.DataFrame(F7.events7(F1, F15, F7.m15_context(F15), CFG["pivot"], CFG, sym, CFG["wave"], entries=["direct"], exits=["single"], sls=["sl05", "sl1"], gap=gap, ctx1h=F7.m1h_context(F1)))
    if len(ev):
        ev = ev[ev["تأییدِ موج"] >= start]
    ev.to_csv(p, index=False, compression="gzip")
    first = pd.Timestamp(int(D["1h"]["t"].iloc[0]), unit="ms").date()
    print(f"💾 {sym}: داده از {first} · {int((ev.get('وضعیت', pd.Series(dtype=str)) == 'ورود').sum())} ورود (قبل از فیلتر)", flush=True)
    return ev


def select(E, sl, filt="none"):
    """none = قوانینِ قبلی (فقط لانگ) · ma_rsi = لانگ و شورت با MA200، هم‌جهتی و منعِ واگراییِ مخالف رویِ 1h."""
    d = E[(E["وضعیت"] == "ورود") & (E["sl"] == sl)].copy()
    if filt == "none":
        d = d[d["جهت"] == "لانگ"]
    else:
        g = lambda c: d.get(c, pd.Series(False, index=d.index)).fillna(False).astype(bool)
        lng = (d["جهت"] == "لانگ") & g("1h ورود بالایِ MA200") & g("1h هم‌جهتیِ صعودی") & ~g("1h واگراییِ منفی")
        sht = (d["جهت"] == "شورت") & ~g("1h ورود بالایِ MA200") & d.get("1h ورود بالایِ MA200", pd.Series(np.nan, index=d.index)).notna() & g("1h هم‌جهتیِ نزولی") & ~g("1h واگراییِ مثبت")
        d = d[lng | sht]
    d = d[(d["SL٪"] >= CFG["min_sl"]) & ~d["ساعت"].isin(CFG["bad_hours"])]
    d = d[d["$ single"].notna()]
    d["خروج_ms"] = d["زمانِ ورود"] + (d["مدت single"] * 3.6e6).astype("int64")
    return d.sort_values("زمانِ ورود").reset_index(drop=True)


def portfolio(d, capital, margin):
    """رویدادهایِ ورود و خروج به ترتیبِ زمان؛ ورود فقط با مارجینِ آزاد و یه پوزیشن برایِ هر نماد."""
    ev = [(t, 1, i) for i, t in enumerate(d["خروج_ms"])] + [(t, 2, i) for i, t in enumerate(d["زمانِ ورود"])]
    ev.sort()                                                                # خروج‌ها قبل از ورودهایِ هم‌زمان
    eq, used, open_sym, taken, curve, maxpos = capital, 0.0, set(), np.zeros(len(d), bool), [], 0
    for t, kind, i in ev:
        sym = d.at[i, "نماد"]
        if kind == 1 and taken[i]:
            eq += d.at[i, "$ single"]; used -= margin; open_sym.discard(sym); curve.append((t, eq))
        elif kind == 2:
            if sym in open_sym or eq - used < margin:
                continue
            taken[i] = True; used += margin; open_sym.add(sym); maxpos = max(maxpos, len(open_sym))
    C = pd.DataFrame(curve, columns=["t", "سرمایه"])
    return taken, C, maxpos


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbols", default=SYMBOLS); ap.add_argument("--years", type=float, default=6)
    ap.add_argument("--days", type=float, default=0); ap.add_argument("--gaps", default="skip,market,market786"); ap.add_argument("--filters", default="none,ma_rsi")
    ap.add_argument("--capital", type=float, default=500); ap.add_argument("--margin", type=float, default=20); ap.add_argument("--lev", type=float, default=10)
    ap.add_argument("--cache", default="/content/fr_cache"); ap.add_argument("--out", default="/content/fr8_results"); ap.add_argument("--end", default=None)
    a = ap.parse_args()
    CFG.update(capital=a.capital, margin=a.margin, lev=a.lev)
    os.makedirs(os.path.join(a.out, "events"), exist_ok=True)
    end = int(pd.Timestamp(a.end, tz="UTC").value // 10**6) if a.end else int(time.time() * 1000) // 3_600_000 * 3_600_000
    start = end - (int(a.days * 86_400_000) if a.days else int(a.years * 365.25 * 86_400_000))
    import ccxt
    ex = ccxt.okx({"enableRateLimit": True})
    txt = []
    for gp in [g for g in a.gaps.split(",") if g]:
        allE = []
        for sym in [s.strip().upper() for s in a.symbols.split(",") if s.strip()]:
            ev = trades_for(sym, ex, start, end, a.cache, a.out, gp)
            if ev is not None and len(ev):
                allE.append(ev)
        E = pd.concat(allE, ignore_index=True)
        for fl in [f for f in a.filters.split(",") if f]:
            txt.append(report(E, a.out, start, end, gp, fl))
    full = []
    for t in txt:
        full += [t, ""]
    open(os.path.join(a.out, "v8_report.md"), "w", encoding="utf-8").write("\n".join(full))


GAPF = {"skip": "شکاف ← بدونِ ورود", "market": "شکاف ← ورود با قیمتِ بازار", "market786": "شکاف ← ورود فقط اگه بالایِ ۰.۷۸۶"}
FILTF = {"none": "فیلترِ قبلی (فقط لانگ)", "ma_rsi": "فیلترِ جدید: MA200 + هم‌جهتی + منعِ واگراییِ مخالف (1h) · لانگ و شورت"}


def report(E, out, start, end, gap="skip", filt="none"):
    cap, mg = CFG["capital"], CFG["margin"]
    txt = [f"# {GAPF.get(gap, gap)} · {FILTF.get(filt, filt)}", f"## v8 — بهترین ترکیب رویِ {E['نماد'].nunique()} نماد · سرمایه ${cap:g} · مارجین ${mg:g} × {CFG['lev']:g}", "",
           f"فیبو 1h · موج {CFG['wave']} · پیووت {CFG['pivot']} · لانگ · ورودِ مستقیم ۰.۶۱۸ · TP سطحِ ۰ +۱٪ · SL≥{CFG['min_sl']:g}٪ · بدونِ ورود در ۴–۸ و ۱۶–۲۰ UTC", ""]
    for sl, nm in (("sl05", "SL ۰.۵٪ بازتر"), ("sl1", "SL سطحِ ۱")):
        d = select(E, sl, filt)
        if not len(d):
            continue
        taken, C, maxpos = portfolio(d, cap, mg)
        n_gap = int(d.get("شکاف", pd.Series(False, index=d.index)).fillna(False).astype(bool)[taken].sum())
        d["گرفته شد"] = taken
        t = d[taken].copy()
        t["ماه"] = pd.to_datetime(t["خروج_ms"], unit="ms").dt.to_period("M")
        M = t.groupby("ماه")["$ single"].sum()
        months = pd.period_range(pd.Timestamp(start, unit="ms").to_period("M"), pd.Timestamp(end, unit="ms").to_period("M"), freq="M")
        M = M.reindex(months, fill_value=0.0)
        eqv = C["سرمایه"].to_numpy() if len(C) else np.array([cap])
        dd = float((eqv - np.maximum.accumulate(np.r_[cap, eqv])[1:]).min()) if len(C) else 0.0
        t["بخش"] = FR.split_of(t["تأییدِ موج"], start, end)
        per = t.groupby("نماد").agg(معاملات=("$ single", "size"), برد=("$ single", lambda x: int((x > 0).sum())), خالص=("$ single", "sum")).round(1).sort_values("خالص", ascending=False)
        per["برد٪"] = (100 * per["برد"] / per["معاملات"]).round(1)
        yr = t.groupby(pd.to_datetime(t["خروج_ms"], unit="ms").dt.year)["$ single"].agg(["size", "sum"]).round(0)
        sp = t.groupby("بخش")["R single"].agg(["size", "mean"]).round(3)
        u = t["$ single"]
        side_txt = " · ".join(f"{k}: {len(v)} معامله، {v.sum():+.0f}$" for k, v in t.groupby("جهت")["$ single"])
        txt += [f"## {nm}",
                f"- ستاپ‌هایِ بعد از فیلتر: {len(d)} · **گرفته‌شده با سرمایه‌یِ مشترک: {len(t)}** (از این‌ها ورودِ شکاف: {n_gap}) · حداکثر پوزیشنِ هم‌زمان: {maxpos}",
                f"- برد {int((u > 0).sum())} · باخت {int((u <= 0).sum())} · برد٪ {100 * (u > 0).mean():.1f} · میانگینِ هر معامله ${u.mean():+.2f} · میانگینِ برد ${u[u > 0].mean():+.2f} · باخت ${u[u <= 0].mean():+.2f}",
                f"- **سرمایه: ${cap:g} → ${cap + u.sum():,.0f}** (خالص ${u.sum():+,.0f}) · بیشترین افت ${dd:,.0f}",
                f"- **سودِ ماهانه: میانگین ${M.mean():+.1f} · میانه ${M.median():+.1f}** · ماهِ مثبت/منفی/صفر {int((M > 0).sum())}/{int((M < 0).sum())}/{int((M == 0).sum())} · بهترین ${M.max():+.0f} ({M.idxmax()}) · بدترین ${M.min():+.0f} ({M.idxmin()})",
                f"- معامله در ماه {len(t) / len(M):.1f} · {side_txt}", "", "سالانه (تعداد، $):", yr.to_string(), "",
                "امید در هر بخش (R):", sp.to_string(), "", "به تفکیکِ نماد:", per.to_string(), "",
                "ماهانه ($):", " ".join(f"{str(k)[2:]}:{v:+.0f}" for k, v in M.items()), ""]
        t[["نماد", "جهت", "زمانِ ورود", "ورود", "SL٪", "خروج single", "$ single"]].assign(**{"زمانِ ورود": pd.to_datetime(t["زمانِ ورود"], unit="ms")}).to_csv(
            os.path.join(out, f"v8_trades_{gap}_{filt}_{sl}.csv"), index=False, encoding="utf-8-sig")
        C.assign(t=pd.to_datetime(C["t"], unit="ms")).to_csv(os.path.join(out, f"v8_equity_{gap}_{filt}_{sl}.csv"), index=False)
    print("\n".join(txt[:40]))
    return "\n".join(txt)


if __name__ == "__main__":
    main()
