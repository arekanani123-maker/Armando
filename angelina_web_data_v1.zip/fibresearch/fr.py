# -*- coding: utf-8 -*-
"""
تحقیقِ شش‌ساله‌یِ فیبوناچی، MA200 و رفتارِ قیمت بعد از تارگت و استاپ — موتورِ اصلی (مستقل از همه‌یِ پروژه‌هایِ قبلی).

قراردادها (ثابت در کلِ تحقیق):
  موجِ صعودی: سطحِ ۱ = کفِ موج، سطحِ ۰ = سقفِ موج ← لانگ · موجِ نزولی: سطحِ ۱ = سقف، سطحِ ۰ = کف ← شورت
  Fib(r) = P0 + r × (P1 − P0) · ورود = سطحِ r · TP = سطحِ ۰ · SL = سطحِ ۱ · R = |ورود − SL|
  پیووت: سقف در j اگه H[j] از n کندلِ چپ اکیداً و از n کندلِ راست ≥ بالاتر باشه؛ تأیید در بسته‌شدنِ کندلِ j+n
  موج: با تأییدِ سقفِ پیووتِ j، کفِ موج = پایین‌ترین Low بینِ سقفِ پیووتِ قبلی و j (قرینه برایِ نزولی)
  رویداد: هر موج × هر سطح = یک رویدادِ مستقل؛ اولین لمسِ سطح از کندلِ بعد از تأیید؛ لغو اگه قبلش سطحِ ۰ شکسته بشه؛ انقضا بعد از wait_bars
  اگه در لحظه‌یِ فعال‌شدن کلِ کندل اونطرفِ سطح باشه (شکاف) ← «فعال‌نشده» جدا ثبت میشه
  کندلِ ورود: SL در همون کندل = SL (قیمت از سطح گذشته)؛ TP یا آستانه‌ها در کندلِ ورود و هر کندلی که هم TP/آستانه هم SL رو لمس کنه ←
  بررسی با کندل‌هایِ 5m؛ اگه باز مبهم بود (یا خودِ تایم 5m باشه) ← «مبهم»
  MA200 = SMA200 رویِ کلوز؛ وضعیت از آخرین کندلِ بسته‌شده تا لحظه‌یِ بازشدنِ کندلِ ورود؛ بالا/زیر/برابر؛ شیب = MA200 نسبت به ۳۰ کندلِ قبل
"""
import os
import time
import numpy as np
import pandas as pd

TF_MS = {"5m": 300_000, "15m": 900_000, "1h": 3_600_000, "4h": 14_400_000, "1d": 86_400_000}
LEVELS = [0.382, 0.5, 0.618, 0.786]
THRESH_R = [0.5, 1.0, 2.0]
WINDOWS_H = {"۱۵ دقیقه": 0.25, "۱ ساعت": 1, "۴ ساعت": 4, "۲۴ ساعت": 24, "۷۲ ساعت": 72}


# ================================================================ داده
def fetch(ex, sym, tf, since_ms, until_ms, cache, log=print):
    os.makedirs(cache, exist_ok=True)
    path = os.path.join(cache, f"{sym}_{tf}.csv.gz")
    cols = ["t", "open", "high", "low", "close", "volume"]
    old = pd.read_csv(path) if os.path.exists(path) else pd.DataFrame(columns=cols)
    step = TF_MS[tf]
    cur = max(int(old["t"].max()) + step, since_ms) if len(old) else since_ms
    if len(old) and int(old["t"].min()) > since_ms + step:                       # کش از جایِ دیرتری شروع شده ← از اول
        old, cur = pd.DataFrame(columns=cols), since_ms
    rows, tries, last_save = [], 0, time.time()
    while cur < until_ms:
        try:
            raw = ex.fetch_ohlcv(f"{sym}/USDT:USDT", tf, since=cur, limit=300); tries = 0
        except Exception as e:                                                   # noqa: BLE001
            tries += 1
            if tries > 6:
                log(f"    {sym} {tf}: خطا ({e})"); break
            time.sleep(2 * tries); continue
        if not raw:
            cur += step * 300; continue
        rows += raw; nxt = int(raw[-1][0]) + step
        cur = nxt if nxt > cur else cur + step * 300
        if time.time() - last_save > 60:
            old = pd.concat([old, pd.DataFrame(rows, columns=cols)]).drop_duplicates("t").sort_values("t"); rows = []
            old.to_csv(path, index=False, compression="gzip"); last_save = time.time()
            log(f"    {sym} {tf}: تا {pd.Timestamp(cur, unit='ms'):%Y-%m-%d}")
    if rows:
        old = pd.concat([old, pd.DataFrame(rows, columns=cols)]).drop_duplicates("t").sort_values("t")
    old = old[old["t"] + step <= min(until_ms, int(time.time() * 1000))].reset_index(drop=True)
    old.to_csv(path, index=False, compression="gzip")
    return old.astype({"t": np.int64})


def quality(d, tf):
    t = d["t"].to_numpy(np.int64); step = TF_MS[tf]
    gaps = np.diff(np.unique(t)) // step - 1 if len(t) > 1 else np.array([0])
    bad = ((d["high"] < d[["open", "close"]].max(axis=1)) | (d["low"] > d[["open", "close"]].min(axis=1))).sum()
    return {"کندل": len(d), "از": pd.Timestamp(int(t[0]), unit="ms").strftime("%Y-%m-%d") if len(t) else "-",
            "تا": pd.Timestamp(int(t[-1]), unit="ms").strftime("%Y-%m-%d") if len(t) else "-", "تکراری": int(len(t) - len(np.unique(t))),
            "گمشده": int(gaps.clip(min=0).sum()), "بزرگ‌ترین شکاف (کندل)": int(gaps.max()) if len(gaps) else 0, "OHLC نامعتبر": int(bad)}


class Frame:
    """آرایه‌هایِ یه تایم‌فریم + SMA200 و شیب (فقط برایِ کندل‌هایِ کامل)."""

    def __init__(self, d, tf, slope_n=30):
        self.tf = tf
        self.t = d["t"].to_numpy(np.int64); self.ct = self.t + TF_MS[tf]
        self.O, self.H, self.L, self.C = (d[c].to_numpy(float) for c in ("open", "high", "low", "close"))
        self.ma = pd.Series(self.C).rolling(200, min_periods=200).mean().to_numpy()
        self.slope = (self.ma / pd.Series(self.ma).shift(slope_n).to_numpy() - 1) * 100

    def closed_idx(self, t_ms):
        """اندیسِ آخرین کندلی که تا t_ms بسته شده (ct ≤ t_ms)."""
        return np.searchsorted(self.ct, np.asarray(t_ms, np.int64), side="right") - 1

    def state(self, t_ms):
        j = self.closed_idx(t_ms)
        ok = (j >= 0)
        c = np.where(ok, self.C[np.clip(j, 0, None)], np.nan); m = np.where(ok, self.ma[np.clip(j, 0, None)], np.nan)
        s = np.where(ok, self.slope[np.clip(j, 0, None)], np.nan)
        st = np.where(~np.isfinite(m), np.nan, np.where(c > m, 1, np.where(c < m, -1, 0)))
        return st, s


# ================================================================ پیووت و موج
def pivots(H, L, n):
    ph, pl = [], []
    for j in range(n, len(H) - n):
        if H[j] > H[j - n:j].max() and H[j] >= H[j + 1:j + n + 1].max():
            ph.append(j)
        if L[j] < L[j - n:j].min() and L[j] <= L[j + 1:j + n + 1].min():
            pl.append(j)
    return ph, pl


def waves(F, n, mode="between", max_back=5000):
    """هر موج: (کندلِ تأیید، جهت +۱ صعودی/‎-۱ نزولی، اندیسِ شروع، اندیسِ پایان، P1، P0).
    شروعِ موج (برایِ سقفِ j؛ شورت قرینه):
      between   = پایین‌ترین قیمت بینِ سقفِ پیووتِ قبلی و j
      lastpivot = آخرین کفِ پیووت قبل از j (تأییدشده تا لحظه‌یِ تأییدِ j)
      origin    = پایین‌ترین قیمت از آخرین کندلی که سقفش بالاتر از H[j] بوده تا j (شروعِ کلِ حرکت؛ حداکثر max_back کندل)"""
    H, L = F.H, F.L
    ph, pl = pivots(H, L, n)
    out = []
    for piv, kind in ((ph, 1), (pl, -1)):
        prev = None; prev_j = None
        other = pl if kind == 1 else ph
        for j in piv:
            a = prev + 1 if prev is not None else max(0, j - 10 * n)
            prev = j
            if mode == "lastpivot":
                c = [q for q in other if q < j and q + n <= j + n]
                if not c:
                    continue
                a = c[-1]; j_ = j
                if kind == 1:
                    i0 = a; p1, p0 = L[i0], H[j]
                else:
                    i0 = a; p1, p0 = H[i0], L[j]
                if (kind == 1 and p0 <= p1) or (kind == -1 and p0 >= p1):
                    continue
                out.append((j + n, kind, i0, j, float(p1), float(p0)))
                continue
            if mode == "bos":                                             # B: سقفِ جدید باید با کلوز از سقفِ پیووتِ قبلی رد شده باشه
                if prev_j is None:
                    prev_j = j; continue
                lvlp = H[prev_j] if kind == 1 else L[prev_j]
                Cc = F.C[prev_j + 1:j + 1]
                broke = (Cc > lvlp).any() if kind == 1 else (Cc < lvlp).any()
                a_b = prev_j + 1
                prev_j = j
                if not broke:
                    continue
                a = a_b
            if mode == "origin":
                lo = max(0, j - max_back)
                seg = H[lo:j] > H[j] if kind == 1 else L[lo:j] < L[j]
                idx = np.flatnonzero(seg)
                a = lo + int(idx[-1]) + 1 if len(idx) else lo
            if j - a < 1:
                continue
            if kind == 1:
                i0 = a + int(np.argmin(L[a:j])); p1, p0 = L[i0], H[j]
                if p0 <= p1:
                    continue
            else:
                i0 = a + int(np.argmax(H[a:j])); p1, p0 = H[i0], L[j]
                if p0 >= p1:
                    continue
            out.append((j + n, kind, i0, j, float(p1), float(p0)))
    out.sort(key=lambda w: w[0])
    return out


def fib(p1, p0, r):
    return p0 + r * (p1 - p0)


# ================================================================ شبیه‌سازیِ رویداد
def _first(mask):
    i = int(np.argmax(mask)) if len(mask) else 0
    return i if len(mask) and mask[i] else None


def refine(fine, t0, t1, side, level, need_entry, sl, targets):
    """بررسیِ یه کندلِ درشت با کندل‌هایِ 5m در [t0, t1). خروجی: {'sl': ترتیب/None, نامِ هدف: ترتیب/None, 'amb': {...}} — ترتیب = شماره‌یِ کندلِ 5m."""
    if fine is None:
        return None
    a, b = np.searchsorted(fine.t, t0), np.searchsorted(fine.t, t1)
    if b <= a:
        return None
    H, L = fine.H[a:b], fine.L[a:b]
    k0 = 0
    if need_entry:
        touch = _first((L <= level) & (H >= level))
        if touch is None:
            return None
        k0 = touch
    res, amb = {"sl": None}, set()
    for nm in targets:
        res[nm] = None
    for k in range(k0, len(H)):
        slh = (L[k] <= sl) if side == 1 else (H[k] >= sl)
        for nm, px in targets.items():
            if res[nm] is None and ((H[k] >= px) if side == 1 else (L[k] <= px)):
                if slh or (need_entry and k == k0):
                    amb.add(nm)
                res[nm] = k
        if slh and res["sl"] is None:
            res["sl"] = k
            break
    res["amb"] = amb
    return res


def simulate(F, fine, e, side, entry, tp, sl, max_bars):
    """از کندلِ ورود e: اولین رسیدن به TP، آستانه‌هایِ R و SL. خروجی دیکشنری با زمان‌ها و برچسبِ مبهم."""
    R = abs(entry - sl)
    targets = {"TP": tp, **{f"{k}R": entry + side * k * R for k in THRESH_R}}
    end = min(len(F.H), e + max_bars)
    H, L = F.H[e:end], F.L[e:end]
    slm = (L <= sl) if side == 1 else (H >= sl)
    i_sl = _first(slm)
    out = {"R": R, "sl_bar": None, "amb": set()}
    for nm, px in targets.items():
        hit = (H >= px) if side == 1 else (L <= px)
        i = _first(hit)
        out[nm] = None
        if i is None or (i_sl is not None and i > i_sl):
            continue
        if i == 0 or (i_sl is not None and i == i_sl):                       # کندلِ ورود یا هم‌زمان با SL ← 5m
            rf = refine(fine, F.t[e + i], F.t[e + i] + TF_MS[F.tf], side, entry, i == 0, sl, {nm: px}) if fine is not None and F.tf != "5m" else None
            if rf is None or nm in rf["amb"] or rf[nm] is None:
                if rf is not None and rf[nm] is None:
                    continue                                                  # در 5m به هدف نرسید (قبل از SL یا اصلاً)
                out["amb"].add(nm); continue
            if rf["sl"] is not None and rf["sl"] < rf[nm]:
                continue
            if i_sl is not None and i == i_sl:
                out.setdefault("before_sl", set()).add(nm)                     # در همون کندل، طبقِ 5m قبل از SL
        out[nm] = e + i
    out["sl_bar"] = e + i_sl if i_sl is not None else None
    # MFE / MAE تا خروج (یا تا max_bars)
    x = (out["TP"] if out["TP"] is not None else end - 1)
    if out["sl_bar"] is not None and (out["TP"] is None or out["sl_bar"] < out["TP"] or (out["sl_bar"] == out["TP"] and "TP" not in out.get("before_sl", ()))):
        x = out["sl_bar"]
    seg_h, seg_l = F.H[e:x + 1], F.L[e:x + 1]
    out["mfe_R"] = ((seg_h.max() - entry) if side == 1 else (entry - seg_l.min())) / R
    out["mae_R"] = ((entry - seg_l.min()) if side == 1 else (seg_h.max() - entry)) / R
    return out


def after(fine, t0_ms, move, ref_px, R, tp0=None, trade_side=None):
    """رفتار بعد از رویداد از t0_ms رویِ 5m. move = جهتِ حرکتی که رویداد رو ساخت (+۱ بالا، ‎-۱ پایین):
    بعد از TP = جهتِ معامله · بعد از SL = خلافِ جهتِ معامله. «ادامه» = همون جهت، «برگشت» = جهتِ مخالف. tp0 + trade_side: برگشت به TPِ اولیه بعد از SL."""
    side = move
    out = {}
    for nm, h in WINDOWS_H.items():
        a, b = np.searchsorted(fine.t, t0_ms), np.searchsorted(fine.t, t0_ms + int(h * 3_600_000))
        if b <= a or fine.t[b - 1] + TF_MS["5m"] < t0_ms + int(h * 3_600_000) - TF_MS["5m"]:
            out[f"{nm}: ناقص"] = True
        if b <= a:
            continue
        hh, ll = fine.H[a:b].max(), fine.L[a:b].min()
        up, dn = (hh - ref_px) / ref_px * 100, (ref_px - ll) / ref_px * 100
        out[f"{nm}: ادامه٪"] = up if side == 1 else dn
        out[f"{nm}: برگشت٪"] = dn if side == 1 else up
        out[f"{nm}: ادامه R"] = ((hh - ref_px) if side == 1 else (ref_px - ll)) / R
        out[f"{nm}: برگشت R"] = ((ref_px - ll) if side == 1 else (hh - ref_px)) / R
    a, b = np.searchsorted(fine.t, t0_ms), np.searchsorted(fine.t, t0_ms + 72 * 3_600_000)
    if b > a:
        H, L, T = fine.H[a:b], fine.L[a:b], fine.t[a:b]
        k = int(np.argmax(H)) if side == 1 else int(np.argmin(L))
        ext = H[k] if side == 1 else L[k]
        out["زمان تا سقف/کفِ بعدی (ساعت، ۷۲س)"] = (T[k] - t0_ms) / 3.6e6
        rest = L[k:] if side == 1 else H[k:]
        out["اصلاح بعد از سقف/کفِ جدید٪"] = ((ext - rest.min()) / ext * 100) if side == 1 else ((rest.max() - ext) / ext * 100)
        if tp0 is not None:                                                    # بعد از SL: برگشت به TPِ اولیه؟
            hit = (H >= tp0) if trade_side == 1 else (L <= tp0)
            i = _first(hit)
            out["رسیدن به TPِ اولیه در ۷۲ ساعت"] = i is not None
            out["زمان تا TPِ اولیه (ساعت)"] = (T[i] - t0_ms) / 3.6e6 if i is not None else np.nan
    return out


def events(F, fine, ctx, n, cfg, sym):
    """همه‌یِ رویدادهایِ موج × سطح برایِ یه نماد، تایم و پیووت."""
    rows = []
    wait, max_bars, fee = cfg["wait_bars"], cfg["max_hold_bars"], cfg["fee_pct"]
    H, L = F.H, F.L
    for (k, side, i0, j, p1, p0) in waves(F, n):
        if k + 1 >= len(H):
            continue
        stop = min(len(H), k + 1 + wait)
        brk = _first((H[k + 1:stop] > p0) if side == 1 else (L[k + 1:stop] < p0))
        for r in LEVELS:
            lv = fib(p1, p0, r)
            base = {"نماد": sym, "تایم": F.tf, "پیووت": n, "جهت": "لانگ" if side == 1 else "شورت", "سطح": r, "P1": p1, "P0": p0,
                    "قیمتِ سطح": lv, "شروعِ موج": int(F.t[i0]), "پایانِ موج": int(F.t[j]), "تأییدِ موج": int(F.ct[k])}
            gap = (H[k + 1] < lv) if side == 1 else (L[k + 1] > lv)               # کلِ کندل اونطرفِ سطح
            if gap:
                rows.append({**base, "وضعیت": "فعال‌نشده (شکاف)"}); continue
            touch = _first(((L[k + 1:stop] <= lv) & (H[k + 1:stop] >= lv)))
            if touch is None or (brk is not None and brk <= touch):                # شکست و لمس در یه کندل ← ترتیب نامعلوم ← لغو
                rows.append({**base, "وضعیت": "لغو (شکستِ سطحِ ۰)" if brk is not None else "منقضی"}); continue
            e = k + 1 + touch
            sim = simulate(F, fine, e, side, lv, p0, p1, max_bars)
            R = sim["R"]
            tp_b, sl_b = sim["TP"], sim["sl_bar"]
            if "TP" in sim["amb"]:
                res, xb = "مبهم", None
            elif tp_b is not None and (sl_b is None or tp_b < sl_b or (tp_b == sl_b and "TP" in sim.get("before_sl", ()))):
                res, xb = "TP", tp_b
            elif sl_b is not None:
                res, xb = "SL", sl_b
            else:
                res, xb = "باز", None
            fee_R = 2 * fee / 100 * lv / R
            pnl_R = {"TP": abs(p0 - lv) / R - fee_R, "SL": -1 - fee_R}.get(res, np.nan)
            st = {tf: ctx[tf].state(np.array([F.t[e]])) for tf in ctx}
            row = {**base, "وضعیت": "معامله", "زمانِ ورود": int(F.t[e]), "نتیجه": res, "R٪": R / lv * 100, "سود R (خالص)": pnl_R,
                   "MFE R": sim["mfe_R"], "MAE R": sim["mae_R"], "مدت (ساعت)": (F.ct[xb] - F.t[e]) / 3.6e6 if xb is not None else np.nan}
            for kR in THRESH_R:
                nm = f"{kR}R"
                row[f"برگشتِ موفق {nm}"] = np.nan if nm in sim["amb"] else float(sim[nm] is not None)
            for tf, (s_, sl_) in st.items():
                row[f"MA200 {tf}"] = s_[0]; row[f"شیبِ MA200 {tf}٪"] = sl_[0]
            if res in ("TP", "SL") and fine is not None:
                t0 = int(F.ct[xb])                                             # مبدأ: بسته‌شدنِ کندلِ خروج
                if res == "TP":
                    row.update({f"بعد از TP · {k_}": v for k_, v in after(fine, t0, side, p0, R).items()})
                else:
                    row.update({f"بعد از SL · {k_}": v for k_, v in after(fine, t0, -side, p1, R, tp0=p0, trade_side=side).items()})
            rows.append(row)
    return rows


def split_of(t_ms, start, end, fr=(0.6, 0.2)):
    a = start + (end - start) * fr[0]; b = start + (end - start) * (fr[0] + fr[1])
    t = np.asarray(t_ms, float)
    return np.where(t < a, "آموزش", np.where(t < b, "اعتبارسنجی", "آزمونِ نهایی"))
