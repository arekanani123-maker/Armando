# -*- coding: utf-8 -*-
"""
Angelina2 — همون Angelina (قفل‌شده) + قانونِ سمتِ MA200 (angelina2.json، قفل‌شده):
  سمتِ درست (لانگ بالایِ MA200، شورت زیرش) ← ورود مثلِ Angelina
  سمتِ غلط ← ورود فقط با واگراییِ 4h: معمولیِ قوی (اختلافِ RSI ≥ ۵ و پیووتِ اولِ RSI < ۳۰ برایِ لانگ / > ۷۰ برایِ شورت) یا مخفی
  MA200 رویِ 4h و روزانه (دو نسخه) · مقایسه با Angelina رویِ همون رویدادها
اجرا: python angelina2.py --results /content/angelina_results
"""
import os, sys, json, hashlib, argparse
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fr as FR, fr2 as F2, run_angelina as A


def lock2():
    c = json.load(open(os.path.join(HERE, "angelina2.json"), encoding="utf-8"))
    if hashlib.sha256(json.dumps(c, sort_keys=True).encode()).hexdigest() != open(os.path.join(HERE, "angelina2.sha256")).read().strip():
        raise SystemExit("❌ angelina2.json تغییر کرده — منطقِ قفل‌شده نیست.")
    return c


def div_flags(F, c):
    """پرچم‌هایِ واگراییِ 4h (معتبر از بسته‌شدنِ کندل): قویِ معمولی و مخفی، صعودی و نزولی."""
    H, L, C = F.H, F.L, F.C
    N = len(C); r = F2.rsi(C, c["rsi_len"]); n = c["pivot_lr"]
    out = {k: np.zeros(N, bool) for k in ("bull_strong", "bull_hid", "bear_strong", "bear_hid")}
    ph, pl = FR.pivots(H, L, n)
    for piv, Y, kind in ((pl, L, "bull"), (ph, H, "bear")):
        for a in range(1, len(piv)):
            p1, p2 = piv[a - 1], piv[a]
            if not (c["pivot_gap"][0] <= p2 - p1 <= c["pivot_gap"][1]) or not (np.isfinite(r[p1]) and np.isfinite(r[p2])) or p2 + n >= N:
                continue
            key = None
            if kind == "bull":
                if Y[p2] < Y[p1] and r[p2] - r[p1] >= c["strong_rsi_diff"] and r[p1] < c["strong_rsi_long"]:
                    key = "bull_strong"
                elif Y[p2] > Y[p1] and r[p2] < r[p1]:
                    key = "bull_hid"
            else:
                if Y[p2] > Y[p1] and r[p1] - r[p2] >= c["strong_rsi_diff"] and r[p1] > c["strong_rsi_short"]:
                    key = "bear_strong"
                elif Y[p2] < Y[p1] and r[p2] > r[p1]:
                    key = "bear_hid"
            if key:
                out[key][p2 + n:min(N, p2 + n + c["div_valid_bars"])] = True
    return out


def tag(E, frames, c):
    E = E.copy()
    ent = (E["وضعیت"] == "ورود").to_numpy()
    side = np.where(E["جهت"] == "لانگ", 1, -1)
    for tf in c["side_ma200_tf"]:
        right = np.full(len(E), np.nan)
        for sym, F in frames[tf].items():
            m = ent & (E["نماد"] == sym).to_numpy()
            if not m.any():
                continue
            j = F.closed_idx(E.loc[m, "زمانِ ورود"].astype("int64").to_numpy())
            jj = np.clip(j, 0, None)
            ok = (j >= 0) & np.isfinite(F.ma[jj])
            right[m] = np.where(ok, (np.sign(F.C[jj] - F.ma[jj]) * side[m] > 0).astype(float), np.nan)
        E[f"سمتِ درست {tf}"] = right
    dv = np.zeros(len(E), bool)
    for sym, (F, fl) in frames["div"].items():
        m = ent & (E["نماد"] == sym).to_numpy()
        if not m.any():
            continue
        j = F.closed_idx(E.loc[m, "زمانِ ورود"].astype("int64").to_numpy())
        jj = np.clip(j, 0, None); ok = j >= 0
        lng = (fl["bull_strong"] | fl["bull_hid"])[jj]; sht = (fl["bear_strong"] | fl["bear_hid"])[jj]
        dv[m] = ok & np.where(side[m] == 1, lng, sht)
    E["واگراییِ 4h"] = dv
    return E


def select(E, tf):
    r = E[f"سمتِ درست {tf}"]
    keep = (E["وضعیت"] != "ورود") | (r == 1) | ((r == 0) & E["واگراییِ 4h"])
    return E[keep]


def main():
    c = lock2(); L = A.lock()
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="/content/angelina_results"); ap.add_argument("--cache", default="/content/fr_cache")
    ap.add_argument("--out", default="/content/angelina2_results")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    import glob
    fs = [f for f in glob.glob(os.path.join(a.results, "events", "*.csv.gz")) if os.path.getsize(f) > 50]
    E = pd.concat([pd.read_csv(f) for f in fs], ignore_index=True)
    import ccxt
    ex = ccxt.okx({"enableRateLimit": True})
    frames = {"4h": {}, "1d": {}, "div": {}}
    s0, e0 = int(E["تأییدِ موج"].min()), int(E["تأییدِ موج"].max()) + 30 * 86_400_000
    for sym in sorted(E["نماد"].unique()):
        print(f"  {sym} ...", flush=True)
        F4 = FR.Frame(FR.fetch(ex, sym, "4h", s0 - 240 * FR.TF_MS["4h"], e0, a.cache), "4h")
        frames["4h"][sym] = F4; frames["div"][sym] = (F4, div_flags(F4, c))
        frames["1d"][sym] = FR.Frame(FR.fetch(ex, sym, "1d", s0 - 240 * 86_400_000, e0, a.cache), "1d")
    T = tag(E, frames, c)
    start = int(E["تأییدِ موج"].min()); end = e0
    parts = []
    for nm, sub in [("angelina (پایه)", T)] + [(f"angelina2 · MA200ِ {tf}", select(T, tf)) for tf in c["side_ma200_tf"]]:
        d = os.path.join(a.out, nm.split(" ")[0] + ("_" + nm.split("ِ ")[-1] if "MA200" in nm else ""))
        os.makedirs(d, exist_ok=True)
        A.report(sub, L, d, start, end)
        rep = open(os.path.join(d, "angelina_report.md"), encoding="utf-8").read()
        ent = sub[sub["وضعیت"] == "ورود"]
        info = ""
        if "MA200" in nm:
            tf = nm.split("ِ ")[-1]
            rr = T[T["وضعیت"] == "ورود"][f"سمتِ درست {tf}"]
            info = (f"- ستاپ‌هایِ سمتِ درست: {int((rr == 1).sum())} · سمتِ غلط: {int((rr == 0).sum())} "
                    f"(از این‌ها با واگراییِ 4h: {int(((rr == 0) & T.loc[rr.index, 'واگراییِ 4h']).sum())})\n")
        body = rep.split("## نتیجه", 1)[1].split("## ماهانه")[0]
        parts.append(f"# {nm}\n{info}## نتیجه{body}")
    open(os.path.join(a.out, "angelina2_compare.md"), "w", encoding="utf-8").write(
        "# Angelina در مقابلِ Angelina2 (۷ نماد · ۶ سال · $500 · $20 × ۱۰)\n\n" + "\n\n".join(parts))
    print(open(os.path.join(a.out, "angelina2_compare.md"), encoding="utf-8").read())


if __name__ == "__main__":
    main()
