# -*- coding: utf-8 -*-
"""v7: python run7.py --symbols BTC,ETH --years 6 --pivots 10,20,30,40,50 --waves origin (قابلِ ادامه)."""
import os, sys, glob, time, argparse
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fr as FR, fr7 as F7

CFG = {"fee_pct": 0.05, "wait_bars": 500, "max_hold_bars": 5000, "margin": 20.0, "lev": 10.0, "capital": 500.0}
HR = {"all": "همه‌یِ ساعت‌ها", "ex4_8_16_20": "بدونِ ۴–۸ و ۱۶–۲۰ UTC"}


def long_table(E, start, end):
    E = E[E["وضعیت"] == "ورود"].copy()
    E["بخش"] = FR.split_of(E["تأییدِ موج"], start, end)
    parts = []
    for xm in F7.EXITS7:
        if f"R {xm}" not in E:
            continue
        d = E[["موج", "نماد", "پیووت", "جهت", "sl", "ورود_حالت", "بخش", "ساعت", "SL٪", "زمانِ ورود"]].copy()
        d["خروج"] = xm; d["R"] = E[f"R {xm}"].to_numpy(); d["$"] = E[f"$ {xm}"].to_numpy(); d["مسیر"] = E[f"خروج {xm}"].to_numpy()
        parts.append(d)
    return pd.concat(parts, ignore_index=True)


def summarize(L, keys):
    out = []
    for ms in (0, 3):
        for hr in HR:
            d = L[(L["SL٪"] >= ms) & ((hr == "all") | ~(L["ساعت"].between(4, 7) | L["ساعت"].between(16, 19)))]
            g = d.groupby(keys).agg(n=("R", "size"), R=("R", "sum"), usd=("$", "sum"), win=("$", lambda x: (x > 0).mean())).reset_index()
            g["minSL"], g["hours"] = ms, hr
            out.append(g)
    S = pd.concat(out, ignore_index=True); S["امید"] = S["R"] / S["n"]
    return S


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbols", default="BTC,ETH"); ap.add_argument("--years", type=float, default=6)
    ap.add_argument("--pivots", default="10,20,30,40,50"); ap.add_argument("--waves", default="origin")
    ap.add_argument("--margin", type=float, default=20); ap.add_argument("--lev", type=float, default=10)
    ap.add_argument("--cache", default="/content/fr_cache"); ap.add_argument("--out", default="/content/fr7_results"); ap.add_argument("--end", default=None)
    a = ap.parse_args()
    CFG.update(margin=a.margin, lev=a.lev)
    ev_dir = os.path.join(a.out, "events"); os.makedirs(ev_dir, exist_ok=True)
    end = int(pd.Timestamp(a.end, tz="UTC").value // 10**6) if a.end else int(time.time() * 1000) // 3_600_000 * 3_600_000
    start = end - int(a.years * 365.25 * 86_400_000)
    import ccxt
    ex = ccxt.okx({"enableRateLimit": True})
    pivs = [int(x) for x in a.pivots.split(",")]
    for sym in [s.strip().upper() for s in a.symbols.split(",") if s.strip()]:
        D = {tf: FR.fetch(ex, sym, tf, start - 210 * FR.TF_MS["4h"], end, a.cache) for tf in ("15m", "1h")}
        F1, F15 = FR.Frame(D["1h"], "1h"), FR.Frame(D["15m"], "15m")
        ctx = F7.m15_context(F15)
        for wm in a.waves.split(","):
            for n in pivs:
                p = os.path.join(ev_dir, f"{sym}_p{n}_{wm}.csv.gz")
                if os.path.exists(p):
                    print(f"⏭  {sym} پیووت {n} {wm}", flush=True); continue
                t0 = time.time()
                ev = pd.DataFrame(F7.events7(F1, F15, ctx, n, CFG, sym, wm))
                ev = ev[ev["تأییدِ موج"] >= start] if len(ev) else ev
                ev.to_csv(p, index=False, compression="gzip")
                print(f"💾 {sym} پیووت {n} {wm}: {len(ev)} ({time.time() - t0:.0f}s)", flush=True)
    E = pd.concat([pd.read_csv(f) for f in glob.glob(os.path.join(ev_dir, "*.csv.gz"))], ignore_index=True)
    report(E, a.out, start, end)


def report(E, out, start, end):
    fill = E.groupby(["جهت", "ورود_حالت", "وضعیت"]).size().unstack(fill_value=0)
    L = long_table(E, start, end)
    K = ["موج", "جهت", "sl", "ورود_حالت", "خروج"]
    S = summarize(L, K); Sp = summarize(L, K + ["بخش"]); Sv = summarize(L, K + ["پیووت"])
    Sp.to_csv(os.path.join(out, "v7_by_split.csv"), index=False); Sv.to_csv(os.path.join(out, "v7_by_pivot.csv"), index=False)
    lab = lambda d: d.assign(ورود=d["ورود_حالت"].map(F7.ENTRY_FA), خروج_=d["خروج"].map(F7.EXIT7_FA))
    sec = []
    for (wm, sd, sl), g in lab(S).groupby(["موج", "جهت", "sl"]):
        for ms, hr in ((0, "all"), (3, "ex4_8_16_20")):
            x = g[(g["minSL"] == ms) & (g["hours"] == hr)]
            sec += [f"### {wm} · {sd} · SL {sl} · حداقلِ SL {ms}٪ · {HR[hr]}",
                    "امید (R):", x.pivot_table(index="ورود", columns="خروج_", values="امید").round(3).to_string(),
                    "سودِ دلاری:", x.pivot_table(index="ورود", columns="خروج_", values="usd").round(0).to_string(),
                    "تعداد:", x.pivot_table(index="ورود", columns="خروج_", values="n").to_string(), ""]
    T = Sv[Sv["n"] >= 50].sort_values("usd", ascending=False).head(25)
    tp = Sp.pivot_table(index=K + ["minSL", "hours"], columns="بخش", values="امید").round(3)
    sec2 = tp.reset_index().merge(S[K + ["minSL", "hours", "n", "امید", "usd"]], on=K + ["minSL", "hours"]).sort_values("usd", ascending=False).head(25)
    paths = L[(L["جهت"] == "لانگ") & L["خروج"].str.startswith("mt")].groupby(["خروج", "مسیر"]).size().rename("تعداد").reset_index().sort_values(["خروج", "تعداد"], ascending=[True, False])
    txt = ["# v7 — فیبو رویِ 1h، ورود با تأییدِ 15m، خروجِ چندتارگتی", "",
           "تعریف‌ها: بالایِ fr7.py. TP1 = سطحِ ۰ (۵۰٪ + SL به ورود) · TP2 و TP3 هر کدوم ۲۵٪. دلار: $" + f"{CFG['margin'] * CFG['lev']:g} هر معامله، کارمزدِ هر بخش جدا.",
           "", "## چند درصد ستاپ‌ها به ورود رسیدن", fill.to_string(), "", *sec,
           "## ۲۵ ترکیبِ برتر (سودِ دلاری، هر پیووت جدا، حداقل ۵۰ معامله)", T.round(3).to_string(index=False), "",
           "## ۲۵ ترکیبِ برتر (همه‌یِ پیووت‌ها با هم) و امید در هر بخش", sec2.to_string(index=False), "",
           "## مسیرِ خروج در چندتارگتی (لانگ)", paths.to_string(index=False)]
    open(os.path.join(out, "v7_report.md"), "w", encoding="utf-8").write("\n".join(txt))
    print("\n".join(txt[:80]))


if __name__ == "__main__":
    main()
