# -*- coding: utf-8 -*-
"""
v11 — منطقِ قفل‌شده (strategy_locked.json) رویِ ۳ تایم‌فریم × چند پیووت، با سرمایه‌یِ مشترک.
اگه فایلِ قفل تغییر کرده باشه (اثرِ انگشت جور نباشه)، اجرا نمیشه. فقط تایم، پیووت و بازه قابلِ‌تنظیم‌ان.
اجرا: python run9.py --days 182 --tfs 15m,1h,4h --pivots 10,20,30,40,50
"""
import os, sys, json, glob, time, hashlib, argparse
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fr as FR, fr7 as F7, run8 as R8


def load_lock():
    c = json.load(open(os.path.join(HERE, "strategy_locked.json"), encoding="utf-8"))
    h = hashlib.sha256(json.dumps(c, sort_keys=True).encode()).hexdigest()
    if h != open(os.path.join(HERE, "strategy_locked.sha256")).read().strip():
        raise SystemExit("❌ strategy_locked.json تغییر کرده — منطقِ قفل‌شده نیست.")
    return c


def main():
    L = load_lock()
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbols", default=R8.SYMBOLS); ap.add_argument("--days", type=float, default=182)
    ap.add_argument("--tfs", default="15m,1h,4h"); ap.add_argument("--pivots", default="10,20,30,40,50")
    ap.add_argument("--cache", default="/content/fr_cache"); ap.add_argument("--out", default="/content/fr11_results"); ap.add_argument("--end", default=None)
    a = ap.parse_args()
    R8.CFG.update(capital=L["capital"], margin=L["margin"], lev=L["lev"], fee_pct=L["fee_pct"], wave=L["wave"], min_sl=L["min_sl_pct"], bad_hours=L["bad_hours_utc"])
    os.makedirs(os.path.join(a.out, "events"), exist_ok=True)
    end = int(pd.Timestamp(a.end, tz="UTC").value // 10**6) if a.end else int(time.time() * 1000) // 3_600_000 * 3_600_000
    start = end - int(a.days * 86_400_000)
    tfs = [x for x in a.tfs.split(",") if x]; pivs = [int(x) for x in a.pivots.split(",")]
    warm = 210 * FR.TF_MS["4h"] + 60 * max(pivs) * max(FR.TF_MS[t] for t in tfs)
    import ccxt
    ex = ccxt.okx({"enableRateLimit": True})
    ev = {(tf, n): [] for tf in tfs for n in pivs}
    for sym in [s.strip().upper() for s in a.symbols.split(",") if s.strip()]:
        todo = [(tf, n) for tf in tfs for n in pivs if not os.path.exists(os.path.join(a.out, "events", f"{sym}_{tf}_p{n}.csv.gz"))]
        if todo:
            try:
                D = {tf: FR.fetch(ex, sym, tf, start - warm, end, a.cache) for tf in sorted(set(tfs + ["15m"]), key=lambda x: FR.TF_MS[x])}
            except Exception as e:                                        # noqa: BLE001
                print(f"  {sym}: داده نیومد ({e})", flush=True); continue
            if len(D["15m"]) < 2000:
                print(f"  {sym}: داده‌یِ کافی نیست", flush=True); continue
            F15 = FR.Frame(D["15m"], "15m"); c15 = F7.m15_context(F15)
            for tf in tfs:
                Fw = F15 if tf == "15m" else FR.Frame(D[tf], tf)
                cw = F7.m1h_context(Fw)
                for n in pivs:
                    p = os.path.join(a.out, "events", f"{sym}_{tf}_p{n}.csv.gz")
                    if os.path.exists(p):
                        continue
                    e = pd.DataFrame(F7.events7(Fw, F15, c15, n, R8.CFG, sym, L["wave"], ["direct"], ["single"], L["sl_variants"], gap=L["gap"], ctx1h=cw))
                    e = e[e["تأییدِ موج"] >= start] if len(e) else e
                    e.to_csv(p, index=False, compression="gzip")
            print(f"💾 {sym}", flush=True)
        for tf in tfs:
            for n in pivs:
                p = os.path.join(a.out, "events", f"{sym}_{tf}_p{n}.csv.gz")
                if os.path.exists(p) and os.path.getsize(p) > 50:
                    d = pd.read_csv(p)
                    if len(d):
                        ev[(tf, n)].append(d)
    report(ev, L, a.out, start, end)


def run_config(E, sl, L, start, end):
    d = R8.select(E, sl, L["filter"])
    if not len(d):
        return None
    taken, C, maxpos = R8.portfolio(d, L["capital"], L["margin"])
    t = d[taken].copy()
    u = t["$ single"]
    t["ماه"] = pd.to_datetime(t["خروج_ms"], unit="ms").dt.to_period("M")
    months = pd.period_range(pd.Timestamp(start, unit="ms").to_period("M"), pd.Timestamp(end, unit="ms").to_period("M"), freq="M")
    M = t.groupby("ماه")["$ single"].sum().reindex(months, fill_value=0.0)
    eqv = C["سرمایه"].to_numpy() if len(C) else np.array([L["capital"]])
    dd = float((eqv - np.maximum.accumulate(np.r_[L["capital"], eqv])[1:]).min()) if len(C) else 0.0
    side = {k: (len(v), round(v.sum(), 1)) for k, v in t.groupby("جهت")["$ single"]}
    return t, M, {"معاملات": len(t), "برد": int((u > 0).sum()), "باخت": int((u <= 0).sum()), "برد٪": round(100 * (u > 0).mean(), 1) if len(u) else 0,
                  "میانگینِ هر معامله $": round(u.mean(), 2) if len(u) else 0, "خالص $": round(u.sum(), 1), "سرمایه‌یِ پایانی $": round(L["capital"] + u.sum(), 1),
                  "بیشترین افت $": round(dd, 1), "میانگینِ ماهانه $": round(M.mean(), 1), "ماهِ مثبت/منفی": f"{int((M > 0).sum())}/{int((M < 0).sum())}",
                  "لانگ (تعداد، $)": side.get("لانگ", (0, 0)), "شورت (تعداد، $)": side.get("شورت", (0, 0)), "حداکثر هم‌زمان": maxpos}


def report(ev, L, out, start, end):
    rows, monthly = [], []
    for (tf, n), parts in ev.items():
        if not parts:
            continue
        E = pd.concat(parts, ignore_index=True)
        for sl in L["sl_variants"]:
            r = run_config(E, sl, L, start, end)
            if r is None:
                rows.append({"تایم": tf, "پیووت": n, "SL": sl, "معاملات": 0}); continue
            t, M, s = r
            rows.append({"تایم": tf, "پیووت": n, "SL": sl, **s})
            monthly.append(M.rename(f"{tf} p{n} {sl}"))
            t.to_csv(os.path.join(out, f"v11_trades_{tf}_p{n}_{sl}.csv"), index=False, encoding="utf-8-sig")
    T = pd.DataFrame(rows).sort_values(["SL", "تایم", "پیووت"])
    T.to_csv(os.path.join(out, "v11_summary.csv"), index=False, encoding="utf-8-sig")
    MM = pd.concat(monthly, axis=1).round(0) if monthly else pd.DataFrame()
    MM.to_csv(os.path.join(out, "v11_monthly.csv"), encoding="utf-8-sig")
    ts = lambda ms: pd.Timestamp(int(ms), unit="ms").strftime("%Y-%m-%d")
    txt = [f"# v11 — منطقِ قفل‌شده ({L['name']}) · {ts(start)} تا {ts(end)}", "",
           "فیبو رویِ تایمِ جدول · موجِ شروعِ کلِ حرکت · ورود ۰.۶۱۸ (شکاف ← بازار) · فیلتر: MA200 + هم‌جهتی + منعِ واگراییِ مخالف رویِ همون تایم ·",
           f"SL≥{L['min_sl_pct']:g}٪ · بدونِ ورود در ۴–۸ و ۱۶–۲۰ UTC · TP سطحِ ۰ +۱٪ · ${L['capital']:g} مشترک · ${L['margin']:g} × {L['lev']:g}", ""]
    for sl, nm in (("sl1", "SL سطحِ ۱"), ("sl05", "SL ۰.۵٪ بازتر")):
        x = T[T["SL"] == sl].drop(columns="SL")
        txt += [f"## {nm}", x.to_string(index=False), ""]
    txt += ["## سودِ ماهانه ($)", MM.T.to_string() if len(MM) else "-"]
    open(os.path.join(out, "v11_report.md"), "w", encoding="utf-8").write("\n".join(txt))
    print("\n".join(txt))


if __name__ == "__main__":
    main()
