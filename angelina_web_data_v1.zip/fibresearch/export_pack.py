# -*- coding: utf-8 -*-
"""
ساختِ بسته‌یِ داده برایِ Angelina Web از کندل‌هایِ واقعیِ OKX (همون دانلودکننده و کشِ بک‌تست‌هایِ پایتون).
python export_pack.py --symbols BTC,ETH,SOL,XRP,ADA,DOGE,SUI --path-tf 15m --days 2191 --out /content/angelina_15m_6y.fpk
شاملِ تایمِ مسیر (5m یا 15m) + 1h + 4h + 1d، با دیتایِ گرم‌شدنِ کافی قبل از شروع.
"""
import os, sys, time, argparse
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fr as FR, pack

WARM_DAYS = {"5m": 12, "15m": 12, "1h": 40, "4h": 140, "1d": 280}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbols", default="BTC,ETH,SOL,XRP,ADA,DOGE,SUI"); ap.add_argument("--path-tf", dest="path_tf", default="15m")
    ap.add_argument("--days", type=float, default=2191); ap.add_argument("--cache", default="/content/fr_cache"); ap.add_argument("--out", required=True)
    a = ap.parse_args()
    import ccxt
    ex = ccxt.okx({"enableRateLimit": True})
    end = int(time.time() * 1000) // 3_600_000 * 3_600_000
    start = end - int(a.days * 86_400_000)
    tfs = [a.path_tf] + [t for t in ("1h", "4h", "1d") if t != a.path_tf]
    series = []
    for sym in [s.strip().upper() for s in a.symbols.split(",") if s.strip()]:
        for tf in tfs:
            print(f"  {sym} {tf} ...", flush=True)
            d = FR.fetch(ex, sym, tf, start - WARM_DAYS[tf] * 86_400_000, end, a.cache)
            if len(d):
                series.append((sym, tf, d[["t", "open", "high", "low", "close"]]))
    pack.write_pack(a.out, series, {"source": "OKX USDT-M perpetual", "path_tf": a.path_tf, "start": start, "end": end, "created": int(time.time() * 1000)})
    print(f"📦 {a.out} · {os.path.getsize(a.out) / 1e6:.1f} MB · {len(series)} سری")


if __name__ == "__main__":
    main()
