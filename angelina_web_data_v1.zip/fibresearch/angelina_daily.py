# -*- coding: utf-8 -*-
"""
تحلیلِ روزانه‌یِ Angelina (فقط تحلیل — منطقِ قفل‌شده و نتایج تغییر نمی‌کنن).
معاملاتِ Angelina از رویِ رویدادهایِ angelina_results/events با همون قوانینِ پرتفو دوباره ساخته میشن (زمانِ ورود و خروج معلوم).
برایِ هر معامله، از آخرین کندلِ روزانه‌یِ بسته‌شده قبل از ورود:
  قیمت/MA200ِ روزانه: بالا یا زیر ← هم‌جهت (لانگ بالا / شورت زیر) یا خلاف
  چرخه‌یِ روزانه = علامتِ (MA200 الان − MA200ِ ۳۰ روزِ قبل) ← هم‌جهت یا خلاف
  تغییرِ چرخه در طولِ معامله: علامت بینِ ورود و خروج عوض شده؟ · سنِ چرخه: روز از آخرین تغییرِ علامت
اجرا: python angelina_daily.py --results /content/angelina_results
"""
import os, sys, json, glob, argparse
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fr as FR, run8 as R8, run_angelina as A


def rebuild(results):
    L = A.lock()
    fs = [f for f in glob.glob(os.path.join(results, "events", "*.csv.gz")) if os.path.getsize(f) > 50]
    E = pd.concat([pd.read_csv(f) for f in fs], ignore_index=True)
    d = E[(E["وضعیت"] == "ورود") & E["$ single"].notna()].copy()
    d["خروج_ms"] = d["زمانِ ورود"] + (d["مدت single"] * 3.6e6).astype("int64")
    d = d.sort_values("زمانِ ورود").reset_index(drop=True)
    tk, _, _ = R8.portfolio(d, L["capital"], L["margin"])
    return d[tk].sort_values("خروج_ms").reset_index(drop=True)


def daily_context(D1, slope_days=30):
    F = FR.Frame(D1, "1d")
    s = np.sign(F.ma - pd.Series(F.ma).shift(slope_days).to_numpy())
    s[~np.isfinite(s)] = 0
    last_flip = np.full(len(s), -1)
    lf = -1
    for i in range(1, len(s)):
        if s[i] != 0 and s[i - 1] != 0 and s[i] != s[i - 1]:
            lf = i
        last_flip[i] = lf
    return {"F": F, "sign": s, "last_flip": last_flip}


def tag(t, ctx):
    rows = []
    for _, r in t.iterrows():
        c = ctx[r["نماد"]]; F = c["F"]
        side = 1 if r["جهت"] == "لانگ" else -1
        j = F.closed_idx(np.array([int(r["زمانِ ورود"])]))[0]
        if j < 0 or not np.isfinite(F.ma[j]):
            rows.append({}); continue
        above = F.C[j] > F.ma[j]
        cyc = c["sign"][j]
        k = F.closed_idx(np.array([int(r["خروج_ms"])]))[0]
        flip = bool(k > j and (c["sign"][j + 1:k + 1] == -cyc).any()) if cyc != 0 else False
        age = (j - c["last_flip"][j]) if c["last_flip"][j] >= 0 else np.nan
        rows.append({"قیمت/MA200ِ روزانه": "هم‌جهت" if (above == (side == 1)) else "خلاف",
                     "چرخه‌یِ روزانه": "خنثی" if cyc == 0 else ("هم‌جهت" if cyc == side else "خلاف"),
                     "تغییرِ چرخه در معامله": "بله" if flip else "نه",
                     "سنِ چرخه (روز)": pd.cut([age], [-1, 30, 90, 180, 1e9], labels=["کمتر از ۳۰", "۳۰–۹۰", "۹۰–۱۸۰", "بیشتر از ۱۸۰"])[0] if np.isfinite(age) else "نامعلوم"})
    return pd.concat([t.reset_index(drop=True), pd.DataFrame(rows)], axis=1)


def stats(g):
    u = g["$ single"]
    w, l = u[u > 0].sum(), -u[u <= 0].sum()
    return pd.Series({"معاملات": len(u), "برد٪": round(100 * (u > 0).mean(), 1), "سود $": round(u.sum(), 1), "میانگین $": round(u.mean(), 2),
                      "PF": round(w / l, 2) if l > 0 else np.nan})


def report(T, out):
    T = T.copy(); T["سال"] = pd.to_datetime(T["خروج_ms"], unit="ms").dt.year
    txt = ["# Angelina — تحلیلِ روزانه (MA200ِ روزانه و چرخه‌یِ روزانه)", "",
           "هم‌جهت = لانگ وقتی قیمت بالایِ MA200ِ روزانه / چرخه صعودی؛ شورت برعکس. همه از آخرین کندلِ روزانه‌یِ بسته‌شده قبل از ورود.", "",
           f"کلِ معاملات: {len(T)} · سود ${T['$ single'].sum():+,.0f} (باید با گزارشِ Angelina یکی باشه)", ""]
    for col in ("قیمت/MA200ِ روزانه", "چرخه‌یِ روزانه", "تغییرِ چرخه در معامله", "سنِ چرخه (روز)"):
        txt += [f"## {col}", T.groupby(col).apply(stats).to_string(), ""]
    txt += ["## ترکیب: قیمت/MA200 × چرخه", T.groupby(["قیمت/MA200ِ روزانه", "چرخه‌یِ روزانه"]).apply(stats).to_string(), ""]
    txt += ["## ترکیب به تفکیکِ سال (سود $)", T.pivot_table(index=["قیمت/MA200ِ روزانه", "چرخه‌یِ روزانه"], columns="سال", values="$ single", aggfunc="sum").round(0).to_string(), ""]
    txt += ["## لانگ و شورت × قیمت/MA200", T.groupby(["جهت", "قیمت/MA200ِ روزانه"]).apply(stats).to_string(), ""]
    bad = T[(pd.to_datetime(T["خروج_ms"], unit="ms") >= "2025-05-01") & (pd.to_datetime(T["خروج_ms"], unit="ms") < "2025-08-15")]
    txt += ["## مه تا اوتِ ۲۰۲۵ (رشته‌یِ ۳۰ باخت)", bad.groupby(["قیمت/MA200ِ روزانه", "چرخه‌یِ روزانه"]).apply(stats).to_string() if len(bad) else "-", "",
            "## ۲۰۲۲ تا ۲۰۲۴", T[T["سال"].between(2022, 2024)].groupby(["قیمت/MA200ِ روزانه", "چرخه‌یِ روزانه"]).apply(stats).to_string()]
    open(os.path.join(out, "angelina_daily_report.md"), "w", encoding="utf-8").write("\n".join(txt))
    T.to_csv(os.path.join(out, "angelina_daily_trades.csv"), index=False, encoding="utf-8-sig")
    print("\n".join(txt))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="/content/angelina_results"); ap.add_argument("--cache", default="/content/fr_cache")
    ap.add_argument("--out", default="/content/angelina_daily_results")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    t = rebuild(a.results)
    import ccxt
    ex = ccxt.okx({"enableRateLimit": True})
    start = int(t["زمانِ ورود"].min()) - 300 * 86_400_000; end = int(t["خروج_ms"].max()) + 2 * 86_400_000
    ctx = {}
    for sym in sorted(t["نماد"].unique()):
        print(f"  روزانه‌یِ {sym} ...", flush=True)
        ctx[sym] = daily_context(FR.fetch(ex, sym, "1d", start, end, a.cache))
    report(tag(t, ctx), a.out)


if __name__ == "__main__":
    main()
