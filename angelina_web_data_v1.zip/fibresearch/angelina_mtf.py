# -*- coding: utf-8 -*-
"""
Angelina — MA200 در 15m، 1h، 4h و 1D در سه لحظه (فقط تحلیل؛ Angelina تغییر نمی‌کنه):
  موج = لحظه‌یِ تأییدِ موجِ 4h (کشیدنِ فیبو) · ورود · خروج
برایِ هر لحظه از آخرین کندلِ بسته‌شده‌یِ هر تایم: قیمت بالا/زیرِ MA200 (نسبت به جهتِ معامله: هم‌جهت/خلاف) و شیبِ MA200 (۳۰ کندل، هم‌جهت/خلاف).
اجرا: python angelina_mtf.py --results /content/angelina_results
"""
import os, sys, argparse
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fr as FR, angelina_daily as AD

TFS = ["15m", "1h", "4h", "1d"]
MOM = {"موج": "تأییدِ موج", "ورود": "زمانِ ورود", "خروج": "خروج_ms"}


def tag(t, frames):
    t = t.reset_index(drop=True).copy()
    side = np.where(t["جهت"] == "لانگ", 1, -1)
    for tf in TFS:
        for mn, col in MOM.items():
            pos = np.full(len(t), np.nan); slo = np.full(len(t), np.nan)
            for sym, F in frames[tf].items():
                m = (t["نماد"] == sym).to_numpy()
                if not m.any():
                    continue
                j = F.closed_idx(t.loc[m, col].astype("int64").to_numpy())
                ok = j >= 0
                jj = np.clip(j, 0, None)
                ma, c = F.ma[jj], F.C[jj]
                ma30 = pd.Series(F.ma).shift(30).to_numpy()[jj]
                p_ = np.where(ok & np.isfinite(ma), np.sign(c - ma), np.nan)
                s_ = np.where(ok & np.isfinite(ma30), np.sign(ma - ma30), np.nan)
                pos[m], slo[m] = p_, s_
            t[f"{tf}|{mn}|قیمت"] = np.where(np.isnan(pos), np.nan, pos * side)
            t[f"{tf}|{mn}|شیب"] = np.where(np.isnan(slo), np.nan, slo * side)
    t["نتیجه"] = np.where(t["$ single"] > 0, "برد", "باخت")
    return t


def lab(v):
    return "هم‌جهت" if v > 0 else ("خلاف" if v < 0 else "؟")


def report(T, out):
    txt = ["# Angelina — MA200ِ 15m، 1h، 4h و 1D در لحظه‌یِ فیبو، ورود و خروج", "",
           "هم‌جهت = لانگ وقتی قیمت بالایِ MA200 (یا شیبِ MA200 رو به بالا)؛ شورت برعکس. از آخرین کندلِ بسته‌شده‌یِ هر تایم.",
           f"معاملات: {len(T)} · برد {int((T['نتیجه'] == 'برد').sum())} · باخت {int((T['نتیجه'] == 'باخت').sum())} · سود ${T['$ single'].sum():+,.0f}", ""]
    for kind in ("قیمت", "شیب"):
        rows = []
        for tf in TFS:
            for mn in MOM:
                c = f"{tf}|{mn}|{kind}"
                g = T[T[c].notna()]
                for v, nm in ((1, "هم‌جهت"), (-1, "خلاف")):
                    x = g[g[c] == v]
                    if len(x):
                        rows.append({"تایم": tf, "لحظه": mn, "حالت": nm, "معاملات": len(x), "برد٪": round(100 * (x["$ single"] > 0).mean(), 1),
                                     "سود $": round(x["$ single"].sum(), 1), "میانگین $": round(x["$ single"].mean(), 2)})
        R = pd.DataFrame(rows)
        txt += [f"## {'قیمت نسبت به MA200' if kind == 'قیمت' else 'شیبِ MA200'} — برد٪ و سود در هر حالت",
                R.pivot_table(index=["تایم", "لحظه"], columns="حالت", values=["برد٪", "سود $", "معاملات"]).round(1).to_string(), ""]
        sh = []
        for tf in TFS:
            for res in ("برد", "باخت"):
                x = T[T["نتیجه"] == res]
                for mn in MOM:
                    c = f"{tf}|{mn}|{kind}"
                    sh.append({"تایم": tf, "نتیجه": res, "لحظه": mn, "هم‌جهت٪": round(100 * (x[c] > 0).mean(), 1)})
        S = pd.DataFrame(sh).pivot_table(index=["تایم", "نتیجه"], columns="لحظه", values="هم‌جهت٪")[list(MOM)]
        txt += [f"### چند درصد از بردها / باخت‌ها {'قیمتشون' if kind == 'قیمت' else 'شیبشون'} هم‌جهت بوده (موج → ورود → خروج)", S.to_string(), ""]
        ch = []
        for tf in TFS:
            a, b = f"{tf}|ورود|{kind}", f"{tf}|خروج|{kind}"
            for res in ("برد", "باخت"):
                x = T[(T["نتیجه"] == res) & T[a].notna() & T[b].notna()]
                ch.append({"تایم": tf, "نتیجه": res, "هم‌جهت ← خلاف٪": round(100 * ((x[a] > 0) & (x[b] < 0)).mean(), 1),
                           "خلاف ← هم‌جهت٪": round(100 * ((x[a] < 0) & (x[b] > 0)).mean(), 1), "بدونِ تغییر٪": round(100 * (x[a] == x[b]).mean(), 1)})
        txt += [f"### تغییر از ورود تا خروج ({kind})", pd.DataFrame(ch).to_string(index=False), ""]
    T["تعدادِ تایمِ هم‌جهت در ورود"] = sum((T[f"{tf}|ورود|قیمت"] > 0).astype(int) for tf in TFS)
    txt += ["## تعدادِ تایم‌هایی که قیمت در لحظه‌یِ ورود سمتِ درستِ MA200 بوده (۰ تا ۴)",
            T.groupby("تعدادِ تایمِ هم‌جهت در ورود").apply(lambda x: pd.Series({"معاملات": len(x), "برد٪": round(100 * (x["$ single"] > 0).mean(), 1), "سود $": round(x["$ single"].sum(), 1)})).to_string(), "",
            "## لانگ و شورت — قیمت نسبت به MA200 در لحظه‌یِ ورود (هر تایم)"]
    for tf in TFS:
        c = f"{tf}|ورود|قیمت"
        g = T[T[c].notna()].groupby(["جهت", T[c].map(lab)])["$ single"].agg(["size", "sum", lambda x: round(100 * (x > 0).mean(), 1)])
        g.columns = ["معاملات", "سود $", "برد٪"]
        txt += [f"### {tf}", g.round(1).to_string(), ""]
    open(os.path.join(out, "angelina_mtf_report.md"), "w", encoding="utf-8").write("\n".join(txt))
    T.to_csv(os.path.join(out, "angelina_mtf_trades.csv"), index=False, encoding="utf-8-sig")
    print("\n".join(txt))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="/content/angelina_results"); ap.add_argument("--cache", default="/content/fr_cache")
    ap.add_argument("--out", default="/content/angelina_mtf_results")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    t = AD.rebuild(a.results)
    import ccxt
    ex = ccxt.okx({"enableRateLimit": True})
    frames = {tf: {} for tf in TFS}
    for sym in sorted(t["نماد"].unique()):
        s0 = int(t[t["نماد"] == sym]["تأییدِ موج"].min()); e0 = int(t[t["نماد"] == sym]["خروج_ms"].max()) + 86_400_000
        for tf in TFS:
            warm = 240 * FR.TF_MS[tf]
            print(f"  {sym} {tf} ...", flush=True)
            frames[tf][sym] = FR.Frame(FR.fetch(ex, sym, tf, s0 - warm, e0, a.cache), tf)
    report(tag(t, frames), a.out)


if __name__ == "__main__":
    main()
