# -*- coding: utf-8 -*-
"""
v2 — همون قراردادهایِ fr.py + مقایسه‌یِ TP، SL، تغییرِ چرخه و فیلترِ ورود.
  TP:  tp0 = سطحِ ۰ · tp05 = ۰.۵٪ اونطرفِ سطحِ ۰ · tp1 = ۱٪ اونطرف · ext = اکستنشنِ ‎-۰.۲۷ (Fib(-0.27))
  SL:  sl1 = سطحِ ۱ · sl05 = ۰.۵٪ اونطرفِ سطحِ ۱                   R = |ورود − SL| (برایِ هر SL جدا)
  چرخه: none · 15m · 1h · 4h — علامتِ شیبِ MA200 (۳۰ کندل)؛ ورود فقط وقتی چرخه (آخرین کندلِ بسته‌شده قبل از ورود) هم‌جهتِ معامله‌ست؛
        اگه بعداً در بسته‌شدنِ یه کندلِ معامله خلاف بشه ← خروج با کلوزِ همون کندل (TP/SL داخلِ همون کندل اولویت دارن)
  فیلترِ ورود رویِ تایمِ معامله، آخرین کندلِ بسته‌شده قبل از ورود: هم‌جهتی (کلوز و RSI14 هر دو بالاتر/پایین‌تر از ۵ کندلِ قبل) ·
        واگراییِ معمولی · واگراییِ مخفی (پیووت ۳/۳، فاصله ۵ تا ۶۰ کندل، معتبر تا ۱۰ کندل بعد از تأییدِ پیووتِ دوم)
"""
import numpy as np
import pandas as pd
import fr as FR

TPS = {"tp0": None, "tp05": 0.005, "tp1": 0.01, "ext": "ext"}
SLS = {"sl1": 0.0, "sl05": 0.005}
CYCLES = ["none", "15m", "1h", "4h"]
EXITS = ["none", "be1", "part1"]          # بدون · SL به ورود بعد از +۱R · ۵۰٪ در +۱R و بقیه با SL در ورود
FILTERS = ["none", "align", "reg", "hid"]
FILTER_FA = {"none": "بدونِ فیلتر", "align": "هم‌جهتی", "reg": "واگراییِ معمولی", "hid": "واگراییِ مخفی"}


def rsi(c, n=14):
    d = np.diff(np.asarray(c, float), prepend=np.nan)
    up = pd.Series(np.where(d > 0, d, 0.0)).ewm(alpha=1 / n, adjust=False, min_periods=n).mean()
    dn = pd.Series(np.where(d < 0, -d, 0.0)).ewm(alpha=1 / n, adjust=False, min_periods=n).mean()
    return (100 - 100 / (1 + up / dn.replace(0, np.nan))).fillna(100.0).where(up.notna()).to_numpy()


def filter_flags(F, n=3, gap=(5, 60), valid=10):
    """پرچم‌هایِ هر کندل (معتبر از بسته‌شدنِ همون کندل): bull_reg, bull_hid, bear_reg, bear_hid, align_up, align_dn."""
    H, L, C = F.H, F.L, F.C
    N = len(C); r = rsi(C)
    f = {k: np.zeros(N, bool) for k in ("bull_reg", "bull_hid", "bear_reg", "bear_hid")}
    ph, pl = FR.pivots(H, L, n)
    for piv, Y, kind in ((pl, L, "bull"), (ph, H, "bear")):
        for a in range(1, len(piv)):
            p1, p2 = piv[a - 1], piv[a]
            if not (gap[0] <= p2 - p1 <= gap[1]) or not (np.isfinite(r[p1]) and np.isfinite(r[p2])) or p2 + n >= N:
                continue
            if kind == "bull":
                key = "bull_reg" if (Y[p2] < Y[p1] and r[p2] > r[p1]) else ("bull_hid" if (Y[p2] > Y[p1] and r[p2] < r[p1]) else None)
            else:
                key = "bear_reg" if (Y[p2] > Y[p1] and r[p2] < r[p1]) else ("bear_hid" if (Y[p2] < Y[p1] and r[p2] > r[p1]) else None)
            if key:
                f[key][p2 + n:min(N, p2 + n + valid)] = True
    c5, r5 = pd.Series(C).shift(5).to_numpy(), pd.Series(r).shift(5).to_numpy()
    f["align_up"] = (C > c5) & (r > r5)
    f["align_dn"] = (C < c5) & (r < r5)
    return f


def cycle_arrays(F, ctx):
    """برایِ هر چرخه: علامتِ شیب در بسته‌شدنِ هر کندلِ معامله، و در لحظه‌یِ بازشدنِ هر کندل (برایِ تصمیمِ ورود)."""
    out = {}
    for tf in CYCLES[1:]:
        X = ctx[tf]
        s = np.sign(X.slope); s[~np.isfinite(s)] = 0
        jc, jo = X.closed_idx(F.ct), X.closed_idx(F.t)
        out[tf] = (np.where(jc >= 0, s[np.clip(jc, 0, None)], 0), np.where(jo >= 0, s[np.clip(jo, 0, None)], 0))
    return out


def _resolve(F, fine, e, i_tp, i_sl, side, entry, tp, sl, seg=None):
    """seg = (hh, ll) از کندلِ ورود به بعد — برایِ ادامه‌یِ جستجو وقتی برخوردِ کندلِ ورود قبل از ورود بوده."""
    """نتیجه‌یِ یه جفتِ TP/SL از اندیس‌هایِ اولین برخورد (نسبت به e). خروجی: ('TP'|'SL'|'مبهم'|'باز', اندیسِ خروج)."""
    if i_tp is None and i_sl is None:
        return "باز", None
    if i_tp is not None and (i_sl is None or i_tp < i_sl) and i_tp > 0:
        return "TP", i_tp
    if i_sl is not None and (i_tp is None or i_sl < i_tp):
        return "SL", i_sl
    k = i_tp                                                        # TP در کندلِ ورود، یا TP و SL در یه کندل ← 5m
    if fine is None or F.tf == "5m":
        return "مبهم", k
    rf = FR.refine(fine, F.t[e + k], F.t[e + k] + FR.TF_MS[F.tf], side, entry, k == 0, sl, {"TP": tp})
    if rf is None or "TP" in rf["amb"]:
        return "مبهم", k
    if rf["TP"] is not None and (rf["sl"] is None or rf["TP"] < rf["sl"]):
        return "TP", k
    if rf["sl"] is not None:
        return "SL", k
    if k == 0 and seg is not None:                                  # برخوردهایِ کندلِ ورود قبل از ورود بودن ← جستجو از کندلِ ۱
        hh, ll = seg
        nt = FR._first((hh[1:] >= tp) if side == 1 else (ll[1:] <= tp))
        ns = i_sl if (i_sl is not None and i_sl > 0) else FR._first((ll[1:] <= sl) if side == 1 else (hh[1:] >= sl))
        ns = ns if (i_sl is not None and i_sl > 0) else (None if ns is None else ns + 1)
        return _resolve(F, fine, e, None if nt is None else nt + 1, ns, side, entry, tp, sl, None)
    return "مبهم", k


def _manage(xm, res, ix, i1, i_tp, be_idx, flip, tpR, lv, side, C, e, R, fee_R):
    """مدیریتِ خروج رویِ نتیجه‌یِ پایه (اندیس‌ها نسبت به e). SL از کندلِ بعد از +۱R به ورود میره؛ +۱R و SL در یه کندل ← SL؛
    TP و برگشت به ورود در یه کندل ← ورود؛ چرخه در کلوز. خروجی: (برچسب، سودِ خالص R)."""
    cyc_pnl = lambda k: side * (C[e + k] - lv) / R
    if xm == "none" or i1 is None or (ix is not None and ix <= i1 and res in ("TP", "SL", "مبهم")):
        if flip is not None and (ix is None or flip < ix):
            return "چرخه", cyc_pnl(flip) - fee_R
        return res, {"TP": tpR - fee_R, "SL": -1 - fee_R}.get(res, np.nan)
    if flip is not None and flip < i1:
        return "چرخه", cyc_pnl(flip) - fee_R
    cands = [(i_tp, "TP"), (be_idx, "ورود"), (flip, "چرخه")]
    cands = [c for c in cands if c[0] is not None and (c[0] > i1 or (c[1] == "چرخه" and c[0] >= i1))]
    if not cands:
        return "باز", np.nan
    k, lab = min(cands, key=lambda c: (c[0], {"ورود": 0, "TP": 1, "چرخه": 2}[c[1]]))
    rest = {"TP": tpR, "ورود": 0.0, "چرخه": cyc_pnl(k)}[lab]
    if xm == "be1":
        return ("SL در ورود" if lab == "ورود" else lab), rest - fee_R
    return "نیمه + " + lab, 0.5 + 0.5 * rest - fee_R


def events2(F, fine, ctx, cyc, flags, n, cfg, sym, wave_mode="between", tps=None, sls=None, cycles=None, exits=None, przc=None):
    rows = []
    tps = tps or list(TPS); sls = sls or list(SLS); cycles = cycles or CYCLES; exits = exits or EXITS
    wait, max_bars, fee = cfg["wait_bars"], cfg["max_hold_bars"], cfg["fee_pct"]
    H, L, C = F.H, F.L, F.C
    for (k, side, i0, j, p1, p0) in FR.waves(F, n, wave_mode):
        if k + 1 >= len(H):
            continue
        stop = min(len(H), k + 1 + wait)
        brk = FR._first((H[k + 1:stop] > p0) if side == 1 else (L[k + 1:stop] < p0))
        tp_px = {nm: (p0 if v is None else FR.fib(p1, p0, -0.27) if v == "ext" else p0 * (1 + side * v)) for nm, v in TPS.items() if nm in tps}
        sl_px = {nm: p1 * (1 - side * v) for nm, v in SLS.items() if nm in sls}
        for r in FR.LEVELS:
            lv = FR.fib(p1, p0, r)
            if (H[k + 1] < lv) if side == 1 else (L[k + 1] > lv):
                continue                                             # شکاف در لحظه‌یِ فعال‌شدن
            touch = FR._first((L[k + 1:stop] <= lv) & (H[k + 1:stop] >= lv))
            if touch is None or (brk is not None and brk <= touch):
                continue
            e = k + 1 + touch
            end = min(len(H), e + max_bars)
            hh, ll = H[e:end], L[e:end]
            i_tp = {nm: FR._first((hh >= px) if side == 1 else (ll <= px)) for nm, px in tp_px.items()}
            i_sl = {nm: FR._first((ll <= px) if side == 1 else (hh >= px)) for nm, px in sl_px.items()}
            sd = "long" if side == 1 else "short"
            row = {"موج": wave_mode, "نماد": sym, "تایم": F.tf, "پیووت": n, "جهت": "لانگ" if side == 1 else "شورت", "سطح": r, "تأییدِ موج": int(F.ct[k]),
                   "زمانِ ورود": int(F.t[e]), "ورود": lv, "ساعت": int(F.t[e] // 3_600_000 % 24),
                   **{f"R٪ {sn}": abs(lv - slp) / lv * 100 for sn, slp in sl_px.items()},
                   **(dict(zip(("prz_fib", "prz_sr"), prz_flags(przc, int(F.t[e]), side, lv, (p1, p0), n))) if przc is not None else {}),
                   "f_align": bool(flags["align_up" if side == 1 else "align_dn"][e - 1]),
                   "f_reg": bool(flags["bull_reg" if side == 1 else "bear_reg"][e - 1]),
                   "f_hid": bool(flags["bull_hid" if side == 1 else "bear_hid"][e - 1])}
            base = {}
            for tn, tp in tp_px.items():
                for sn, sl in sl_px.items():
                    base[(tn, sn)] = _resolve(F, fine, e, i_tp[tn], i_sl[sn], side, lv, tp, sl, (hh, ll))
            i1, be_after = {}, {}
            for sn, slp in sl_px.items():
                R_ = abs(lv - slp)
                i1[sn] = FR._first((hh >= lv + R_) if side == 1 else (ll <= lv - R_))
                if i1[sn] is not None:
                    q = FR._first((ll[i1[sn] + 1:] <= lv) if side == 1 else (hh[i1[sn] + 1:] >= lv))
                    be_after[sn] = None if q is None else i1[sn] + 1 + q
            for cm in cycles:
                if cm != "none":
                    at_close, at_open = cyc[cm]
                    if at_open[e] != side:
                        for tn in tp_px:
                            for sn in sl_px:
                                for xm in exits:
                                    row[f"{tn}|{sn}|{cm}|{xm}"] = "x"; row[f"R {tn}|{sn}|{cm}|{xm}"] = np.nan
                        continue
                    flip = FR._first(at_close[e:end] == -side)
                else:
                    flip = None
                for (tn, sn), (res, ix) in base.items():
                    R = abs(lv - sl_px[sn]); fee_R = 2 * fee / 100 * lv / R; tpR = abs(tp_px[tn] - lv) / R
                    for xm in exits:
                        lab_, pnl = _manage(xm, res, ix, i1[sn], i_tp[tn], be_after.get(sn), flip, tpR, lv, side, C, e, R, fee_R)
                        row[f"{tn}|{sn}|{cm}|{xm}"] = lab_; row[f"R {tn}|{sn}|{cm}|{xm}"] = pnl
                if flip is not None and ("tp0", "sl1") in base:          # بعد از خروجِ چرخه (TP/SLِ پایه): اول به کدوم رسید؟
                    b, x = base[("tp0", "sl1")]
                    if x is None or flip < x:
                        q = e + flip + 1
                        if q < end:
                            a1 = FR._first((H[q:end] >= tp_px["tp0"]) if side == 1 else (L[q:end] <= tp_px["tp0"]))
                            a2 = FR._first((L[q:end] <= sl_px["sl1"]) if side == 1 else (H[q:end] >= sl_px["sl1"]))
                            row[f"بعد از چرخه {cm}"] = ("TP" if a1 is not None and (a2 is None or a1 < a2) else
                                                        "SL" if a2 is not None and (a1 is None or a2 < a1) else ("هم‌زمان" if a1 is not None else "هیچ"))
            rows.append(row)
    return rows


# ================================================================ v6: تأییدِ PRZ
HIGHER = {"5m": "15m", "15m": "1h", "1h": "4h"}


def prz_context(Fr, tf, pivs, wave_mode, sr_n=5, sr_bars=500):
    """منابعِ PRZ برایِ تایمِ معامله: موج‌هایِ تأییدشده (هر پیووت، همین تایم و تایمِ بالاتر) و سقف/کف‌هایِ پیووتِ ۵ (همین تایم و تایمِ بالاتر).
    هر منبع با زمانِ تأیید (ms، بسته‌شدنِ کندلِ تأیید) ذخیره میشه تا فقط اطلاعاتِ قبل از ورود استفاده بشه."""
    srcs = []
    for t in (tf, HIGHER.get(tf)):
        if t is None or t not in Fr:
            continue
        X = Fr[t]
        for n in pivs:
            W = FR.waves(X, n, wave_mode)
            for side in (1, -1):
                w = [x for x in W if x[1] == side]
                if w:
                    srcs.append({"tf": t, "n": n, "side": side, "ct": np.array([X.ct[x[0]] for x in w], np.int64),
                                 "p1": np.array([x[4] for x in w]), "p0": np.array([x[5] for x in w])})
    sr_t, sr_p = [], []
    for t in (tf, HIGHER.get(tf)):
        if t is None or t not in Fr:
            continue
        X = Fr[t]
        ph, pl = FR.pivots(X.H, X.L, sr_n)
        sr_t += [X.ct[j + sr_n] for j in ph] + [X.ct[j + sr_n] for j in pl]
        sr_p += [X.H[j] for j in ph] + [X.L[j] for j in pl]
    o = np.argsort(sr_t)
    return {"waves": srcs, "sr_t": np.array(sr_t, np.int64)[o], "sr_p": np.array(sr_p, float)[o], "sr_win": sr_bars * FR.TF_MS[tf], "tf": tf}


def prz_flags(pc, t_ms, side, lv, own, n_own, tol=0.003):
    """(همپوشانیِ فیبو، سطحِ حمایت/مقاومت) برایِ ورود در قیمتِ lv در لحظه‌یِ t_ms."""
    fib_hit = False
    for s in pc["waves"]:
        if s["side"] != side:
            continue
        i = np.searchsorted(s["ct"], t_ms, side="right") - 1
        if i < 0:
            continue
        p1, p0 = s["p1"][i], s["p0"][i]
        if s["tf"] == pc["tf"] and s["n"] == n_own and abs(p1 - own[0]) < 1e-12 and abs(p0 - own[1]) < 1e-12:
            continue                                                  # همون موجِ خودِ معامله
        for r in (0.5, 0.618, 0.786):
            if abs(FR.fib(p1, p0, r) - lv) / lv <= tol:
                fib_hit = True; break
        if fib_hit:
            break
    a, b = np.searchsorted(pc["sr_t"], t_ms - pc["sr_win"]), np.searchsorted(pc["sr_t"], t_ms, side="right")
    sr_hit = bool(b > a and (np.abs(pc["sr_p"][a:b] - lv) / lv <= tol).any())
    return fib_hit, sr_hit
