# -*- coding: utf-8 -*-
"""
v13 — سه روشِ مستقل (A، B، C) · ۶ ماه · ۲۹ نماد · لانگ و شورت · $500 مشترک برایِ هر تنظیم · $20 × ۱۰
  A = موجِ کلِ حرکت (origin) · B = فقط بعد از شکستِ سقف/کفِ پیووتِ قبلی با کلوز (bos) · C = آخرین سقف و کفِ پیووت (lastpivot)
  آزمایشِ ۱: فیبو 1h (پیووت ۳۰) و 4h (پیووت ۲۰) · ورودِ مستقیم ۰.۶۱۸ رویِ 5m (شکاف ← بازار)
  آزمایشِ ۲: همون فیبو · بعد از لمسِ ۰.۶۱۸، ورود با شکستِ آخرین سقف/کفِ پیووتِ 5m (پیووت ۵/۱۰/۱۵/۲۰/۳۰)
  آزمایشِ ۳: فیبو و ورود هر دو رویِ 5m (پیووت ۵/۱۰/۱۵/۲۰/۳۰) · ورودِ مستقیم
  خروج: TP سطحِ ۰ (single0) یا سطحِ ۰ +۱٪ (single) · SL سطحِ ۱ · مسیرِ قیمت رویِ 5m · کارمزد ۰.۰۵٪ هر طرف
"""
import os, sys, time, argparse
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fr as FR, fr7 as F7, run8 as R8

METHODS = {"A": "origin", "B": "bos", "C": "lastpivot"}
P5 = [5, 10, 15, 20, 30]
HTF = {"1h": 30, "4h": 20}
EXF = {"single0": "TP سطحِ ۰", "single": "TP سطحِ ۰ +۱٪"}


def metrics(t, cap):
    u = t["$ single_x"]
    if not len(u):
        return {"معاملات": 0}
    w, l = u[u > 0].sum(), -u[u <= 0].sum()
    eq = cap + np.cumsum(t.sort_values("خروج_ms")["$ single_x"].to_numpy())
    dd = float((eq - np.maximum.accumulate(np.r_[cap, eq])[1:]).min())
    return {"معاملات": len(u), "برد٪": round(100 * (u > 0).mean(), 1), "سودِ خالص $": round(u.sum(), 1), "PF": round(w / l, 2) if l > 0 else np.inf,
            "Max DD $": round(dd, 1), "لانگ": int((t["جهت"] == "لانگ").sum()), "شورت": int((t["جهت"] == "شورت").sum())}


def run_one(E, ex, cap, mg):
    d = E[(E["وضعیت"] == "ورود") & E[f"$ {ex}"].notna()].copy()
    if not len(d):
        return {"معاملات": 0}
    d["$ single_x"] = d[f"$ {ex}"]; d["$ single"] = d[f"$ {ex}"]
    d["خروج_ms"] = d["زمانِ ورود"] + (d[f"مدت {ex}"] * 3.6e6).astype("int64")
    d = d.sort_values("زمانِ ورود").reset_index(drop=True)
    tk, C, mx = R8.portfolio(d, cap, mg)
    return metrics(d[tk], cap)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbols", default=R8.SYMBOLS); ap.add_argument("--days", type=float, default=182)
    ap.add_argument("--capital", type=float, default=500); ap.add_argument("--margin", type=float, default=20); ap.add_argument("--lev", type=float, default=10)
    ap.add_argument("--cache", default="/content/fr_cache"); ap.add_argument("--out", default="/content/fr13_results")
    a = ap.parse_args()
    R8.CFG.update(capital=a.capital, margin=a.margin, lev=a.lev)
    os.makedirs(os.path.join(a.out, "events"), exist_ok=True)
    end = int(time.time() * 1000) // 3_600_000 * 3_600_000
    start = end - int(a.days * 86_400_000)
    import ccxt
    ex = ccxt.okx({"enableRateLimit": True})
    store = {}
    for sym in [s.strip().upper() for s in a.symbols.split(",") if s.strip()]:
        p = os.path.join(a.out, "events", f"{sym}.csv.gz")
        if not os.path.exists(p):
            try:
                D = {"5m": FR.fetch(ex, sym, "5m", start - 20 * 86_400_000, end, a.cache),
                     "1h": FR.fetch(ex, sym, "1h", start - 60 * 86_400_000, end, a.cache),
                     "4h": FR.fetch(ex, sym, "4h", start - 120 * 86_400_000, end, a.cache)}
            except Exception as e:                                          # noqa: BLE001
                print(f"  {sym}: داده نیومد ({e})", flush=True); continue
            if len(D["5m"]) < 5000:
                print(f"  {sym}: داده‌یِ کافی نیست", flush=True); continue
            F5 = FR.Frame(D["5m"], "5m"); c5 = F7.m15_context(F5); c5.update(F7.bos_flags(F5, P5))
            rows = []
            for m, wm in METHODS.items():
                for tf, n in HTF.items():                                     # آزمایش ۱ و ۲
                    Fw = FR.Frame(D[tf], tf)
                    ev = F7.events7(Fw, F5, c5, n, R8.CFG, sym, wm, ["direct"] + [f"bos5_{k}" for k in P5], ["single0", "single"], ["sl1"], gap="market")
                    rows += [dict(r, روش=m, محدوده=f"{tf} p{n}") for r in ev]
                for k in P5:                                                  # آزمایش ۳
                    ev = F7.events7(F5, F5, c5, k, R8.CFG, sym, wm, ["direct"], ["single0", "single"], ["sl1"], gap="market")
                    rows += [dict(r, روش=m, محدوده=f"5m p{k}") for r in ev]
            E = pd.DataFrame(rows)
            E = E[E["تأییدِ موج"] >= start] if len(E) else E
            E.to_csv(p, index=False, compression="gzip")
            print(f"💾 {sym}: {int((E['وضعیت'] == 'ورود').sum()) if len(E) else 0} ورود", flush=True)
        if os.path.getsize(p) > 50:
            x = pd.read_csv(p)
            if len(x):
                store[sym] = x
    E = pd.concat(store.values(), ignore_index=True)
    report(E, a, start, end)


def report(E, a, start, end):
    rows = []
    for (m, rng, em), g in E.groupby(["روش", "محدوده", "ورود_حالت"]):
        exp = 3 if rng.startswith("5m") else (1 if em == "direct" else 2)
        for exn in EXF:
            r = run_one(g, exn, a.capital, a.margin)
            rows.append({"آزمایش": exp, "روش": m, "فیبو": rng, "ورود": "مستقیم ۰.۶۱۸" if em == "direct" else f"شکستِ پیووتِ 5m ({em.split('_')[1]})", "خروج": EXF[exn], **r})
    T = pd.DataFrame(rows)
    T.to_csv(os.path.join(a.out, "v13_all.csv"), index=False, encoding="utf-8-sig")
    ts = lambda ms: pd.Timestamp(int(ms), unit="ms").strftime("%Y-%m-%d")
    cols = ["فیبو", "ورود", "خروج", "معاملات", "برد٪", "سودِ خالص $", "PF", "Max DD $", "لانگ", "شورت"]
    txt = [f"# v13 — روش‌هایِ A، B، C (جدا) · {ts(start)} تا {ts(end)} · {E['نماد'].nunique()} نماد · ${a.capital:g} مشترک برایِ هر تنظیم · ${a.margin:g} × {a.lev:g}", "",
           "A = کلِ حرکت · B = بعد از شکستِ سقف/کفِ پیووتِ قبلی (کلوز) · C = آخرین سقف و کفِ پیووت · ورود ۰.۶۱۸ · SL سطحِ ۱ · لانگ و شورت · فقط کندل/پیووتِ تأییدشده", ""]
    names = {1: "آزمایشِ ۱ — فیبو 1h/4h · ورودِ مستقیم رویِ 5m", 2: "آزمایشِ ۲ — فیبو 1h/4h · ورود با شکستِ پیووتِ 5m", 3: "آزمایشِ ۳ — فیبو و ورود رویِ 5m"}
    for exp, nm in names.items():
        txt += [f"## {nm}"]
        for m in METHODS:
            x = T[(T["آزمایش"] == exp) & (T["روش"] == m)]
            if len(x):
                txt += [f"### روشِ {m}", x[cols].to_string(index=False), ""]
    txt += ["## بهترین تنظیمات (بیشترین سودِ خالص؛ PF و Max DD کنارش)"]
    for m in METHODS:
        x = T[(T["روش"] == m) & (T["معاملات"] > 0)].sort_values("سودِ خالص $", ascending=False).head(3)
        txt += [f"### روشِ {m}", x[["آزمایش"] + cols].to_string(index=False), ""]
    best = T[T["معاملات"] >= 30].sort_values("PF", ascending=False).head(10)
    txt += ["## بیشترین Profit Factor (حداقل ۳۰ معامله)", best[["آزمایش", "روش"] + cols].to_string(index=False)]
    open(os.path.join(a.out, "v13_report.md"), "w", encoding="utf-8").write("\n".join(txt))
    print("\n".join(txt))


if __name__ == "__main__":
    main()
