# -*- coding: utf-8 -*-
"""
Angelina — استراتژیِ قفل‌شده (angelina.json + angelina.sha256). اگه فایلِ قفل تغییر کنه، اجرا نمیشه.
فیبو 4h · پیووت ۲۰ · روشِ B (شکستِ سقف/کفِ پیووتِ قبلی با کلوز) · ورود ۰.۶۱۸ رویِ 5m (شکاف ← بازار) · TP سطحِ ۰ +۱٪ · SL سطحِ ۱
بدونِ فیلتر · لانگ و شورت · $500 مشترک · $20 × ۱۰ · یه پوزیشن برایِ هر نماد · کارمزد ۰.۰۵٪
اجرا: python run_angelina.py --symbols BTC,ETH,SOL,XRP,ADA,DOGE,SUI --years 6
"""
import os, sys, json, time, hashlib, argparse
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fr as FR, fr7 as F7, run8 as R8


def lock():
    c = json.load(open(os.path.join(HERE, "angelina.json"), encoding="utf-8"))
    if hashlib.sha256(json.dumps(c, sort_keys=True).encode()).hexdigest() != open(os.path.join(HERE, "angelina.sha256")).read().strip():
        raise SystemExit("❌ angelina.json تغییر کرده — استراتژیِ قفل‌شده نیست.")
    return c


def streaks(u):
    """بیشترین رشته‌یِ باخت و برد: (تعداد، جمع $، اندیسِ شروع، اندیسِ پایان) + توزیعِ طولِ رشته‌هایِ باخت."""
    out = {}
    for name, cond in (("باخت", lambda v: v <= 0), ("برد", lambda v: v > 0)):
        best, c, s, i0, runs = (0, 0.0, None, None), 0, 0.0, 0, []
        for i, v in enumerate(u):
            if cond(v):
                if c == 0:
                    i0, s = i, 0.0
                c += 1; s += v
                if c > best[0]:
                    best = (c, s, i0, i)
            else:
                if c:
                    runs.append(c)
                c = 0
        if c:
            runs.append(c)
        out[name] = (best, pd.Series(runs, dtype=int).value_counts().sort_index().to_dict())
    return out


def main():
    L = lock()
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbols", default="BTC,ETH,SOL,XRP,ADA,DOGE,SUI"); ap.add_argument("--years", type=float, default=6)
    ap.add_argument("--cache", default="/content/fr_cache"); ap.add_argument("--out", default="/content/angelina_results"); ap.add_argument("--end", default=None)
    a = ap.parse_args()
    R8.CFG.update(capital=L["capital"], margin=L["margin"], lev=L["lev"], fee_pct=L["fee_pct"])
    os.makedirs(os.path.join(a.out, "events"), exist_ok=True)
    end = int(pd.Timestamp(a.end, tz="UTC").value // 10**6) if a.end else int(time.time() * 1000) // 3_600_000 * 3_600_000
    start = end - int(a.years * 365.25 * 86_400_000)
    import ccxt
    ex = ccxt.okx({"enableRateLimit": True})
    parts, cover = [], []
    for sym in [s.strip().upper() for s in a.symbols.split(",") if s.strip()]:
        p = os.path.join(a.out, "events", f"{sym}.csv.gz")
        if not os.path.exists(p):
            print(f"  داده‌یِ {sym} ...", flush=True)
            d5 = FR.fetch(ex, sym, "5m", start - 5 * 86_400_000, end, a.cache)
            d4 = FR.fetch(ex, sym, "4h", start - 120 * 86_400_000, end, a.cache)
            if len(d5) < 5000 or len(d4) < 300:
                print(f"  {sym}: داده‌یِ کافی نیست", flush=True); continue
            F5, F4 = FR.Frame(d5, "5m"), FR.Frame(d4, "4h")
            ev = pd.DataFrame(F7.events7(F4, F5, {}, L["pivot"], R8.CFG, sym, L["wave_method"], ["direct"], ["single"], ["sl1"], gap=L["gap"]))
            ev = ev[ev["تأییدِ موج"] >= start] if len(ev) else ev
            ev.to_csv(p, index=False, compression="gzip")
            cover.append(f"- {sym}: 5m از {pd.Timestamp(int(d5['t'].iloc[0]), unit='ms').date()} · {int((ev.get('وضعیت', pd.Series(dtype=str)) == 'ورود').sum())} ستاپِ واردشده")
            print(cover[-1], flush=True)
        if os.path.getsize(p) > 50:
            x = pd.read_csv(p)
            if len(x):
                parts.append(x)
    report(pd.concat(parts, ignore_index=True), L, a.out, start, end, cover)


def report(E, L, out, start, end, cover=()):
    d = E[(E["وضعیت"] == "ورود") & E["$ single"].notna()].copy()
    d["خروج_ms"] = d["زمانِ ورود"] + (d["مدت single"] * 3.6e6).astype("int64")
    d = d.sort_values("زمانِ ورود").reset_index(drop=True)
    tk, C, mx = R8.portfolio(d, L["capital"], L["margin"])
    t = d[tk].sort_values("خروج_ms").reset_index(drop=True)
    u = t["$ single"].to_numpy()
    cap = L["capital"]
    eq = cap + np.cumsum(u); pk = np.maximum.accumulate(np.r_[cap, eq])[1:]
    i = int(np.argmin(eq - pk)) if len(eq) else 0
    w, l = u[u > 0].sum(), -u[u <= 0].sum()
    st = streaks(u)
    dt = lambda k: pd.to_datetime(t.loc[k, "خروج_ms"], unit="ms").date() if k is not None else "-"
    (ln, ls, la, lb), lruns = st["باخت"]; (wn, ws, wa, wb), _ = st["برد"]
    t["سال"] = pd.to_datetime(t["خروج_ms"], unit="ms").dt.year; t["ماه"] = pd.to_datetime(t["خروج_ms"], unit="ms").dt.to_period("M")
    Y = t.groupby("سال")["$ single"].agg(["size", "sum", lambda x: int((x > 0).sum())]).rename(columns={"size": "معاملات", "sum": "سود $", "<lambda_0>": "برد"}).round(1)
    M = t.groupby("ماه")["$ single"].sum().reindex(pd.period_range(pd.Timestamp(start, unit="ms").to_period("M"), pd.Timestamp(end, unit="ms").to_period("M"), freq="M"), fill_value=0)
    S = t.groupby("نماد")["$ single"].agg(["size", "sum", lambda x: round(100 * (x > 0).mean(), 1)]).rename(columns={"size": "معاملات", "sum": "سود $", "<lambda_0>": "برد٪"}).round(1).sort_values("سود $", ascending=False)
    yend = pd.Series(eq, index=t["سال"]).groupby(level=0).last().round(0)
    ts = lambda ms: pd.Timestamp(int(ms), unit="ms").strftime("%Y-%m-%d")
    txt = [f"# Angelina — {ts(start)} تا {ts(end)} · {E['نماد'].nunique()} نماد · ${cap:g} · ${L['margin']:g} × {L['lev']:g}", "",
           "فیبو 4h · پیووت ۲۰ · روشِ B · ورود ۰.۶۱۸ (5m، شکاف ← بازار) · TP سطحِ ۰ +۱٪ · SL سطحِ ۱ · بدونِ فیلتر · لانگ و شورت", "", *cover, "",
           "## نتیجه",
           f"- **معاملات: {len(u)}** (برد {int((u > 0).sum())} · باخت {int((u <= 0).sum())} · برد٪ {100 * (u > 0).mean():.1f}) · لانگ {int((t['جهت'] == 'لانگ').sum())} · شورت {int((t['جهت'] == 'شورت').sum())}",
           f"- **سرمایه: ${cap:g} → ${eq[-1]:,.0f}** (خالص ${u.sum():+,.0f}) · PF {w / l:.2f} · میانگینِ هر معامله ${u.mean():+.2f} (برد ${u[u > 0].mean():+.2f} · باخت ${u[u <= 0].mean():+.2f})",
           f"- **بیشترین افت (Drawdown): ${(eq - pk).min():,.0f}** — از ${pk[i]:,.0f} به ${eq[i]:,.0f} (تا {dt(i)}) · کمترین سرمایه ${eq.min():,.0f}",
           f"- **بیشترین ضررِ متوالی: {ln} معامله** (${ls:+,.0f}، {dt(la)} تا {dt(lb)})",
           f"- **بیشترین سودِ متوالی: {wn} معامله** (${ws:+,.0f}، {dt(wa)} تا {dt(wb)})",
           f"- رشته‌هایِ باخت (طول: تعداد): {lruns}",
           f"- حداکثر پوزیشنِ هم‌زمان: {mx} · معامله در ماه: {len(u) / max(1, len(M)):.1f} · میانگینِ ماهانه ${M.mean():+.1f} · ماهِ مثبت/منفی {int((M > 0).sum())}/{int((M < 0).sum())}", "",
           "## سالانه", Y.assign(**{"سرمایه‌یِ پایانِ سال $": yend}).to_string(), "", "## به تفکیکِ نماد", S.to_string(), "",
           "## ماهانه ($)", " ".join(f"{str(k)[2:]}:{v:+.0f}" for k, v in M.items())]
    open(os.path.join(out, "angelina_report.md"), "w", encoding="utf-8").write("\n".join(txt))
    t.assign(**{"زمانِ ورود": pd.to_datetime(t["زمانِ ورود"], unit="ms")})[["نماد", "جهت", "زمانِ ورود", "ورود", "SL٪", "خروج single", "$ single"]].to_csv(
        os.path.join(out, "angelina_trades.csv"), index=False, encoding="utf-8-sig")
    print("\n".join(txt))


if __name__ == "__main__":
    main()
