"""
لایه‌ی ارتباط با Binance Futures (USDT-M) از طریق ccxt.
تمام داده‌ها لحظه‌ای (زنده) از API گرفته می‌شوند - هیچ داده‌ی آرشیوی/کش‌شده استفاده نمی‌شود.
"""

from __future__ import annotations
import time
import logging
from typing import List, Optional

import ccxt
import pandas as pd

from config import BINANCE_MARKET_TYPE

logger = logging.getLogger("binance_client")


class BinanceClient:
    """یک نمونه از این کلاس معادل یک حساب بایننس (اکانت اصلی یا هرکدام از حساب‌های کوپی) است."""

    def __init__(self, api_key: str, api_secret: str, name: str = "account", testnet: bool = False):
        self.name = name
        self.exchange = ccxt.binanceusdm({
            "apiKey": api_key,
            "secret": api_secret,
            "enableRateLimit": True,
            "options": {"defaultType": BINANCE_MARKET_TYPE},
        })
        if testnet:
            self.exchange.set_sandbox_mode(True)

    # ------------------------------------------------------------------
    # داده‌های بازار (فقط‌خواندنی - نیازی به API Key ندارد ولی از همین کلاینت استفاده می‌شود)
    # ------------------------------------------------------------------
    def fetch_ohlcv_full(self, symbol: str, timeframe: str, since_ms: Optional[int] = None,
                          limit_per_call: int = 1000, max_candles: int = 5000) -> pd.DataFrame:
        """
        دریافت کندل‌های زنده با صفحه‌بندی (برای گرفتن مثلاً ۶ ماه داده‌ی ۴ساعته که از سقف
        یک درخواست بیشتر است). هیچ فایل محلی/آرشیوی خوانده نمی‌شود.
        """
        all_rows: List[list] = []
        fetch_since = since_ms
        while True:
            batch = self.exchange.fetch_ohlcv(symbol, timeframe=timeframe, since=fetch_since,
                                                limit=limit_per_call)
            if not batch:
                break
            all_rows.extend(batch)
            if len(batch) < limit_per_call or len(all_rows) >= max_candles:
                break
            fetch_since = batch[-1][0] + 1
            time.sleep(self.exchange.rateLimit / 1000)

        df = pd.DataFrame(all_rows, columns=["timestamp", "open", "high", "low", "close", "volume"])
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
        df = df.drop_duplicates(subset="timestamp").sort_values("timestamp").reset_index(drop=True)
        return df

    def fetch_ohlcv_recent(self, symbol: str, timeframe: str, limit: int = 300) -> pd.DataFrame:
        batch = self.exchange.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
        df = pd.DataFrame(batch, columns=["timestamp", "open", "high", "low", "close", "volume"])
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
        return df

    # ------------------------------------------------------------------
    # حساب / موجودی
    # ------------------------------------------------------------------
    def fetch_usdt_balance(self) -> float:
        balance = self.exchange.fetch_balance()
        return float(balance.get("USDT", {}).get("free", 0) or 0)

    def set_leverage(self, symbol: str, leverage: int):
        try:
            self.exchange.set_leverage(leverage, symbol)
        except Exception as e:
            logger.warning(f"[{self.name}] set_leverage failed for {symbol}: {e}")

    # ------------------------------------------------------------------
    # سفارش‌گذاری
    # ------------------------------------------------------------------
    def place_market_order(self, symbol: str, side: str, quantity: float, reduce_only: bool = False):
        """side: 'buy' یا 'sell'"""
        return self.exchange.create_order(
            symbol=symbol, type="market", side=side, amount=quantity,
            params={"reduceOnly": reduce_only},
        )

    def place_stop_loss(self, symbol: str, side: str, quantity: float, stop_price: float):
        """side باید مخالف جهت پوزیشن باشد (برای بستن آن)."""
        return self.exchange.create_order(
            symbol=symbol, type="STOP_MARKET", side=side, amount=quantity,
            params={"stopPrice": stop_price, "reduceOnly": True},
        )

    def place_take_profit(self, symbol: str, side: str, quantity: float, stop_price: float):
        return self.exchange.create_order(
            symbol=symbol, type="TAKE_PROFIT_MARKET", side=side, amount=quantity,
            params={"stopPrice": stop_price, "reduceOnly": True},
        )
