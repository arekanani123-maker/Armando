"""
استراتژی جدید و مستقل: تقاطع میانگین متحرک (MA5 / MA20) روی تایم‌فریم ۱۵ دقیقه.

قوانین اصلی (بدون هیچ قانون یا فیلتر اضافه):
  - MA5 از پایین به بالای MA20 عبور کند -> سیگنال لانگ
  - MA5 از بالا به پایین MA20 عبور کند -> سیگنال شورت

فیلتر اختیاری ADX: اگر فعال باشد، سیگنال فقط زمانی معتبر است که ADX بالاتر از یک
آستانه باشد (یعنی بازار روند دارد، نه رنج/چاپی). این فیلتر جداگانه و اختیاری است -
منطق تقاطع خام دست‌نخورده می‌ماند.

این ماژول کاملاً مستقل از استراتژی چندتایم‌فریمی قبلی (structure/trend/breakout) است.
"""

from __future__ import annotations
from typing import Optional

import pandas as pd

from core.indicators import compute_adx

MA_FAST_PERIOD = 5
MA_SLOW_PERIOD = 20
ADX_PERIOD = 14
ADX_THRESHOLD = 20.0


def compute_ma_cross_signal(df: pd.DataFrame, fast: int = MA_FAST_PERIOD,
                             slow: int = MA_SLOW_PERIOD) -> Optional[str]:
    """
    df باید شامل کندل‌های *بسته‌شده* باشد (آخرین ردیف = آخرین کندل بسته‌شده).
    فقط تقاطعی که دقیقاً روی همین آخرین کندل رخ داده تشخیص داده می‌شود (نه تقاطع‌های قدیمی‌تر).

    خروجی: "long" | "short" | None
    """
    if len(df) < slow + 1:
        return None

    ma_fast = df["close"].rolling(fast).mean()
    ma_slow = df["close"].rolling(slow).mean()

    prev_diff = ma_fast.iloc[-2] - ma_slow.iloc[-2]
    curr_diff = ma_fast.iloc[-1] - ma_slow.iloc[-1]

    if pd.isna(prev_diff) or pd.isna(curr_diff):
        return None

    if prev_diff <= 0 and curr_diff > 0:
        return "long"
    if prev_diff >= 0 and curr_diff < 0:
        return "short"
    return None


def passes_adx_filter(df: pd.DataFrame, period: int = ADX_PERIOD,
                       threshold: float = ADX_THRESHOLD,
                       max_threshold: Optional[float] = None) -> bool:
    """
    True یعنی روی آخرین کندل بسته‌شده‌ی df، ADX بین threshold (کف) و max_threshold
    (سقف، اختیاری) است. کف: بازار باید حداقل کمی روند داشته باشد (نه کاملاً رنج).
    سقف (اگر داده شود): بازار نباید *بیش‌ازحد* روند داشته باشد - چون بررسی داده نشان
    داد وقتی ADX خیلی بالاست (مثلاً بالای ۴۰)، یعنی حرکت بزرگ احتمالاً از قبل رخ داده
    و تقاطع MA این‌جا دیرهنگام و کم‌بازده است.
    اگر داده برای محاسبه‌ی پایدار ADX کافی نباشد (NaN)، محافظه‌کارانه False برمی‌گردد.
    """
    if len(df) < period * 3:  # برای این‌که هموارسازی وایلدر جا بیفتد
        return False
    adx = compute_adx(df, period=period)
    last_adx = adx.iloc[-1]
    if pd.isna(last_adx):
        return False
    if last_adx <= threshold:
        return False
    if max_threshold is not None and last_adx > max_threshold:
        return False
    return True


def last_adx_value(df: pd.DataFrame, period: int = ADX_PERIOD) -> Optional[float]:
    """مقدار خام ADX روی آخرین کندل بسته‌شده - برای ثبت تشخیصی در گزارش معاملات
    (نه برای فیلتر کردن، فقط برای تحلیل بعدی که آیا ورودهای بازنده ADX ضعیف‌تری داشته‌اند)."""
    if len(df) < period * 3:
        return None
    adx = compute_adx(df, period=period)
    last_adx = adx.iloc[-1]
    return None if pd.isna(last_adx) else float(last_adx)


MA200_PERIOD = 200


def passes_ma200_filter(df: pd.DataFrame, signal: str, period: int = MA200_PERIOD) -> bool:
    """
    فیلتر جهت روند بر اساس MA200: سیگنال لانگ فقط وقتی معتبر است که آخرین قیمت بسته‌شده
    بالای MA200 باشد؛ سیگنال شورت فقط وقتی معتبر است که پایین‌تر از MA200 باشد. این
    دقیقاً همان فیلتر جهتی است که در لایه‌ی ۴ساعته‌ی استراتژی اسپایک استفاده می‌شود،
    اینجا به‌عنوان یک فیلتر اختیاری و مستقل برای تقاطع MA اضافه شده - منطق خام تقاطع
    (MA5/MA20) دست‌نخورده می‌ماند.

    اگر داده برای MA200 کافی نباشد، محافظه‌کارانه False برمی‌گردد (سیگنال رد می‌شود).
    """
    if len(df) < period + 1:
        return False
    ma200 = df["close"].rolling(period).mean().iloc[-1]
    if pd.isna(ma200):
        return False
    last_close = df["close"].iloc[-1]
    if signal == "long":
        return last_close > ma200
    else:
        return last_close < ma200
