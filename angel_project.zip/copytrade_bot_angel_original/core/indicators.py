"""
محاسبه‌ی ADX (Average Directional Index) با هموارسازی وایلدر - برای فیلتر کردن
بازار رنج/چاپی از بازار روند‌دار. مقدار بالاتر از threshold یعنی بازار روند دارد؛
پایین‌تر یعنی رنج است.
"""

from __future__ import annotations
import numpy as np
import pandas as pd


def compute_adx(df: pd.DataFrame, period: int = 14) -> pd.Series:
    """
    ورودی: DataFrame با ستون‌های high/low/close.
    خروجی: سری ADX هم‌طول با df (چند ردیف اول NaN است تا هموارسازی وایلدر جا بیفتد).
    """
    high, low, close = df["high"], df["low"], df["close"]
    prev_high, prev_low, prev_close = high.shift(1), low.shift(1), close.shift(1)

    tr = pd.concat([
        high - low,
        (high - prev_close).abs(),
        (low - prev_close).abs(),
    ], axis=1).max(axis=1)

    up_move = high - prev_high
    down_move = prev_low - low

    plus_dm = pd.Series(0.0, index=df.index)
    minus_dm = pd.Series(0.0, index=df.index)
    plus_mask = (up_move > down_move) & (up_move > 0)
    minus_mask = (down_move > up_move) & (down_move > 0)
    plus_dm[plus_mask] = up_move[plus_mask]
    minus_dm[minus_mask] = down_move[minus_mask]

    atr = tr.ewm(alpha=1 / period, adjust=False).mean()
    atr_safe = atr.replace(0, np.nan)

    plus_di = 100 * (plus_dm.ewm(alpha=1 / period, adjust=False).mean() / atr_safe)
    minus_di = 100 * (minus_dm.ewm(alpha=1 / period, adjust=False).mean() / atr_safe)

    di_sum = (plus_di + minus_di).replace(0, np.nan)
    dx = 100 * (plus_di - minus_di).abs() / di_sum
    adx = dx.ewm(alpha=1 / period, adjust=False).mean()

    return adx


def compute_rsi(df: pd.DataFrame, period: int = 14) -> pd.Series:
    """
    RSI با هموارسازی وایلدر (استاندارد). ورودی: DataFrame با ستون close.
    خروجی: سری RSI هم‌طول با df (چند ردیف اول NaN تا هموارسازی جا بیفتد).
    """
    delta = df["close"].diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)

    avg_gain = gain.ewm(alpha=1 / period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1 / period, adjust=False).mean()

    rs = avg_gain / avg_loss.replace(0, np.nan)
    rsi = 100 - (100 / (1 + rs))
    rsi = rsi.where(avg_loss != 0, 100.0)  # اگر هیچ ضرری نبوده، RSI=100
    return rsi
