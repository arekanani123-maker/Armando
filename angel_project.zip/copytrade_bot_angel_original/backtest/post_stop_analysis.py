"""
قانون تحلیل بعد از Stop - ماژول مشترک بین همه‌ی موتورهای بک‌تست (تقاطع MA، اسپایک، و
هر موتور آینده). برای هر معامله‌ای که با حدضرر بسته شده، رفتار قیمت *بعد* از لحظه‌ی
استاپ را بررسی می‌کند تا مشخص شود آیا SL بیش‌ازحد تنگ بوده - یعنی قیمت بعداً واقعاً
به سمت هدف اصلی رفته یا نه. این تحلیل معامله‌ی واقعی را تغییر نمی‌دهد، فقط گزارش
تشخیصی اضافه می‌کند.

قانون (برای LONG و SHORT به‌طور قرینه):
  - بعد از Stop، بیشترین High (لانگ) / کمترین Low (شورت) تا افق‌های ۶، ۱۲، ۲۴، ۴۸، ۷۲
    ساعت بعد بررسی می‌شود؛ درصد حرکت نسبت به قیمت ورود محاسبه می‌شود.
  - محاسبه می‌شود آیا نهایتاً (در بازه‌ی حداکثر افق) به سطوح 1R/2R/3R/5R/10R رسیده یا
    نه، و زمان دقیق رسیدن به هر سطح ثبت می‌شود.

از کندل‌های همان تایم‌فریمی که بک‌تست اصلی با آن اجرا شده استفاده می‌کند - نیازی به
دریافت داده‌ی جدید یا درخواست اضافه به API نیست.
"""

from __future__ import annotations
from typing import Dict, List, Optional

import pandas as pd

POST_STOP_HORIZONS_HOURS = (6, 12, 24, 48, 72)
POST_STOP_R_LEVELS = (1, 2, 3, 5, 10)


def analyze_post_stop_moves(symbol_data: Dict[str, dict], stopped_trades: List[dict],
                             timeframe_minutes: int = 15,
                             horizons_hours=POST_STOP_HORIZONS_HOURS,
                             r_levels=POST_STOP_R_LEVELS) -> List[dict]:
    """
    symbol_data: دیکشنری symbol -> {"df15": DataFrame کندل‌ها (ستون timestamp دارد),
                                     "ts_to_pos": {timestamp: موقعیت عددی در df},
                                     "tf_minutes": (اختیاری) طول کندل این نماد به دقیقه}
    stopped_trades: لیستی از دیکشنری‌ها، هرکدام با کلیدهای:
                     symbol, side ("long"|"short"), entry_price, sl_price, stop_time (pd.Timestamp)
    timeframe_minutes: طول پیش‌فرض هر کندل به دقیقه - اگر symbol_data[symbol] کلید
                       "tf_minutes" داشته باشد (برای پشتیبانی از تایم‌فریم مجزا به‌ازای
                       هر نماد در یک اجرای مشترک)، همان مقدار به‌جای این پیش‌فرض استفاده می‌شود.
    """
    max_horizon_h = max(horizons_hours)
    rows: List[dict] = []

    for st in stopped_trades:
        data = symbol_data.get(st["symbol"])
        if data is None:
            continue
        df = data["df15"] if "df15" in data else data.get("df")
        ts_to_pos = data["ts_to_pos"]
        sym_tf_minutes = data.get("tf_minutes", timeframe_minutes)
        candles_per_hour = 60 / sym_tf_minutes
        stop_pos = ts_to_pos.get(st["stop_time"])
        if stop_pos is None or stop_pos + 1 >= len(df):
            continue

        entry_price = st["entry_price"]
        sl_price = st["sl_price"]
        side = st["side"]
        r_distance = abs(entry_price - sl_price)
        if r_distance <= 0:
            continue

        row = {
            "symbol": st["symbol"], "side": side,
            "entry_time": st.get("entry_time").isoformat() if st.get("entry_time") is not None else None,
            "entry_price": round(entry_price, 6), "sl_price": round(sl_price, 6),
            "stop_time": st["stop_time"].isoformat(), "r_distance": round(r_distance, 6),
        }

        for h in horizons_hours:
            end_pos = min(stop_pos + int(h * candles_per_hour), len(df) - 1)
            window = df.iloc[stop_pos + 1: end_pos + 1]
            if window.empty:
                row[f"extreme_price_{h}h"] = None
                row[f"pct_move_from_entry_{h}h"] = None
                continue
            if side == "long":
                extreme = float(window["high"].max())
                pct_move = (extreme - entry_price) / entry_price * 100
            else:
                extreme = float(window["low"].min())
                pct_move = (entry_price - extreme) / entry_price * 100
            row[f"extreme_price_{h}h"] = round(extreme, 6)
            row[f"pct_move_from_entry_{h}h"] = round(pct_move, 3)

        max_end_pos = min(stop_pos + int(max_horizon_h * candles_per_hour), len(df) - 1)
        full_window = df.iloc[stop_pos + 1: max_end_pos + 1]
        for r in r_levels:
            target_price = entry_price + r_distance * r if side == "long" else entry_price - r_distance * r
            if side == "long":
                hit_positions = full_window.index[full_window["high"] >= target_price]
            else:
                hit_positions = full_window.index[full_window["low"] <= target_price]

            if len(hit_positions) > 0:
                first_pos = hit_positions[0]
                hit_time = df["timestamp"].iloc[first_pos]
                time_to_reach_h = (hit_time - st["stop_time"]).total_seconds() / 3600
                row[f"reached_{r}R"] = True
                row[f"time_to_{r}R_hours"] = round(time_to_reach_h, 2)
            else:
                row[f"reached_{r}R"] = False
                row[f"time_to_{r}R_hours"] = None

        rows.append(row)

    return rows


def post_stop_summary(rows: List[dict], r_levels=POST_STOP_R_LEVELS) -> dict:
    """درصد معاملاتی که بعد از استاپ نهایتاً به هر سطح R رسیده‌اند + میانه‌ی زمان رسیدن."""
    if not rows:
        return {"stopped_trades_analyzed": 0}
    summary = {"stopped_trades_analyzed": len(rows)}
    for r in r_levels:
        reached_count = sum(1 for row in rows if row.get(f"reached_{r}R"))
        summary[f"reached_{r}R_pct"] = round(reached_count / len(rows) * 100, 2)
        times = [row[f"time_to_{r}R_hours"] for row in rows if row.get(f"time_to_{r}R_hours") is not None]
        summary[f"reached_{r}R_median_hours"] = round(pd.Series(times).median(), 2) if times else None
    return summary
