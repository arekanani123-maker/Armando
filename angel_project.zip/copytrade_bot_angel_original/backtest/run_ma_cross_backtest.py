"""
اجرای بک‌تست استراتژی تقاطع MA5/MA20 (مستقل از استراتژی چندتایم‌فریمی اصلی).
با --timeframe می‌توان روی هر تایم‌فریمی (15m، 1h، ...) با شرایط کاملاً یکسان اجرا
کرد تا بازدهی تایم‌فریم‌های مختلف قابل مقایسه باشد.

مثال اجرا (۱۵ دقیقه، طبق آخرین تنظیمات):
    python -m backtest.run_ma_cross_backtest \
        --symbols ETH/USDT --timeframe 15m \
        --start 2026-02-28 --end 2026-08-28 \
        --balance 10000 --margin-per-trade 300 --leverage 6

مثال اجرا (همان استراتژی، تایم‌فریم ۱ ساعته - برای مقایسه):
    python -m backtest.run_ma_cross_backtest \
        --symbols ETH/USDT --timeframe 1h \
        --start 2026-02-28 --end 2026-08-28 \
        --balance 10000 --margin-per-trade 300 --leverage 6

خروجی هر تایم‌فریم در پوشه‌ی جدای backtest/reports/ma_cross/<timeframe>/ ذخیره می‌شود
تا نتایج ۱۵دقیقه و ۱ساعته همدیگر را پاک نکنند و بشود کنار هم مقایسه کرد.
"""

from __future__ import annotations
import argparse
import json
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import config
from core.binance_client import BinanceClient
from backtest.ma_cross_engine import run_ma_cross_backtest

REPORTS_BASE_DIR = os.path.join(os.path.dirname(__file__), "reports", "ma_cross")


def main():
    parser = argparse.ArgumentParser(description="بک‌تست استراتژی تقاطع MA5/MA20")
    parser.add_argument("--symbols", type=str, default="ETH/USDT")
    parser.add_argument("--timeframe", type=str, default="15m",
                         help="تایم‌فریم کندل‌ها، مثل 15m یا 1h - برای مقایسه‌ی بازدهی روی تایم‌فریم‌های مختلف")
    parser.add_argument("--start", type=str, required=True)
    parser.add_argument("--end", type=str, required=True)
    parser.add_argument("--balance", type=float, default=10000.0)
    parser.add_argument("--margin-per-trade", type=float, default=300.0)
    parser.add_argument("--leverage", type=int, default=6)
    parser.add_argument("--sl-pct", type=float, default=3.0)
    parser.add_argument("--tp1-pct", type=float, default=3.0)
    parser.add_argument("--tp1-close-fraction", type=float, default=0.5)
    parser.add_argument("--tp2-pct", type=float, default=6.0,
                         help="درصد TP2 مستقیماً نسبت به قیمت ورود (نه نسبت به TP1)")
    parser.add_argument("--ma-fast", type=int, default=5)
    parser.add_argument("--ma-slow", type=int, default=20)
    parser.add_argument("--use-adx-filter", type=str, default="true",
                         choices=["true", "false"], help="فعال/غیرفعال کردن فیلتر ADX")
    parser.add_argument("--adx-period", type=int, default=14)
    parser.add_argument("--adx-threshold", type=float, default=20.0,
                         help="سیگنال فقط وقتی معتبر است که ADX از این مقدار بیشتر باشد (بازار روند‌دار)")
    args = parser.parse_args()
    use_adx_filter = args.use_adx_filter == "true"

    # هر تایم‌فریم توی پوشه‌ی جدا ذخیره می‌شود تا نتایج ۱۵دقیقه و ۱ساعته همدیگر را
    # پاک نکنند و بشود کنار هم مقایسه‌شان کرد
    safe_tf = args.timeframe.replace("/", "-")
    REPORTS_DIR = os.path.join(REPORTS_BASE_DIR, safe_tf)

    symbols = [s.strip() for s in args.symbols.split(",") if s.strip()]
    client = BinanceClient(api_key="", api_secret="", name="backtest")

    print(f"در حال بک‌تست MA{args.ma_fast}/MA{args.ma_slow} روی {symbols} "
          f"(تایم‌فریم: {args.timeframe}) از {args.start} تا {args.end} (سرمایه: {args.balance}, "
          f"مارجین/ورود: {args.margin_per_trade}, لوریج: {args.leverage}x, فیلتر ADX: "
          f"{'فعال (>' + str(args.adx_threshold) + ')' if use_adx_filter else 'غیرفعال'}) ...")

    try:
        result = run_ma_cross_backtest(
            client, symbols, args.start, args.end,
            initial_balance=args.balance, margin_per_trade=args.margin_per_trade,
            leverage=args.leverage, sl_pct=args.sl_pct, tp1_pct=args.tp1_pct,
            tp1_close_fraction=args.tp1_close_fraction, tp2_pct=args.tp2_pct,
            ma_fast=args.ma_fast, ma_slow=args.ma_slow,
            use_adx_filter=use_adx_filter, adx_period=args.adx_period, adx_threshold=args.adx_threshold,
            timeframe=args.timeframe,
        )
    except Exception as e:
        print(f"خطا: {e}")
        return

    os.makedirs(REPORTS_DIR, exist_ok=True)

    per_symbol_summaries = []
    for symbol in result.symbols:
        safe_symbol = symbol.replace("/", "-")
        trades = result.trades_for(symbol)
        path = os.path.join(REPORTS_DIR, f"ma_trades_{safe_symbol}.csv")
        if trades:
            pd.DataFrame([t.to_dict() for t in trades]).to_csv(path, index=False, encoding="utf-8-sig")
        else:
            pd.DataFrame(columns=["symbol", "side", "entry_time"]).to_csv(path, index=False)
        per_symbol_summaries.append(result.symbol_summary(symbol))

    # ---- تحلیل بعد از استاپ (قانون تحلیل بعد از Stop) ----
    post_stop_df = result.post_stop_analysis_df()
    post_stop_path = os.path.join(REPORTS_DIR, "ma_post_stop_analysis.csv")
    if not post_stop_df.empty:
        post_stop_df.to_csv(post_stop_path, index=False, encoding="utf-8-sig")
    else:
        pd.DataFrame(columns=["symbol", "side", "entry_time"]).to_csv(post_stop_path, index=False)
    post_stop_summary = result.post_stop_summary()

    # نمودار equity پرتفوی
    chart_path = os.path.join(REPORTS_DIR, "ma_equity_portfolio.png")
    times = [t for t, _ in result.equity_curve]
    equities = [e for _, e in result.equity_curve]
    plt.figure(figsize=(10, 5))
    plt.plot(times, equities, color="#60a5fa", linewidth=1.8)
    plt.axhline(args.balance, color="#6b7280", linestyle="--", linewidth=1)
    plt.title(f"MA{args.ma_fast}/MA{args.ma_slow} Cross ({args.timeframe}) - Portfolio Equity ({', '.join(result.symbols)})")
    plt.xlabel("زمان")
    plt.ylabel("موجودی (USDT)")
    plt.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(chart_path, dpi=130)
    plt.close()

    equity_path = os.path.join(REPORTS_DIR, "ma_portfolio_equity.csv")
    pd.DataFrame(result.equity_curve, columns=["time", "realized_equity"]).to_csv(
        equity_path, index=False, encoding="utf-8-sig")

    portfolio_summary = result.portfolio_summary()
    json_payload = {
        "portfolio": {
            **portfolio_summary,
            "strategy": f"MA{args.ma_fast}/MA{args.ma_slow} crossover",
            "timeframe": args.timeframe,
            "margin_per_trade": args.margin_per_trade,
            "leverage": args.leverage,
            "sl_pct": args.sl_pct,
            "tp1_pct": args.tp1_pct,
            "tp1_close_fraction": args.tp1_close_fraction,
            "tp2_pct": args.tp2_pct,
            "use_adx_filter": use_adx_filter,
            "adx_period": args.adx_period if use_adx_filter else None,
            "adx_threshold": args.adx_threshold if use_adx_filter else None,
            "taker_fee_pct_per_side": config.TAKER_FEE_PCT,
            "funding_rate_pct_per_8h": config.FUNDING_RATE_PCT_PER_8H,
        },
        "by_symbol": per_symbol_summaries,
        "open_positions_at_end": result.open_positions_at_end,
        "post_stop_analysis_summary": post_stop_summary,
    }
    json_path = os.path.join(REPORTS_DIR, "ma_portfolio_summary.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(json_payload, f, ensure_ascii=False, indent=2)

    md_lines = [
        f"# گزارش بک‌تست استراتژی تقاطع MA{args.ma_fast}/MA{args.ma_slow} — {', '.join(result.symbols)} "
        f"(تایم‌فریم {args.timeframe})",
        "",
        "## قوانین",
        "",
        f"- ورود لانگ: MA{args.ma_fast} از پایین به بالای MA{args.ma_slow} عبور کند",
        f"- ورود شورت: MA{args.ma_fast} از بالا به پایین MA{args.ma_slow} عبور کند",
        f"- SL: {args.sl_pct}% از قیمت ورود (خلاف جهت پوزیشن)",
        f"- TP1: {args.tp1_pct}% از قیمت ورود (هم‌جهت پوزیشن) -> بستن "
        f"{int(args.tp1_close_fraction*100)}% پوزیشن + انتقال SL به نقطه‌ی ورود",
        f"- TP2: {args.tp2_pct}% از قیمت ورود (نه نسبت به TP1) -> بستن باقیمانده",
        f"- تایم‌فریم: **{args.timeframe}**",
        (f"- **فیلتر ADX فعال**: سیگنال فقط وقتی معتبر است که ADX({args.adx_period}) > "
         f"{args.adx_threshold} باشد (رد کردن بازار رنج/چاپی)") if use_adx_filter
        else "- بدون فیلتر ADX (خام)",
        "",
        "## تنظیمات اجرا",
        "",
        f"- بازه: `{args.start}` تا `{args.end}` (UTC)",
        f"- سرمایه‌ی مشترک پرتفوی: `{args.balance:,.2f} USDT`",
        f"- مارجین هر ورود: `{args.margin_per_trade} USDT` | لوریج: `{args.leverage}x` | "
        f"ارزش اسمی: `{args.margin_per_trade*args.leverage:,.2f} USDT`",
        f"- کارمزد Taker: `{config.TAKER_FEE_PCT}%` هر طرف، فاندینگ تقریبی: `{config.FUNDING_RATE_PCT_PER_8H}%` هر ۸ساعت",
        "- مارجین آزاد واقعاً بین نمادها مشترک است "
        f"(رد شده به‌خاطر کمبود مارجین: {portfolio_summary['rejected_due_to_margin']})",
        "",
        "## نتیجه‌ی پرتفوی",
        "",
        "| معیار | مقدار |",
        "|---|---:|",
        f"| سرمایه‌ی اولیه | {portfolio_summary['initial_balance']:.2f} USDT |",
        f"| موجودی نهایی | {portfolio_summary['final_balance']:.2f} USDT |",
        f"| سود/زیان تحقق‌یافته | {portfolio_summary['realized_pnl']:.2f} USDT |",
        f"| بازده | {portfolio_summary['total_return_pct']:.2f}% |",
        f"| Max Drawdown | {portfolio_summary['max_drawdown_pct']:.2f}% |",
        f"| معاملات بسته‌شده | {portfolio_summary['total_closed_trades']} |",
        f"| پوزیشن باز در پایان | {portfolio_summary['open_positions_at_end']} |",
        "",
        "## تفکیک نمادها",
        "",
        "| نماد | معاملات | نرخ برد | Profit Factor | رسیده به TP1 | استاپ کامل | سود/زیان |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for s in per_symbol_summaries:
        md_lines.append(
            f"| {s['symbol']} | {s['total_trades']} | {s['win_rate_pct']}% | {s['profit_factor']} | "
            f"{s['reached_tp1_count']} | {s['full_stop_loss_count']} | {s['realized_pnl']:.2f} USDT |"
        )

    md_lines += [
        "",
        "## تحلیل بعد از Stop",
        "",
        "برای هر معامله‌ای که با حدضرر کامل بسته شده (قبل از رسیدن به TP1)، رفتار قیمت "
        "*بعد* از لحظه‌ی استاپ (تا ۷۲ ساعت بعد) بررسی شده تا مشخص شود آیا SL بیش‌ازحد تنگ بوده.",
        "",
        f"- تعداد معاملات استاپ‌خورده‌ی تحلیل‌شده: **{post_stop_summary.get('stopped_trades_analyzed', 0)}**",
        "",
    ]
    if post_stop_summary.get("stopped_trades_analyzed", 0) > 0:
        md_lines += [
            "| سطح R | درصد رسیدن (تا ۷۲ساعت بعد از استاپ) | میانه‌ی زمان رسیدن (ساعت) |",
            "|---|---:|---:|",
        ]
        for r in [1, 2, 3, 5, 10]:
            pct = post_stop_summary.get(f"reached_{r}R_pct")
            med = post_stop_summary.get(f"reached_{r}R_median_hours")
            md_lines.append(f"| {r}R | {pct}% | {med if med is not None else '—'} |")
        md_lines += [
            "",
            "> اگر درصد رسیدن به ۱R/۲R بالا باشد، نشانه‌ی این است که SL فعلی (۳٪ ثابت) بیش‌ازحد "
            "تنگ است و قیمت اغلب بعد از تکان‌خوردن نویزی به مسیر اصلی برمی‌گردد.",
            "- فایل کامل: `ma_post_stop_analysis.csv`",
        ]

    md_lines += [
        "",
        "## فایل‌های خروجی",
        "",
        "- `ma_portfolio_summary.json`, `ma_portfolio_equity.csv`, `ma_equity_portfolio.png`",
        "- `ma_trades_<SYMBOL>.csv` — هر ردیف یک معامله با جزئیات هر دو پله‌ی خروج (leg1/leg2)",
        "- `ma_post_stop_analysis.csv` — تحلیل بعد از استاپ (بالا)",
        "",
        "> این گزارش توصیه‌ی مالی نیست. قبل از اجرای واقعی، تست‌نت الزامی است.",
    ]
    md_path = os.path.join(REPORTS_DIR, "ma_backtest_report.md")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write("\n".join(md_lines))

    print(f"\nمعاملات بسته‌شده: {portfolio_summary['total_closed_trades']} | "
          f"بازده: {portfolio_summary['total_return_pct']}% | Max DD: {portfolio_summary['max_drawdown_pct']}%")
    for s in per_symbol_summaries:
        print(f"  {s['symbol']}: {s['total_trades']} معامله، برد {s['win_rate_pct']}%، "
              f"PF {s['profit_factor']}، سود/زیان {s['realized_pnl']} USDT")
    if post_stop_summary.get("stopped_trades_analyzed", 0) > 0:
        print(f"\nتحلیل بعد از استاپ ({post_stop_summary['stopped_trades_analyzed']} معامله):")
        for r in [1, 2, 3, 5, 10]:
            print(f"  رسیدن به {r}R تا ۷۲ساعت بعد: {post_stop_summary.get(f'reached_{r}R_pct')}%")
    print(f"\nگزارش‌ها در: {REPORTS_DIR}")


if __name__ == "__main__":
    main()
