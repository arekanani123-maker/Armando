"""
اجرای «انجل» = استراتژی ۲ (تقاطع MA) به‌صورت مستقل.

⚠️ استراتژی ۳ (اسپایک/شورت عمیق) طبق درخواست کاربر از انجل حذف شد. استراتژی ۳
دست‌نخورده و به‌طور کامل در backtest/spike_engine.py و backtest/run_spike_backtest.py
باقی مانده - اگر بخواهید جدا اجرایش کنید همچنان در دسترس است، فقط دیگر بخشی از
اجرای ترکیبی انجل نیست.

فعلاً فقط بک‌تست است (نه اجرای زنده روی حساب واقعی).

مثال اجرا:
    python -m backtest.run_angel_backtest \
        --symbols ETH/USDT --start 2026-02-28 --end 2026-08-28 \
        --balance 10000 --margin-per-trade 300 --leverage 6
"""

from __future__ import annotations
import argparse
import json
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import config
from core.binance_client import BinanceClient
from backtest.ma_cross_engine import run_ma_cross_backtest
# توجه: run_spike_backtest دیگر اینجا فراخوانی نمی‌شود (استراتژی ۳ از انجل حذف شد)،
# ولی خودش دست‌نخورده در backtest/spike_engine.py و backtest/run_spike_backtest.py باقی مانده.

ANGEL_REPORTS_DIR = os.path.join(os.path.dirname(__file__), "reports", "angel")
MA_REPORTS_BASE_DIR = os.path.join(os.path.dirname(__file__), "reports", "ma_cross")


def _save_ma_cross_reports(result, symbols, args, timeframe: str, symbol_timeframes: dict = None):
    """دقیقاً همان گزارش‌هایی که run_ma_cross_backtest.py می‌سازد - در همان پوشه‌ی همیشگی‌اش.
    اگر symbol_timeframes داده شود (تایم‌فریم مجزا به‌ازای بعضی نمادها)، پوشه‌ی خروجی
    "mixed" نام‌گذاری می‌شود و جدول تفکیک نمادها ستون تایم‌فریم هم دارد."""
    symbol_timeframes = symbol_timeframes or {}
    is_mixed = bool(symbol_timeframes)
    safe_tf = "mixed" if is_mixed else timeframe.replace("/", "-")
    out_dir = os.path.join(MA_REPORTS_BASE_DIR, safe_tf)
    os.makedirs(out_dir, exist_ok=True)

    per_symbol_summaries = []
    for symbol in result.symbols:
        safe_symbol = symbol.replace("/", "-")
        trades = result.trades_for(symbol)
        path = os.path.join(out_dir, f"ma_trades_{safe_symbol}.csv")
        if trades:
            pd.DataFrame([t.to_dict() for t in trades]).to_csv(path, index=False, encoding="utf-8-sig")
        else:
            pd.DataFrame(columns=["symbol", "side", "entry_time"]).to_csv(path, index=False)
        s = result.symbol_summary(symbol)
        s["timeframe"] = symbol_timeframes.get(symbol, timeframe)
        per_symbol_summaries.append(s)

    chart_path = os.path.join(out_dir, "ma_equity_portfolio.png")
    times = [t for t, _ in result.equity_curve]
    equities = [e for _, e in result.equity_curve]
    plt.figure(figsize=(10, 5))
    plt.plot(times, equities, color="#60a5fa", linewidth=1.8)
    plt.axhline(args.balance, color="#6b7280", linestyle="--", linewidth=1)
    title_tf = "مجزا به‌ازای هر نماد" if is_mixed else timeframe
    plt.title(f"MA5/MA20 Cross ({title_tf}) - Portfolio Equity ({', '.join(result.symbols)})")
    plt.xlabel("زمان")
    plt.ylabel("موجودی (USDT)")
    plt.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(chart_path, dpi=130)
    plt.close()

    equity_path = os.path.join(out_dir, "ma_portfolio_equity.csv")
    pd.DataFrame(result.equity_curve, columns=["time", "realized_equity"]).to_csv(
        equity_path, index=False, encoding="utf-8-sig")

    post_stop_df = result.post_stop_analysis_df()
    post_stop_path = os.path.join(out_dir, "ma_post_stop_analysis.csv")
    if not post_stop_df.empty:
        post_stop_df.to_csv(post_stop_path, index=False, encoding="utf-8-sig")
    else:
        pd.DataFrame(columns=["symbol", "side", "entry_time"]).to_csv(post_stop_path, index=False)
    post_stop_summary = result.post_stop_summary()

    portfolio_summary = result.portfolio_summary()
    ma_targets_str = getattr(args, "ma_targets", None)
    json_payload = {
        "code_version": config.BOT_CODE_VERSION,
        "portfolio": {
            **portfolio_summary, "strategy": "MA5/MA20 crossover",
            "timeframe": "mixed (به‌ازای هر نماد جدا - جدول by_symbol را ببینید)" if is_mixed else timeframe,
            "margin_per_trade": args.margin_per_trade, "leverage": args.leverage,
            "sl_pct": args.ma_sl_pct,
            "targets": ma_targets_str if ma_targets_str else
                       f"tp1={args.ma_tp1_pct}% (50%), tp2={args.ma_tp2_pct}% (50%)",
            "max_concurrent_positions_per_symbol": getattr(args, "max_concurrent_positions", 1),
            "require_same_direction_for_concurrent": getattr(args, "require_same_direction", "true"),
        },
        "by_symbol": per_symbol_summaries,
        "open_positions_at_end": result.open_positions_at_end,
        "post_stop_analysis_summary": post_stop_summary,
        "data_warnings": result.data_warnings,
    }
    with open(os.path.join(out_dir, "ma_portfolio_summary.json"), "w", encoding="utf-8") as f:
        json.dump(json_payload, f, ensure_ascii=False, indent=2)

    targets_desc = f"اهداف R-based سفارشی: `{ma_targets_str}`" if ma_targets_str else \
        f"TP1={args.ma_tp1_pct}% (۵۰٪) | TP2={args.ma_tp2_pct}% (۵۰٪)"
    tf_line = "تایم‌فریم: **مجزا به‌ازای هر نماد** (جدول زیر را ببینید)" if is_mixed \
        else f"تایم‌فریم: `{timeframe}`"
    md_lines = [
        f"# گزارش بک‌تست استراتژی تقاطع MA5/MA20 — {', '.join(result.symbols)} (اجرا از انجل)",
        "",
        f"> نسخه‌ی کد: `{config.BOT_CODE_VERSION}`",
        "",
        f"- {tf_line} | SL={args.ma_sl_pct}% (=۱R) | {targets_desc}",
        f"- فیلتر ADX: `{args.ma_use_adx_filter == 'true'}` (کف={args.ma_adx_threshold}"
        f"{', سقف=' + str(args.ma_adx_max_threshold) if getattr(args, 'ma_adx_max_threshold', None) else ''}) | "
        f"فیلتر MA200: `{getattr(args, 'ma_use_ma200_filter', 'false') == 'true'}`",
        f"- سرمایه: `{args.balance:,.2f} USDT` | مارجین/ورود: `{args.margin_per_trade}` | لوریج: `{args.leverage}x`",
        f"- حداکثر پوزیشن هم‌زمان هر نماد: `{getattr(args, 'max_concurrent_positions', 1)}` "
        f"(هم‌جهت الزامی: `{getattr(args, 'require_same_direction', 'true')}`)",
    ]
    if getattr(args, "exclude_entry_windows", None):
        md_lines += [
            f"- ⚠️ پنجره‌های ورود مستثنی‌شده: `{args.exclude_entry_windows}`",
            "",
            "> **هشدار overfitting:** این فیلتر بر اساس ساعت/روزهایی انتخاب شده که در همین بازه‌ی "
            "زمانی باخت داده بودند. نتیجه‌ی این اجرا احتمالاً بهتر از واقعیت به‌نظر می‌رسد چون مدل "
            "با اطلاع از باخت‌های همین بازه تنظیم شده - این فیلتر را روی یک بازه‌ی متفاوت (که ندیده) "
            "دوباره تست کنید تا معلوم شود این الگو واقعی است یا فقط نویز همین بازه.",
        ]
    md_lines += [
        "",
        "## نتیجه‌ی پرتفوی",
        "",
        "| معیار | مقدار |",
        "|---|---:|",
        f"| موجودی نهایی | {portfolio_summary['final_balance']:.2f} USDT |",
        f"| بازده | {portfolio_summary['total_return_pct']:.2f}% |",
        f"| Max Drawdown | {portfolio_summary['max_drawdown_pct']:.2f}% |",
        f"| معاملات بسته‌شده | {portfolio_summary['total_closed_trades']} |",
        "",
        "## تفکیک نمادها",
        "",
        "| نماد | تایم‌فریم | معاملات | نرخ برد | Profit Factor | سود/زیان |",
        "|---|---|---:|---:|---:|---:|",
    ]
    for s in per_symbol_summaries:
        md_lines.append(f"| {s['symbol']} | {s['timeframe']} | {s['total_trades']} | {s['win_rate_pct']}% | "
                         f"{s['profit_factor']} | {s['realized_pnl']:.2f} USDT |")

    if result.data_warnings:
        md_lines += ["", "## ⚠️ هشدار داده", ""]
        for w in result.data_warnings:
            md_lines.append(f"- {w}")

    if post_stop_summary.get("stopped_trades_analyzed", 0) > 0:
        md_lines += ["", "## تحلیل بعد از Stop", "",
                     f"معاملات استاپ‌خورده‌ی تحلیل‌شده: {post_stop_summary['stopped_trades_analyzed']}"]
        for r in [1, 2, 3, 5, 10]:
            md_lines.append(f"- رسیدن به {r}R تا ۷۲ساعت بعد: {post_stop_summary.get(f'reached_{r}R_pct')}%")
    with open(os.path.join(out_dir, "ma_backtest_report.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(md_lines))

    return out_dir


def main():
    parser = argparse.ArgumentParser(description="بک‌تست ترکیبی انجل (استراتژی ۲ + ۳، کاملاً جدا از هم)")
    parser.add_argument("--symbols", type=str, default="ETH/USDT")
    parser.add_argument("--start", type=str, required=True)
    parser.add_argument("--end", type=str, required=True)
    parser.add_argument("--balance", type=float, default=10000.0,
                         help="سرمایه‌ی اولیه - به هرکدام از دو استراتژی جدا و کامل داده می‌شود (مشترک نیست)")
    parser.add_argument("--margin-per-trade", type=float, default=300.0)
    parser.add_argument("--leverage", type=int, default=6)
    parser.add_argument("--ma-timeframe", type=str, default="15m")
    parser.add_argument("--ma-use-adx-filter", type=str, default="true", choices=["true", "false"])
    parser.add_argument("--ma-adx-symbols", type=str, default=None,
                         help="لیست نمادهایی که *فقط* برایشان فیلتر ADX اعمال می‌شود، با کاما جدا: "
                              "'ADA/USDT,DOGE/USDT' - اگر داده شود، ma-use-adx-filter دیگر عمومی نیست")
    parser.add_argument("--ma-adx-threshold", type=float, default=20.0)
    parser.add_argument("--ma-adx-max-threshold", type=float, default=None,
                         help="سقف بالایی اختیاری ADX - اگر داده شود، سیگنال‌هایی که ADX از این "
                              "مقدار بیشتر است هم رد می‌شوند (نه فقط زیر آستانه‌ی کف)")
    parser.add_argument("--ma-use-ma200-filter", type=str, default="false", choices=["true", "false"],
                         help="فیلتر جهت روند: لانگ فقط بالای MA200، شورت فقط زیر MA200 (همان تایم‌فریم ورودی)")
    parser.add_argument("--ma-tp1-pct", type=float, default=3.0)
    parser.add_argument("--ma-tp2-pct", type=float, default=6.0)
    parser.add_argument("--ma-sl-pct", type=float, default=3.0)
    parser.add_argument("--ma-targets", type=str, default=None,
                         help="لیست هدف‌های R-based به‌صورت 'R1:frac1,R2:frac2,...' مثلاً "
                              "'1:0.3,2:0.4,3:0.3' - اگر داده شود جایگزین tp1-pct/tp2-pct می‌شود")
    parser.add_argument("--ma-targets-by-symbol", type=str, default=None,
                         help="override تارگت برای نمادهای خاص: 'SYM=R1:f1,R2:f2;SYM2=R1:f1,...' مثلاً "
                              "'ADA/USDT=1:0.3,2:0.4,3:0.3' - نمادهایی که اینجا نیامده‌اند از "
                              "--ma-targets عمومی استفاده می‌کنند")
    parser.add_argument("--max-concurrent-positions", type=int, default=1,
                         help="حداکثر پوزیشن هم‌زمان روی یک نماد")
    parser.add_argument("--require-same-direction", type=str, default="true", choices=["true", "false"])
    parser.add_argument("--symbol-timeframes", type=str, default=None,
                         help="override تایم‌فریم برای نمادهای خاص: 'SYM:tf,SYM:tf,...' مثلاً "
                              "'BEAT/USDT:1h,SUI/USDT:1h' - نمادهایی که اینجا نیامده‌اند از "
                              "--ma-timeframe عمومی استفاده می‌کنند (اجرای مشترک با تایم‌فریم مجزا)")
    parser.add_argument("--exclude-entry-windows", type=str, default=None,
                         help="ورود جدید در این (روز هفته:ساعت UTC) ها ممنوع می‌شود. فرمت: "
                              "'day:hour,day:hour,...' با نام روز انگلیسی (monday..sunday) - مثلاً "
                              "'sunday:4,sunday:8,sunday:12'. ⚠️ ریسک overfitting دارد اگر بر اساس "
                              "همان بازه‌ای انتخاب شود که قرار است تست شود.")
    parser.add_argument("--close-open-positions-at-end", type=str, default="false", choices=["true", "false"],
                         help="اگر true باشد، در پایان بازه‌ی تست هر پوزیشن بازمانده با قیمت آخرین "
                              "کندل بسته می‌شود - تا گزارش نهایی هیچ پوزیشن معلقی نداشته باشد")
    args = parser.parse_args()

    symbols = [s.strip() for s in args.symbols.split(",") if s.strip()]
    client = BinanceClient(api_key="", api_secret="", name="backtest")
    use_adx_filter = args.ma_use_adx_filter == "true"
    adx_filter_symbols = None
    if args.ma_adx_symbols:
        adx_filter_symbols = [s.strip() for s in args.ma_adx_symbols.split(",") if s.strip()]
    use_ma200_filter = args.ma_use_ma200_filter == "true"
    require_same_direction = args.require_same_direction == "true"

    ma_targets = None
    if args.ma_targets:
        ma_targets = []
        for part in args.ma_targets.split(","):
            r_str, frac_str = part.split(":")
            ma_targets.append((float(r_str), float(frac_str)))

    ma_targets_by_symbol = None
    if args.ma_targets_by_symbol:
        ma_targets_by_symbol = {}
        for sym_block in args.ma_targets_by_symbol.split(";"):
            sym_block = sym_block.strip()
            if not sym_block:
                continue
            sym, target_str = sym_block.split("=")
            sym_targets = []
            for part in target_str.split(","):
                r_str, frac_str = part.split(":")
                sym_targets.append((float(r_str), float(frac_str)))
            ma_targets_by_symbol[sym.strip()] = sym_targets

    symbol_timeframes = {}
    if args.symbol_timeframes:
        for part in args.symbol_timeframes.split(","):
            sym, tf = part.split(":")
            symbol_timeframes[sym.strip()] = tf.strip()

    day_name_to_num = {"monday": 0, "tuesday": 1, "wednesday": 2, "thursday": 3,
                        "friday": 4, "saturday": 5, "sunday": 6}
    excluded_entry_windows = None
    if args.exclude_entry_windows:
        excluded_entry_windows = []
        for part in args.exclude_entry_windows.split(","):
            day_str, hour_str = part.split(":")
            excluded_entry_windows.append((day_name_to_num[day_str.strip().lower()], int(hour_str)))

    os.makedirs(ANGEL_REPORTS_DIR, exist_ok=True)

    print("=" * 70)
    print(f"نسخه‌ی کد: {config.BOT_CODE_VERSION}")
    print("انجل: استراتژی ۲ (MA Cross) - استراتژی ۳ (Spike) از انجل حذف شده")
    print(f"نمادها: {symbols} | بازه: {args.start} تا {args.end}")
    print(f"سرمایه: {args.balance} USDT")
    print(f"تایم‌فریم پیش‌فرض: {args.ma_timeframe}"
          + (f" | override: {symbol_timeframes}" if symbol_timeframes else ""))
    print(f"فیلتر ADX: {use_adx_filter} (کف={args.ma_adx_threshold}, سقف={args.ma_adx_max_threshold}) "
          f"| فیلتر MA200: {use_ma200_filter}")
    if excluded_entry_windows:
        print(f"⚠️ پنجره‌های ورود مستثنی‌شده: {args.exclude_entry_windows}")
    print(f"حداکثر پوزیشن هم‌زمان هر نماد: {args.max_concurrent_positions} "
          f"(هم‌جهت الزامی: {require_same_direction})")
    print("=" * 70)

    print("\nدر حال اجرای استراتژی ۲ (تقاطع MA)...")
    ma_result, ma_error, ma_dir = None, None, None
    try:
        ma_result = run_ma_cross_backtest(
            client, symbols, args.start, args.end,
            initial_balance=args.balance, margin_per_trade=args.margin_per_trade,
            leverage=args.leverage, sl_pct=args.ma_sl_pct, tp1_pct=args.ma_tp1_pct,
            tp2_pct=args.ma_tp2_pct, targets=ma_targets, targets_by_symbol=ma_targets_by_symbol,
            use_adx_filter=use_adx_filter, adx_filter_symbols=adx_filter_symbols,
            adx_threshold=args.ma_adx_threshold, adx_max_threshold=args.ma_adx_max_threshold,
            use_ma200_filter=use_ma200_filter,
            excluded_entry_windows=excluded_entry_windows,
            close_open_positions_at_end=args.close_open_positions_at_end == "true",
            timeframe=args.ma_timeframe,
            symbol_timeframes=symbol_timeframes or None,
            max_concurrent_positions_per_symbol=args.max_concurrent_positions,
            require_same_direction_for_concurrent=require_same_direction,
        )
        ma_dir = _save_ma_cross_reports(ma_result, symbols, args, args.ma_timeframe, symbol_timeframes)
        print(f"  انجام شد: {ma_result.portfolio_summary()['total_closed_trades']} معامله -> {ma_dir}")
    except Exception as e:
        ma_error = str(e)
        print(f"  خطا: {ma_error}")

    summary = {
        "code_version": config.BOT_CODE_VERSION,
        "symbols": symbols, "start": args.start, "end": args.end,
        "note": "استراتژی ۳ (Spike) از انجل حذف شده - این گزارش فقط استراتژی ۲ (MA Cross) است",
        "ma_cross": ma_result.portfolio_summary() if ma_result else {"error": ma_error},
    }
    json_path = os.path.join(ANGEL_REPORTS_DIR, "angel_combined_summary.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    def fmt(result, key, suffix=""):
        if result is None:
            return "خطا"
        val = result.portfolio_summary().get(key)
        return f"{val}{suffix}" if val is not None else "—"

    rows = [
        ("سرمایه‌ی اولیه", "initial_balance", " USDT"),
        ("موجودی نهایی", "final_balance", " USDT"),
        ("سود/زیان", "realized_pnl", " USDT"),
        ("بازده", "total_return_pct", "%"),
        ("Max Drawdown", "max_drawdown_pct", "%"),
        ("معاملات بسته‌شده", "total_closed_trades", ""),
    ]

    md_lines = [
        f"# گزارش انجل (فقط استراتژی ۲ - MA Cross) — {', '.join(symbols)}",
        "",
        f"> نسخه‌ی کد: `{config.BOT_CODE_VERSION}`",
        "",
        "> استراتژی ۳ (اسپایک/شورت عمیق) طبق درخواست از انجل حذف شده. اگر بخواهید "
        "می‌توانید همچنان جدا با `run_spike_backtest.py` اجرایش کنید.",
        "",
        f"- بازه: `{args.start}` تا `{args.end}` (UTC) | سرمایه: `{args.balance:,.2f} USDT`",
        "",
        "## نتیجه",
        "",
        "| معیار | مقدار |",
        "|---|---:|",
    ]
    for label, key, suffix in rows:
        md_lines.append(f"| {label} | {fmt(ma_result, key, suffix)} |")
    md_lines += [
        "",
        "## جزئیات کامل",
        "",
        f"- `{os.path.relpath(ma_dir, os.path.dirname(__file__)) if ma_dir else '—'}/ma_backtest_report.md`",
        "",
        "> این گزارش توصیه‌ی مالی نیست. قبل از اجرای واقعی، تست‌نت الزامی است.",
    ]
    md_path = os.path.join(ANGEL_REPORTS_DIR, "angel_combined_report.md")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write("\n".join(md_lines))

    print("\n" + "=" * 70)
    print("خلاصه:")
    for label, key, suffix in rows:
        print(f"  {label}: {fmt(ma_result, key, suffix)}")
    print(f"\nگزارش: {md_path}")
    print(f"جزئیات کامل: {ma_dir}")


if __name__ == "__main__":
    main()
