"""
موتور بک‌تست استراتژی تقاطع MA5/MA20 (مستقل از موتور استراتژی قبلی).

منطق سیگنال دقیقاً بدون تغییر است:
  ورود لانگ  : MA5 از پایین به بالای MA20 عبور کند
  ورود شورت  : MA5 از بالا به پایین MA20 عبور کند

مدیریت پوزیشن به‌صورت عمومی (N هدف مبتنی بر R) پیاده شده:
  - SL = ورود ± sl_pct% (این فاصله = ۱R)
  - targets: لیستی از (ضریب R, درصد بسته‌شدن) - مثلاً [(1,0.3),(2,0.4),(3,0.3)]
    یعنی هدف اول در 1R با بستن 30%، هدف دوم در 2R با بستن 40%، هدف سوم در 3R با بستن 30%
  - اگر targets داده نشود، به‌صورت پیش‌فرض از tp1_pct/tp1_close_fraction/tp2_pct
    (حالت قدیمی دوهدفه) ساخته می‌شود - کاملاً سازگار با نسخه‌ی قبلی
  - **استاپ با هر هدف جابجا می‌شود** (trailing از طریق تارگت‌ها): بعد از رسیدن به
    هدف اول، SL برای باقیمانده به نقطه‌ی ورود (BE) منتقل می‌شود؛ بعد از رسیدن به
    هدف دوم، SL به سطح قیمتی هدف اول منتقل می‌شود (سود هدف اول را قفل می‌کند)؛ و
    همین‌طور با هر هدف بعدی، SL به سطح قیمتی هدف قبلی منتقل می‌شود
  - اگر بین دو کندل هم SL/استاپ‌جابجاشده هم هدف بعدی لمس شوند، محافظه‌کارانه فرض
    می‌شود بدترین حالت (SL) زودتر رخ داده است؛ هر پوزیشن حداکثر یک رویداد در هر
    کندل پردازش می‌شود

امکان باز بودن حداکثر max_concurrent_positions_per_symbol پوزیشن هم‌زمان روی یک نماد
اضافه شده (پیش‌فرض ۱ = رفتار قبلی)؛ اگر require_same_direction_for_concurrent فعال
باشد (پیش‌فرض)، پوزیشن دوم فقط اگر هم‌جهت با پوزیشن(های) باز باشد مجاز است.

سرمایه‌ی مشترک بین همه‌ی نمادها (مثل حالت portfolio موتور قبلی).
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import pandas as pd

import config
from core.binance_client import BinanceClient
from core.ma_cross_strategy import compute_ma_cross_signal, passes_adx_filter, passes_ma200_filter, \
    last_adx_value, MA_FAST_PERIOD, MA_SLOW_PERIOD, ADX_PERIOD, ADX_THRESHOLD, MA200_PERIOD
from backtest.post_stop_analysis import analyze_post_stop_moves, post_stop_summary as _shared_post_stop_summary


@dataclass
class MATrade:
    symbol: str
    side: str
    entry_time: pd.Timestamp
    entry_price: float
    quantity: float
    margin_used: float
    sl_initial: float
    r_distance: float
    targets: List[Tuple[float, float, float]]  # (ضریب R, سطح قیمت, درصد بسته‌شدن)

    legs: List[dict] = field(default_factory=list)  # هرکدام: time/price/qty/reason/pnl
    remaining_qty: float = 0.0
    next_target_idx: int = 0
    current_stop: Optional[float] = None  # None = هنوز هدف اول نخورده (SL اولیه فعال است)
    stage: str = "open"  # "open" | "closed"

    # فیلدهای تشخیصی لحظه‌ی ورود - برای تحلیل بعدی که آیا ورودهای بازنده الگوی
    # مشترکی دارند (مثلاً ADX ضعیف‌تر یا فاصله‌ی کمتر بین MA5/MA20 نسبت به برنده‌ها)
    adx_at_entry: Optional[float] = None
    ma_gap_pct_at_entry: Optional[float] = None

    @property
    def total_pnl(self) -> float:
        return sum(leg["pnl"] for leg in self.legs)

    def to_dict(self):
        d = {
            "symbol": self.symbol, "side": self.side,
            "entry_time": self.entry_time.isoformat(), "entry_price": round(self.entry_price, 6),
            "quantity": round(self.quantity, 6), "margin_used": round(self.margin_used, 4),
            "sl_initial": round(self.sl_initial, 6), "r_distance": round(self.r_distance, 6),
            "num_targets": len(self.targets), "num_legs_closed": len(self.legs),
            "adx_at_entry": round(self.adx_at_entry, 2) if self.adx_at_entry is not None else None,
            "ma_gap_pct_at_entry": round(self.ma_gap_pct_at_entry, 4)
            if self.ma_gap_pct_at_entry is not None else None,
            "total_pnl": round(self.total_pnl, 4),
        }
        for i, leg in enumerate(self.legs, start=1):
            d[f"leg{i}_time"] = leg["time"].isoformat()
            d[f"leg{i}_price"] = round(leg["price"], 6)
            d[f"leg{i}_qty"] = round(leg["qty"], 6)
            d[f"leg{i}_reason"] = leg["reason"]
            d[f"leg{i}_pnl"] = round(leg["pnl"], 4)
        return d


def _fee(notional: float) -> float:
    return notional * (config.TAKER_FEE_PCT / 100)


def _funding(notional: float, hold_hours: float) -> float:
    return notional * (config.FUNDING_RATE_PCT_PER_8H / 100) * (hold_hours / 8)


def _close_leg(trade: MATrade, time: pd.Timestamp, price: float, qty: float,
               reason: str, hold_hours: float) -> float:
    direction = 1 if trade.side == "long" else -1
    gross = (price - trade.entry_price) * qty * direction
    notional_entry = trade.entry_price * qty
    notional_exit = price * qty
    pnl = gross - _fee(notional_entry) - _fee(notional_exit) - _funding(notional_entry, hold_hours)
    trade.legs.append({"time": time, "price": price, "qty": qty, "reason": reason, "pnl": pnl})
    return pnl


@dataclass
class MACrossPortfolioResult:
    trades: List[MATrade] = field(default_factory=list)
    equity_curve: List[tuple] = field(default_factory=list)
    initial_balance: float = 0.0
    final_balance: float = 0.0
    symbols: List[str] = field(default_factory=list)
    rejected_due_to_margin: int = 0
    open_positions_at_end: List[dict] = field(default_factory=list)
    post_stop_analysis: List[dict] = field(default_factory=list)
    data_warnings: List[str] = field(default_factory=list)

    def trades_for(self, symbol: str) -> List[MATrade]:
        return [t for t in self.trades if t.symbol == symbol]

    def post_stop_analysis_df(self):
        return pd.DataFrame(self.post_stop_analysis)

    def post_stop_summary(self) -> dict:
        """
        درصد معاملاتی که بعد از خوردن استاپ کامل (تک‌leg با reason='stop_loss')، نهایتاً
        (در بازه‌ی حداکثر ۷۲ ساعت) به هر سطح R رسیده‌اند.
        """
        return _shared_post_stop_summary(self.post_stop_analysis)

    def symbol_summary(self, symbol: str) -> dict:
        trades = self.trades_for(symbol)
        wins = [t for t in trades if t.total_pnl > 0]
        losses = [t for t in trades if t.total_pnl <= 0]
        gross_win = sum(t.total_pnl for t in wins)
        gross_loss = abs(sum(t.total_pnl for t in losses))
        pf = (gross_win / gross_loss) if gross_loss > 0 else (float("inf") if gross_win > 0 else 0.0)
        full_stop_loss_count = sum(1 for t in trades if len(t.legs) == 1 and t.legs[0]["reason"] == "stop_loss")
        reached_target1_count = sum(1 for t in trades if t.legs and t.legs[0]["reason"] != "stop_loss")
        return {
            "symbol": symbol,
            "total_trades": len(trades),
            "win_rate_pct": round(len(wins) / len(trades) * 100, 2) if trades else 0.0,
            "profit_factor": round(pf, 2) if pf != float("inf") else "inf",
            "reached_tp1_count": reached_target1_count,
            "full_stop_loss_count": full_stop_loss_count,
            "realized_pnl": round(sum(t.total_pnl for t in trades), 2),
        }

    @property
    def max_drawdown_pct(self):
        peak = -float("inf")
        max_dd = 0.0
        for _, equity in self.equity_curve:
            peak = max(peak, equity)
            dd = (equity - peak) / peak * 100 if peak > 0 else 0
            max_dd = min(max_dd, dd)
        return max_dd

    def portfolio_summary(self) -> dict:
        return {
            "initial_balance": round(self.initial_balance, 2),
            "final_balance": round(self.final_balance, 2),
            "realized_pnl": round(self.final_balance - self.initial_balance, 2),
            "total_return_pct": round((self.final_balance - self.initial_balance) / self.initial_balance * 100, 2)
            if self.initial_balance else 0.0,
            "max_drawdown_pct": round(self.max_drawdown_pct, 2),
            "total_closed_trades": len(self.trades),
            "rejected_due_to_margin": self.rejected_due_to_margin,
            "open_positions_at_end": len(self.open_positions_at_end),
        }


def _timeframe_to_minutes(timeframe: str) -> int:
    """تبدیل رشته‌ی تایم‌فریم بایننس (مثل '15m', '1h', '4h', '1d') به تعداد دقیقه."""
    unit = timeframe[-1]
    value = int(timeframe[:-1])
    if unit == "m":
        return value
    if unit == "h":
        return value * 60
    if unit == "d":
        return value * 60 * 24
    raise ValueError(f"تایم‌فریم پشتیبانی‌نشده: {timeframe}")


def run_ma_cross_backtest(client: BinanceClient, symbols: List[str], start: str, end: str,
                           initial_balance: float = 10000.0,
                           margin_per_trade: float = 100.0,
                           leverage: int = 6,
                           sl_pct: float = 3.0,
                           tp1_pct: float = 3.0,
                           tp1_close_fraction: float = 0.5,
                           tp2_pct: float = 6.0,
                           targets: Optional[List[Tuple[float, float]]] = None,
                           targets_by_symbol: Optional[Dict[str, List[Tuple[float, float]]]] = None,
                           max_concurrent_positions_per_symbol: int = 1,
                           require_same_direction_for_concurrent: bool = True,
                           ma_fast: int = MA_FAST_PERIOD,
                           ma_slow: int = MA_SLOW_PERIOD,
                           use_adx_filter: bool = False,
                           adx_filter_symbols: Optional[List[str]] = None,
                           adx_period: int = ADX_PERIOD,
                           adx_threshold: float = ADX_THRESHOLD,
                           adx_max_threshold: Optional[float] = None,
                           use_ma200_filter: bool = False,
                           ma200_period: int = MA200_PERIOD,
                           excluded_entry_windows: Optional[List[Tuple[int, int]]] = None,
                           close_open_positions_at_end: bool = False,
                           timeframe: str = "15m",
                           symbol_timeframes: Optional[Dict[str, str]] = None) -> MACrossPortfolioResult:
    """
    timeframe: تایم‌فریم پیش‌فرض برای نمادهایی که در symbol_timeframes نیامده‌اند.
    symbol_timeframes: نگاشت اختیاری symbol -> timeframe برای override کردن تایم‌فریم
    عمومی به‌ازای نمادهای خاص - مثلاً می‌توان بعضی نمادها را ۱۵دقیقه و بقیه را ۱ساعته
    در یک اجرای واحد (با سرمایه‌ی مشترک) اجرا کرد. منطق ورود (تقاطع MA + فیلتر ADX)
    برای همه یکسان است؛ فقط طول کندل پایه‌ی هرکدام فرق می‌کند.

    use_ma200_filter: فیلتر اختیاری جهت روند - سیگنال لانگ فقط اگر قیمت بالای MA200
    (همان تایم‌فریم ورودی هر نماد) باشد، سیگنال شورت فقط اگر پایین‌تر باشد.

    excluded_entry_windows: لیست اختیاری (weekday, hour) که ورود جدید در آن (روز هفته،
    ساعت UTC) ممنوع می‌شود - weekday بر اساس دوشنبه=۰ ... یکشنبه=۶ (استاندارد پایتون).
    مثلاً [(6,4),(6,8),(6,12)] یعنی یکشنبه ساعت ۰۴/۰۸/۱۲ UTC هیچ ورود جدیدی زده نمی‌شود.
    پوزیشن‌های از قبل باز، بدون تغییر مدیریت می‌شوند - این فیلتر فقط جلوی ورود جدید را می‌گیرد.

    close_open_positions_at_end: اگر True باشد، در پایان بازه‌ی تست هر پوزیشنی که هنوز
    باز مانده (نه به SL/تارگت نهایی رسیده) با قیمت آخرین کندل موجود بسته می‌شود - تا
    گزارش نهایی هیچ پوزیشن معلقی نداشته باشد و کل PnL به‌صورت تحقق‌یافته (realized) دیده
    شود. پیش‌فرض False (رفتار قبلی حفظ می‌شود: پوزیشن باز می‌ماند و فقط سود/زیان
    پله‌های قبلاً بسته‌شده‌اش شمرده می‌شود).

    targets: لیست (ضریب R، درصد بسته‌شدن) - مثلاً [(1,0.3),(2,0.4),(3,0.3)]. اگر داده
    نشود، از tp1_pct/tp1_close_fraction/tp2_pct (حالت دوهدفه‌ی قبلی) ساخته می‌شود -
    که دقیقاً معادل [(tp1_pct/sl_pct, tp1_close_fraction), (tp2_pct/sl_pct, 1-tp1_close_fraction)]
    است، یعنی رفتار پیش‌فرض قبلی کاملاً حفظ می‌شود.

    targets_by_symbol: نگاشت اختیاری symbol -> لیست تارگت مخصوص آن نماد (همان فرمت
    targets) - برای نمادهایی که اینجا نیامده‌اند، از targets عمومی (یا tp1/tp2 قدیمی)
    استفاده می‌شود. این یعنی می‌توان بعضی نمادها را با ساختار تارگت متفاوت از بقیه
    در یک اجرای واحد (با سرمایه‌ی مشترک) اجرا کرد.

    adx_filter_symbols: لیست اختیاری نمادهایی که *فقط* برایشان فیلتر ADX اعمال شود -
    اگر داده شود، use_adx_filter دیگر عمومی نیست: نمادهای داخل این لیست فیلتر ADX
    دارند (صرف‌نظر از مقدار use_adx_filter)، نمادهای خارج این لیست فیلتر ADX ندارند.
    اگر داده نشود (None)، رفتار قبلی حفظ می‌شود: use_adx_filter یکسان روی همه اعمال
    می‌شود.
    """
    excluded_entry_windows_set = set(excluded_entry_windows or [])
    start_ts = pd.Timestamp(start, tz="UTC")
    end_ts = pd.Timestamp(end, tz="UTC")
    symbol_timeframes = symbol_timeframes or {}
    targets_by_symbol = targets_by_symbol or {}
    adx_filter_symbols_set = set(adx_filter_symbols) if adx_filter_symbols is not None else None

    def _adx_filter_active_for(symbol: str) -> bool:
        if adx_filter_symbols_set is not None:
            return symbol in adx_filter_symbols_set
        return use_adx_filter

    if targets is None:
        default_target_specs = [(tp1_pct / sl_pct, tp1_close_fraction), (tp2_pct / sl_pct, 1 - tp1_close_fraction)]
    else:
        default_target_specs = list(targets)

    def _target_specs_for(symbol: str):
        return targets_by_symbol.get(symbol, default_target_specs)

    def _min_candles_needed() -> int:
        need = max(ma_slow, adx_period * 4)
        if use_ma200_filter:
            need = max(need, ma200_period)
        return need

    symbol_data: Dict[str, dict] = {}
    for symbol in symbols:
        sym_tf = symbol_timeframes.get(symbol, timeframe)
        tf_minutes = _timeframe_to_minutes(sym_tf)
        warmup_candles_needed = _min_candles_needed()
        warmup_days = max(3, (warmup_candles_needed * tf_minutes) / (60 * 24) + 1)
        warmup_start = start_ts - pd.Timedelta(days=warmup_days)
        since_ms = int(warmup_start.timestamp() * 1000)

        # سقف تعداد کندل باید بر اساس بازه‌ی واقعی درخواستی محاسبه شود، نه یک عدد ثابت -
        # وگرنه بک‌تست‌های بلندمدت روی تایم‌فریم‌های ریز (مثلاً ۲۴ ماه روی ۱۵دقیقه)
        # بی‌سروصدا (بدون خطا) قبل از تاریخ پایان واقعی قطع می‌شوند. ۲۰٪ حاشیه‌ی
        # اطمینان اضافه شده است.
        total_days_needed = warmup_days + (end_ts - start_ts).days + 2
        candles_needed = int(total_days_needed * (60 * 24 / tf_minutes) * 1.2)
        max_candles = max(5000, candles_needed)

        df15 = client.fetch_ohlcv_full(symbol, sym_tf, since_ms=since_ms, max_candles=max_candles)
        df15 = df15[df15["timestamp"] <= end_ts].reset_index(drop=True)
        min_len_needed = _min_candles_needed() + 2
        if df15.empty or len(df15) < min_len_needed:
            continue

        # هشدار اگر با وجود سقف محاسبه‌شده، داده هنوز قبل از تاریخ پایان درخواستی قطع
        # شده باشد (مثلاً چون خود صرافی برای این نماد در آن بازه داده نداشته)
        actual_end = df15["timestamp"].max()
        data_truncated = actual_end < (end_ts - pd.Timedelta(days=2))

        symbol_data[symbol] = {
            "df15": df15,
            "ts_to_pos": {ts: i for i, ts in enumerate(df15["timestamp"])},
            "open_trades": [],
            "timeframe": sym_tf,
            "tf_minutes": tf_minutes,
            "data_truncated": data_truncated,
            "actual_end": actual_end,
        }

    if not symbol_data:
        raise ValueError("داده‌ای برای هیچ‌کدام از نمادها پیدا نشد")

    # تایم‌لاین مشترک = اجتماع (نه اشتراک) تایم‌استمپ‌های همه‌ی نمادها؛ چون نمادها
    # ممکن است تایم‌فریم متفاوت داشته باشند، هر نماد فقط در تایم‌استمپ‌های خودش
    # بررسی می‌شود (با ts_to_pos.get که همین الان هم None برمی‌گرداند اگر آن نماد
    # کندلی در آن لحظه نداشته باشد).
    union_ts = set()
    for data in symbol_data.values():
        ts_set = set(data["df15"].loc[data["df15"]["timestamp"] >= start_ts, "timestamp"])
        union_ts |= ts_set
    master_timeline = sorted(union_ts)
    if not master_timeline:
        raise ValueError("هیچ کندلی در بازه‌ی تست برای هیچ نمادی پیدا نشد")

    trades: List[MATrade] = []
    equity_curve: List[tuple] = [(master_timeline[0], initial_balance)]
    realized_equity = initial_balance
    locked_margin = 0.0
    rejected_due_to_margin = 0

    for now in master_timeline:
        # ---- مرحله‌ی ۱: پردازش پوزیشن‌های باز ----
        for symbol, data in symbol_data.items():
            open_trades: List[MATrade] = data["open_trades"]
            if not open_trades:
                continue
            pos = data["ts_to_pos"].get(now)
            if pos is None:
                continue
            candle = data["df15"].iloc[pos]

            still_open: List[MATrade] = []
            for trade in open_trades:
                hold_hours_now = max((now - trade.entry_time).total_seconds() / 3600, 0)

                # استاپ فعال فعلی: تا قبل از رسیدن به هدف اول، همان SL اولیه است؛
                # بعد از هر هدف، به‌جای ماندن ثابت روی نقطه‌ی ورود، به سطح قیمتیِ
                # همان هدفی که تازه خورده منتقل می‌شود (پله‌ای) - یعنی بعد از هدف ۱
                # به نقطه‌ی ورود (سود صفر)، بعد از هدف ۲ به سطح قیمت هدف ۱ (قفل سود
                # هدف اول)، و به همین ترتیب.
                active_stop = trade.current_stop if trade.current_stop is not None else trade.sl_initial
                has_next = trade.next_target_idx < len(trade.targets)
                next_target_price = trade.targets[trade.next_target_idx][1] if has_next else None

                if trade.side == "long":
                    hit_stop = candle["low"] <= active_stop
                    hit_target = has_next and candle["high"] >= next_target_price
                else:
                    hit_stop = candle["high"] >= active_stop
                    hit_target = has_next and candle["low"] <= next_target_price

                if hit_stop:  # محافظه‌کارانه: اگر هم‌زمان بود، استاپ برنده است
                    qty = trade.remaining_qty
                    reason = "stop_loss" if trade.next_target_idx == 0 else \
                        f"trailing_stop_after_target_{trade.next_target_idx}"
                    pnl = _close_leg(trade, now, active_stop, qty, reason, hold_hours_now)
                    trade.stage = "closed"
                    realized_equity += pnl
                    locked_margin -= trade.margin_used * (qty / trade.quantity)
                    trades.append(trade)
                    equity_curve.append((now, realized_equity))
                    continue

                elif hit_target:
                    r_mult, target_price, frac = trade.targets[trade.next_target_idx]
                    qty = trade.quantity * frac
                    pnl = _close_leg(trade, now, target_price, qty, f"target_{trade.next_target_idx + 1}",
                                      hold_hours_now)
                    trade.remaining_qty -= qty
                    realized_equity += pnl
                    locked_margin -= trade.margin_used * frac
                    equity_curve.append((now, realized_equity))

                    # استاپ را پله‌ای جابه‌جا کن: بعد از هدف اول -> نقطه‌ی ورود؛
                    # بعد از هدف دوم به بعد -> سطح قیمتِ هدف قبلی (قفل سود بیشتر)
                    if trade.next_target_idx == 0:
                        trade.current_stop = trade.entry_price
                    else:
                        trade.current_stop = trade.targets[trade.next_target_idx - 1][1]
                    trade.next_target_idx += 1

                    if trade.remaining_qty <= 1e-9:
                        trade.stage = "closed"
                        trades.append(trade)
                        continue
                    still_open.append(trade)
                else:
                    still_open.append(trade)

            data["open_trades"] = still_open

        # ---- مرحله‌ی ۲: بررسی سیگنال ورود جدید ----
        for symbol, data in symbol_data.items():
            open_trades: List[MATrade] = data["open_trades"]
            if len(open_trades) >= max_concurrent_positions_per_symbol:
                continue
            pos = data["ts_to_pos"].get(now)
            if pos is None:
                continue
            if excluded_entry_windows_set and (now.weekday(), now.hour) in excluded_entry_windows_set:
                continue  # این (روز هفته، ساعت) صریحاً از ورود جدید مستثنی شده

            df15 = data["df15"]
            window_size = _min_candles_needed() + 5
            window = df15.iloc[max(0, pos - window_size + 1): pos + 1]
            signal = compute_ma_cross_signal(window, fast=ma_fast, slow=ma_slow)
            if signal is None:
                continue
            if _adx_filter_active_for(symbol) and not passes_adx_filter(
                    window, period=adx_period, threshold=adx_threshold, max_threshold=adx_max_threshold):
                continue
            if use_ma200_filter and not passes_ma200_filter(window, signal, period=ma200_period):
                continue
            if open_trades and require_same_direction_for_concurrent and open_trades[0].side != signal:
                continue  # پوزیشن باز خلاف جهت است - اجازه‌ی هم‌زمانی نداریم

            entry_price = float(df15["close"].iloc[pos])
            free_balance = realized_equity - locked_margin
            if margin_per_trade > free_balance:
                rejected_due_to_margin += 1
                continue

            # ثبت تشخیصی لحظه‌ی ورود (بدون اثر روی تصمیم معامله - فقط برای تحلیل بعدی)
            adx_entry_val = last_adx_value(window, period=adx_period)
            ma5_val = window["close"].rolling(ma_fast).mean().iloc[-1]
            ma20_val = window["close"].rolling(ma_slow).mean().iloc[-1]
            ma_gap_pct = abs(ma5_val - ma20_val) / entry_price * 100 if entry_price else None

            quantity = (margin_per_trade * leverage) / entry_price
            r_distance = entry_price * (sl_pct / 100)
            sl = entry_price - r_distance if signal == "long" else entry_price + r_distance

            computed_targets: List[Tuple[float, float, float]] = []
            for r_mult, frac in _target_specs_for(symbol):
                price_level = entry_price + r_distance * r_mult if signal == "long" \
                    else entry_price - r_distance * r_mult
                computed_targets.append((r_mult, price_level, frac))

            new_trade = MATrade(
                symbol=symbol, side=signal, entry_time=now, entry_price=entry_price,
                quantity=quantity, margin_used=margin_per_trade, sl_initial=sl,
                r_distance=r_distance, targets=computed_targets, remaining_qty=quantity,
                adx_at_entry=adx_entry_val, ma_gap_pct_at_entry=ma_gap_pct,
            )
            data["open_trades"].append(new_trade)
            locked_margin += margin_per_trade

    if close_open_positions_at_end:
        for symbol, data in symbol_data.items():
            if not data["open_trades"]:
                continue
            last_price = float(data["df15"]["close"].iloc[-1])
            last_time = data["df15"]["timestamp"].iloc[-1]
            still_open = []
            for trade in data["open_trades"]:
                hold_hours_now = max((last_time - trade.entry_time).total_seconds() / 3600, 0)
                qty = trade.remaining_qty
                pnl = _close_leg(trade, last_time, last_price, qty, "end_of_backtest", hold_hours_now)
                trade.stage = "closed"
                realized_equity += pnl
                locked_margin -= trade.margin_used * (qty / trade.quantity)
                trades.append(trade)
                equity_curve.append((last_time, realized_equity))
            data["open_trades"] = still_open

    open_positions_at_end = []
    for symbol, data in symbol_data.items():
        for t in data["open_trades"]:
            open_positions_at_end.append({
                "symbol": symbol, "side": t.side, "stage": t.stage,
                "entry_time": t.entry_time.isoformat(), "entry_price": t.entry_price,
                "legs_closed": len(t.legs),
            })
            if t.legs:  # حداقل یک leg قبلاً سود/زیانش را به equity اضافه کرده - برای سازگاری در trades ثبت می‌شود
                trades.append(t)

    stopped_trades_generic = [
        {"symbol": t.symbol, "side": t.side, "entry_time": t.entry_time,
         "entry_price": t.entry_price, "sl_price": t.sl_initial, "stop_time": t.legs[0]["time"]}
        for t in trades if len(t.legs) == 1 and t.legs[0]["reason"] == "stop_loss"
    ]
    # توجه: تایم‌فریم هر نماد جدا در symbol_data[...]["tf_minutes"] ذخیره شده و
    # analyze_post_stop_moves به‌صورت خودکار همان را برای هر معامله استفاده می‌کند
    post_stop_rows = analyze_post_stop_moves(symbol_data, stopped_trades_generic)

    data_warnings = []
    for symbol, data in symbol_data.items():
        if data.get("data_truncated"):
            data_warnings.append(
                f"{symbol} ({data['timeframe']}): داده فقط تا {data['actual_end']} در دسترس بود "
                f"(بازه‌ی درخواستی تا {end_ts} بود) - نتایج این نماد کل بازه‌ی خواسته‌شده را پوشش نمی‌دهد"
            )

    return MACrossPortfolioResult(
        trades=trades, equity_curve=equity_curve, initial_balance=initial_balance,
        final_balance=realized_equity, symbols=list(symbol_data.keys()),
        rejected_due_to_margin=rejected_due_to_margin, open_positions_at_end=open_positions_at_end,
        post_stop_analysis=post_stop_rows, data_warnings=data_warnings,
    )
