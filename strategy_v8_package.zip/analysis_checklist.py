"""
Standard post-backtest analysis checklist.
Edit the FILE variable below to point at whichever trades CSV you want to
analyze (e.g. sync_scalper_trades_XRP-USDT-USDT_15m.csv).
"""
import pandas as pd

FILE = "sync_scalper_trades_XRP-USDT-USDT_15m.csv"  # <-- change this per run

df = pd.read_csv(FILE)
df["entry_time"] = pd.to_datetime(df["entry_time"])
df["hour"] = df["entry_time"].dt.hour
df["move_pct"] = (df["exit"] - df["entry"]) / df["entry"] * 100
df.loc[df["side"] == "short", "move_pct"] = -df.loc[df["side"] == "short", "move_pct"]

def session(h):
    if 0 <= h < 8:
        return "Asia"
    if 8 <= h < 16:
        return "London"
    return "NewYork"

df["session"] = df["hour"].apply(session)

wins = df[df["pnl"] > 0]
losses = df[df["pnl"] <= 0]

print("========== 1. Win/Loss count ==========")
print("Wins:", len(wins), "Losses:", len(losses))
if len(df):
    print("Win rate:", round(len(wins) / len(df) * 100, 2), "%")

print()
print("========== 2. Direction breakdown ==========")
print("Direction - Wins:")
print(wins["side"].value_counts())
print("Direction - Losses:")
print(losses["side"].value_counts())

print()
print("========== 3. Session breakdown ==========")
print("Session - Wins:")
print(wins["session"].value_counts())
print("Session - Losses:")
print(losses["session"].value_counts())

print()
print("========== 4. Move pct after win/loss ==========")
print("Avg move pct - Wins:", round(wins["move_pct"].mean(), 3))
print("Avg move pct - Losses:", round(losses["move_pct"].mean(), 3))
print("Max positive move (win):", round(wins["move_pct"].max(), 3))
print("Max negative move (loss):", round(losses["move_pct"].min(), 3))

print()
print("========== 5. Abnormal losses (beyond intended SL) ==========")
big = losses[losses["move_pct"].abs() > 10]
print("Losses over 10 pct move:", len(big))
if len(big):
    print(big[["side", "entry", "exit", "reason", "move_pct", "pnl"]])
print()
print("Loss reason breakdown:")
print(losses["reason"].value_counts())

print()
print("========== Bonus: TP vs SL distance, and MFE (room left after TP) ==========")
tp_hits = df[df["reason"] == "take_profit"]
sl_hits = df[df["reason"] == "stop_loss"]
print("TP distance (avg):", round(tp_hits["move_pct"].mean(), 3), "%")
print("SL distance (avg):", round(sl_hits["move_pct"].abs().mean(), 3), "%")
if len(sl_hits) and sl_hits["move_pct"].abs().mean() != 0:
    print("Ratio TP/SL:", round(tp_hits["move_pct"].mean() / sl_hits["move_pct"].abs().mean(), 3))
if "mfe_pct" in df.columns:
    print()
    print("MFE (max favorable move reached, regardless of exit) - Wins:")
    print(wins["mfe_pct"].describe())
    print("MFE - Losses (how far price ran in our favor before reversing to SL):")
    print(losses["mfe_pct"].describe())
    # room left after TP: how much further price could have gone past our TP, on winning trades
    room_after_tp = tp_hits["mfe_pct"] - tp_hits["move_pct"]
    print()
    print("Room left AFTER hitting TP (wins only) - i.e. how much bigger TP could have been:")
    print(room_after_tp.describe())
